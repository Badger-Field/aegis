"""
	Fenomscrapers Module
"""

from testneto.modules.control import addonPath, addonVersion, joinPath
from testneto.modules.textviewer import TextViewerXML


def get(file):
	testneto_path = addonPath()
	testneto_version = addonVersion()
	helpFile = joinPath(testneto_path, 'resources', 'help', file + '.txt')
	r = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]TestNeto -  v%s - %s[/B]' % (testneto_version, file)
	windows = TextViewerXML('textviewer.xml', testneto_path, heading=heading, text=text)
	windows.run()
	del windows
