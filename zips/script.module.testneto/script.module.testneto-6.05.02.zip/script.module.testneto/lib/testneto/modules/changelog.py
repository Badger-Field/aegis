"""
	Fenomscrapers Module
"""

from testneto.modules.control import addonPath, addonVersion, joinPath
from testneto.modules.textviewer import TextViewerXML


def get():
	testneto_path = addonPath()
	testneto_version = addonVersion()
	changelogfile = joinPath(testneto_path, 'changelog.txt')
	r = open(changelogfile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]TestNeto -  v%s - ChangeLog[/B]' % testneto_version
	windows = TextViewerXML('textviewer.xml', testneto_path, heading=heading, text=text)
	windows.run()
	del windows
