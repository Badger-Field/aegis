import sys
import logging
import abc

from ..exceptions import CloudflareSolveError

if sys.version_info >= (3, 4):
    ABC = abc.ABC  # noqa
else:
    ABC = abc.ABCMeta('ABC', (), {})

# ------------------------------------------------------------------------------- #

interpreters = {}

# ------------------------------------------------------------------------------- #


class JavaScriptInterpreter(ABC):

    # ------------------------------------------------------------------------------- #

    @abc.abstractmethod
    def __init__(self, name):
        interpreters[name] = self

    # ------------------------------------------------------------------------------- #

    @classmethod
    def dynamicImport(cls, name):
        # Aegis strip: dynamic __import__ replaced with explicit static import of the
        # 'native' interpreter (pure-Python AST arithmetic, no eval). Other interpreters
        # (chakracore/js2py/nodejs/v8) are not registered and not callable. See
        # tools/strip_testneto.py.
        if 'native' not in interpreters:
            from . import native as _native  # noqa: F401  (registers itself on import)
        return interpreters['native']

    # ------------------------------------------------------------------------------- #

    @abc.abstractmethod
    def eval(self, jsEnv, js):
        pass

    # ------------------------------------------------------------------------------- #

    def solveChallenge(self, body, domain):
        try:
            return '{0:.10f}'.format(float(self.eval(body, domain)))
        except Exception:
            raise CloudflareSolveError(
                'Error trying to solve Cloudflare IUAM Javascript, they may have changed their technique.'
            )
