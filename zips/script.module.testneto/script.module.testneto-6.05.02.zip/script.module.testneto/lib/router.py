"""
	Fenomscrapers Module
"""

from sys import argv
from urllib.parse import parse_qsl
from testneto import providers
from testneto.modules import control

params = dict(parse_qsl(argv[2].replace('?', '')))
action = params.get('action')
name = params.get('name')

if action is None:
	from testneto.player.navigator import Navigator
	Navigator(params).main()

elif action == 'MediaPlay':
	from testneto import player
	player.TestNetoPlayer().source_select(params)

elif action in ('Movies', 'Series', 'Episodes'):
	from testneto.player import navigator
	if action == 'Episodes': cls = navigator.Episodes()
	elif action == 'Series': cls = navigator.Series()
	else: cls = navigator.Movies()
	cls.run(params)

elif action == 'ShowReadme':
	from testneto.modules import help
	help.get('aioStreams')

elif action == 'InstallJson':
	from testneto.player import settings
	settings.install_json()

elif action == 'ColorPick':
	from testneto.player import settings
	settings.color_pick(params)

elif action == 'TestNetoSettings':
	control.openSettings('0.0', 'script.module.testneto')

elif action == 'ShowChangelog':
	from testneto.modules import changelog
	changelog.get()

elif action == 'ShowHelp':
	from testneto.modules import help
	help.get(name)

elif action == 'Defaults':
	from testneto import sources
	try:
		provider_defaults = control.getProviderDefaults()
		sourceList = []
		sourceList = sources(ret_all=True)
		for name, source in sourceList:
			source_setting = 'provider.' + name
			default_setting = provider_defaults.get(source_setting) or 'false'
			control.setSetting(source_setting, default_setting)
		control.notification(message='Success')
	except: control.notification(message='Error')

elif action == 'toggleAll':
	sourceList = []
	sourceList = providers.all_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])

elif action == 'toggleAllHosters':
	sourceList = []
	sourceList = providers.hoster_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])

elif action == 'toggleAllTorrent':
	sourceList = []
	sourceList = providers.torrent_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])

elif action == 'toggleAllPackTorrent':
	from testneto import sources
	sourceList = []
	sourceList = sources(ret_all=True)
	for name, source in sourceList:
		setting = 'true' if source.pack_capable else 'false'
		source_setting = 'provider.' + name
		control.setSetting(source_setting, setting)

elif action == 'cleanSettings':
	control.clean_settings()

elif action == 'undesirablesSelect':
	from testneto.modules.undesirables import undesirablesSelect
	undesirablesSelect()

elif action == 'undesirablesInput':
	from testneto.modules.undesirables import undesirablesInput
	undesirablesInput()

elif action == 'undesirablesUserRemove':
	from testneto.modules.undesirables import undesirablesUserRemove
	undesirablesUserRemove()

elif action == 'undesirablesUserRemoveAll':
	from testneto.modules.undesirables import undesirablesUserRemoveAll
	undesirablesUserRemoveAll()

elif action == 'tools_clearLogFile':
	from testneto.modules import log_utils
	cleared = log_utils.clear_logFile()
	if cleared == 'canceled': pass
	elif cleared: control.notification(message='TestNeto Log File Successfully Cleared')
	else: control.notification(message='Error clearing TestNeto Log File, see kodi.log for more info')

elif action == 'tools_viewLogFile':
	from testneto.modules import log_utils
	log_utils.view_LogFile(name)

elif action == 'tools_uploadLogFile':
	from testneto.modules import log_utils
	log_utils.upload_LogFile()

elif action == 'healthCheck':
	from testneto.modules.health import testneto
	testneto()
