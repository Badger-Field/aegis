"""Dynamic autoplay quality ceiling.

Autoplay ("Auto Play best source") grabs the highest-quality source umbrella
returns — which is usually 4K. On a fast wired box that's great; on a Firestick
over wifi it means "click -> 4K -> buffer/stutter", because a 4K pull has to
sustain far more bitrate than the link (or the decoder) can hold. A fixed 1080p
cap would fix the stutter but rob the good setups of 4K.

So instead we measure the device's *actual* sustained download throughput and
set umbrella's "Max Quality" (hosts.quality) to the best resolution that link
can stream smoothly. Same idea as the live-TV proxy's dynamic bitrate cap:
measure the real pipe, don't assume it. Runs per-device, so every family box
settles to what it can actually handle.

hosts.quality is umbrella's resolution ceiling: 0=4K, 1=1080p, 2=720p, 3=480p.
"""
from __future__ import annotations

import time
from typing import Any, Callable, Optional

# Cloudflare's speed endpoint streams exactly `bytes` of throwaway data over
# HTTPS from an anycast edge near the device — a stable, global, no-auth probe
# target. GuardedSession allows it (https + TLS verify); no host allowlist.
_PROBE_URL = "https://speed.cloudflare.com/__down?bytes={bytes}"
_DEFAULT_SAMPLE_BYTES = 8_000_000       # ~8 MB: long enough to get past TCP slow-start
_DEFAULT_TIMEOUT = 20.0                  # per-socket connect/read timeout (requests)
# Hard wall-clock cap on the whole transfer. requests' `timeout` is per-read, not
# total, so a slow *trickle* (e.g. the link already saturated by an active
# stream) never trips it and iter_content can block for minutes. This bounds the
# probe so it can't hang service startup; we keep whatever arrived by the cap.
_DEFAULT_MAX_DURATION = 12.0
_MIN_ELAPSED = 0.05                      # guard divide-by-zero on an implausibly fast read
_MIN_SAMPLE_BYTES = 2_000_000           # < 2 MB transferred = too little to trust -> None
# Small chunks so the wall-clock cap is checked often: the loop can only re-check
# the clock between chunks, so a big chunk on a slow link coarsens the cap. 16 KiB
# keeps the worst-case gap small even before the socket-timeout clamp kicks in.
_CHUNK_BYTES = 16384

_QUALITY_LABELS = {0: "4K", 1: "1080p", 2: "720p", 3: "480p"}

# Sustained Mbps -> hosts.quality ceiling. Thresholds carry deliberate headroom
# over nominal stream bitrates: a debrid pull shares the household link and its
# throughput sags under contention, so we'd rather cap one tier low and play
# smooth than pick 4K on a link that can *momentarily* hit the number but not
# hold it. A weak-CPU device that can't decode 4K also tends to sit behind a
# slow link (cheap Firestick + wifi), so the bandwidth proxy correlates with
# decode headroom too — imperfect, but the dominant family failure is buffering.
# (threshold_mbps, ceiling) in descending order; below the last -> 480p.
_CEILING_THRESHOLDS = (
    (40.0, 0),   # >=40 Mbps -> 4K
    (15.0, 1),   # >=15      -> 1080p
    (6.0, 2),    # >=6       -> 720p
)

# Sentinel stored when the user has taken manual control of Max Quality; once we
# see it we never touch the setting again (see sync_dynamic_quality_ceiling).
USER_OWNED = "user"


def quality_ceiling_for_mbps(mbps: float) -> int:
    """Map a measured throughput (Mbps) to an umbrella hosts.quality ceiling."""
    for threshold, ceiling in _CEILING_THRESHOLDS:
        if mbps >= threshold:
            return ceiling
    return 3


def measure_mbps(
    *,
    session_factory: Callable[[], Any],
    sample_bytes: int = _DEFAULT_SAMPLE_BYTES,
    timeout: float = _DEFAULT_TIMEOUT,
    max_duration: float = _DEFAULT_MAX_DURATION,
    clock: Callable[[], float] = time.monotonic,
) -> Optional[float]:
    """Measure sustained download throughput in Mbps, or None if the probe
    fails or yields too little to trust. None means "don't know" — the caller
    must leave the setting unchanged, never guess.

    Stops at `max_duration` wall-clock and computes the rate from whatever
    arrived, so a saturated/degraded link caps the probe instead of hanging.
    A truncated sample under _MIN_SAMPLE_BYTES is treated as unknown (None)
    rather than a misleadingly low reading.
    """
    url = _PROBE_URL.format(bytes=sample_bytes)
    # The loop's max_duration check only fires AFTER a chunk arrives, so a read
    # that stalls mid-transfer would otherwise block for the full socket timeout.
    # Clamp the per-socket-op timeout to the wall-clock budget so no single
    # connect/read can blow past it — the loop bounds the total, this bounds the
    # tail. requests applies a single float to both connect and read.
    socket_timeout = min(timeout, max_duration)
    try:
        session = session_factory()
        start = clock()
        total = 0
        # stream=True so we time the actual transfer, not a buffered slurp.
        with session.get(url, stream=True, timeout=socket_timeout) as resp:
            resp.raise_for_status()
            for chunk in resp.iter_content(chunk_size=_CHUNK_BYTES):
                total += len(chunk)
                if clock() - start >= max_duration:
                    break  # wall-clock cap: keep the partial sample, don't hang
        elapsed = clock() - start
    except Exception:
        return None
    if elapsed < _MIN_ELAPSED or total < _MIN_SAMPLE_BYTES:
        return None
    return (total * 8) / elapsed / 1_000_000.0


def sync_dynamic_quality_ceiling(
    *,
    umbrella_addon: Callable[[], Any],
    measure: Callable[[], Optional[float]],
    read_last: Callable[[], Optional[str]],
    write_last: Callable[[str], None],
    log: Callable[[str], None],
) -> None:
    """Probe throughput and set umbrella's Max Quality to match — but only while
    Aegis still owns the setting.

    Ownership contract (so we adapt without ever fighting a user):
      - first run (read_last() is None) with the setting at umbrella's 4K
        default: Aegis manages it.
      - first run with a NON-default value already present: the user chose it —
        record USER_OWNED and never touch it.
      - later run where the current value != what Aegis last wrote: the user
        changed it since — record USER_OWNED and back off for good.
    """
    umbrella = umbrella_addon()
    if umbrella is None:
        return
    last = read_last()
    if last == USER_OWNED:
        return
    current = (umbrella.getSetting("hosts.quality") or "0").strip()
    if last is None:
        if current != "0":
            write_last(USER_OWNED)
            return
    elif current != str(last):
        write_last(USER_OWNED)
        return

    mbps = measure()
    if mbps is None:
        log("Aegis Umbrella: bandwidth probe failed; Max Quality left unchanged")
        return
    ceiling = quality_ceiling_for_mbps(mbps)
    if current != str(ceiling):
        umbrella.setSetting("hosts.quality", str(ceiling))
        log("Aegis Umbrella: measured {:.1f} Mbps -> Max Quality {} (dynamic)".format(
            mbps, _QUALITY_LABELS.get(ceiling, ceiling)))
    write_last(str(ceiling))
