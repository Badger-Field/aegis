"""First-run playback defaults: skin activation + English language + cache.

Extracted from service.py (behaviour-preserving). Self-contained: the headless-
harness guard stays with the caller in service.py (these are only invoked when
not in the harness), so this module depends on nothing from the entry point.
"""
from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from pathlib import Path

import xbmc
import xbmcvfs

# Kodi's factory-default values for the language prefs (i.e. "the user has not
# chosen"). We only set English when the current value is still one of these, so
# the default never fights a user who later picks another language.
AUDIO_LANG_FACTORY_DEFAULTS = {"mediadefault", "original", "default"}
SUB_LANG_FACTORY_DEFAULTS = {"original", "default"}

# Conservative streaming read-buffer config. Kodi's default buffer is small, so a
# high-bitrate source over a marginal network re-buffers ("pausing and pausing").
# 50 MB + buffermode=1 (buffer all network filesystems) rides out dips while
# staying well within Fire TV RAM.
ADVANCEDSETTINGS_CACHE = (
    ("buffermode", "1"),
    ("memorysize", "52428800"),  # 50 MB
    ("readfactor", "10"),
)


def current_skin() -> str:
    """Return the currently-active skin addon id via JSON-RPC, or ""."""
    try:
        resp = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","id":1,"method":"Settings.GetSettingValue",'
            '"params":{"setting":"lookandfeel.skin"}}'
        )
        return str(json.loads(resp).get("result", {}).get("value", ""))
    except Exception:
        return ""


def jsonrpc_get_setting(setting_id: str):
    try:
        resp = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
            "params": {"setting": setting_id},
        }))
        return json.loads(resp).get("result", {}).get("value")
    except Exception:
        return None


def jsonrpc_set_setting(setting_id: str, value) -> bool:
    try:
        resp = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
            "params": {"setting": setting_id, "value": value},
        }))
        return json.loads(resp).get("result") is True
    except Exception:
        return False


def apply_skin() -> None:
    """Activate skin.aegis as the active Kodi skin (first-run Step 2).

    The wizard used to push only the skin's status *properties* but never
    actually switched Kodi to skin.aegis, so a fresh install stayed on Estuary
    ("the skin doesn't stick"). Set it via JSON-RPC Settings.SetSettingValue,
    which applies immediately WITHOUT the Settings-UI "keep this change?" 15s
    revert dialog. Idempotent: no-ops if the skin isn't installed or is already
    active.
    """
    try:
        if not xbmc.getCondVisibility("System.HasAddon(skin.aegis)"):
            xbmc.log("Aegis: skin.aegis not installed; cannot apply skin", xbmc.LOGWARNING)
            return
        if current_skin() == "skin.aegis":
            return
        resp = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","id":1,"method":"Settings.SetSettingValue",'
            '"params":{"setting":"lookandfeel.skin","value":"skin.aegis"}}'
        )
        if json.loads(resp).get("result") is True:
            xbmc.log("Aegis: activated skin.aegis", xbmc.LOGINFO)
            xbmc.sleep(1500)  # let the skin reload settle before further dialogs
        else:
            xbmc.log("Aegis: failed to activate skin.aegis ({})".format(resp), xbmc.LOGWARNING)
    except Exception as exc:
        xbmc.log("Aegis: skin apply error: {}".format(exc), xbmc.LOGWARNING)


def apply_language_defaults() -> None:
    """Default audio + subtitle language to English (one-shot).

    Fixes the common "starts in a foreign language / Russian subs on multi-track
    releases" complaint: Kodi then auto-selects the English audio track and
    prefers English subtitles. One-shot by construction — only applied while the
    settings are still at Kodi's factory default, so it never overrides a user
    who later picks another language.
    """
    try:
        # A read that fails returns None -> skip (don't treat a transient
        # JSON-RPC failure as "still at factory default" and stomp a user choice).
        audio = jsonrpc_get_setting("locale.audiolanguage")
        if (
            audio is not None
            and str(audio).strip().lower() in AUDIO_LANG_FACTORY_DEFAULTS
            and jsonrpc_set_setting("locale.audiolanguage", "English")
        ):
            xbmc.log("Aegis: default audio language set to English", xbmc.LOGINFO)
        sub = jsonrpc_get_setting("locale.subtitlelanguage")
        if (
            sub is not None
            and str(sub).strip().lower() in SUB_LANG_FACTORY_DEFAULTS
            and jsonrpc_set_setting("locale.subtitlelanguage", "English")
        ):
            xbmc.log("Aegis: default subtitle language set to English", xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log("Aegis: language defaults error: {}".format(exc), xbmc.LOGWARNING)


def ensure_advancedsettings_cache() -> None:
    """Write a streaming read-buffer config to advancedsettings.xml (idempotent).

    This is the in-build fix for high-bitrate buffering on marginal networks.
    Creates special://profile/advancedsettings.xml with a <cache> block; takes
    effect on the next Kodi restart. Only writes when the file is ABSENT -- a
    user-owned advancedsettings.xml is left byte-for-byte untouched (it may hold
    comments and other tuning we must not reformat or clobber).
    """
    try:
        path = Path(xbmcvfs.translatePath("special://profile/advancedsettings.xml"))
        if path.exists():
            xbmc.log(
                "Aegis: advancedsettings.xml already present; leaving it untouched",
                xbmc.LOGINFO,
            )
            return
        root = ET.Element("advancedsettings")
        cache = ET.SubElement(root, "cache")
        for tag, val in ADVANCEDSETTINGS_CACHE:
            ET.SubElement(cache, tag).text = val
        path.parent.mkdir(parents=True, exist_ok=True)
        ET.ElementTree(root).write(str(path), encoding="utf-8", xml_declaration=True)
        xbmc.log(
            "Aegis: wrote streaming cache to advancedsettings.xml (applies next restart)",
            xbmc.LOGINFO,
        )
    except Exception as exc:
        xbmc.log("Aegis: advancedsettings cache write error: {}".format(exc), xbmc.LOGWARNING)
