"""Kodi crash / unclean-exit detection + user-facing surfacing.

Extracted from service.py (behaviour-preserving). Self-contained: the vault is
passed in (duck-typed .read()/.write()) and the Windows CrashDumps directory is
injected, so this module depends on nothing from the service entry point. The
thin delegators in service.py keep the `_WINDOWS_CRASHDUMPS_DIR` module global
(so tests can monkeypatch it) and forward it here.

Two independent signals:
  * Windows minidumps (kodi.exe.*.dmp) — precise, but Windows-only.
  * A vault heartbeat flag (monitor_active) — cross-platform, the only crash
    signal available on Android/Fire OS where tombstones are root-only.
"""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

import xbmc
import xbmcgui


def scan_recent_kodi_crashes(vault: Any, crashdumps_dir, *, max_age_hours: int = 48) -> List[Dict]:
    """Detect Kodi crash dumps written since the previous service start.

    Compares the per-dump mtime against a `service.last_seen_at` marker
    we persist on every run. Dumps newer than the marker are considered
    "new" — i.e. happened during the previous Kodi session — and get
    surfaced to the user via xbmc.log (LOGERROR) and a one-shot toast.

    Bounded to dumps newer than `max_age_hours` so a stale CrashDumps
    folder full of years-old dumps doesn't spam the user on every start.
    """
    if crashdumps_dir is None or not crashdumps_dir.exists():
        return []
    payload = vault.read()
    service_state = payload.setdefault("service", {})
    last_seen = float(service_state.get("last_seen_at") or 0)
    now = time.time()
    floor = max(last_seen, now - max_age_hours * 3600)

    found: List[Dict] = []
    try:
        for dump in crashdumps_dir.glob("kodi.exe.*.dmp"):
            # Single stat() call covers both mtime and size — if we stat
            # twice (once for the filter, once to fill the record) and
            # the file gets unlinked in between (e.g. user wipes the
            # crash folder while the service is starting up), the second
            # call would raise OSError → fall through to the outer
            # handler → abort the entire scan, losing any dumps we'd
            # already collected and skipping the last_seen_at marker
            # update. A per-file `continue` keeps the scan resilient.
            try:
                info = dump.stat()
            except OSError:
                continue
            if info.st_mtime > floor:
                found.append({
                    "path": str(dump),
                    "mtime": info.st_mtime,
                    "size_bytes": info.st_size,
                })
    except OSError as exc:
        xbmc.log("Aegis: crash scan failed: {}".format(exc), xbmc.LOGWARNING)
        return []

    # Update the marker so we don't double-report on the next start. We
    # write this regardless of whether we found dumps — the marker is
    # "service was running at this time," not "we saw a crash."
    service_state["last_seen_at"] = now
    try:
        vault.write(payload)
    except Exception as exc:
        xbmc.log("Aegis: failed updating service.last_seen_at: {}".format(exc), xbmc.LOGWARNING)

    return sorted(found, key=lambda d: d["mtime"], reverse=True)


def detect_unclean_previous_exit(vault: Any) -> Optional[Dict]:
    """Cross-platform crash/kill detector via an app-owned heartbeat flag.

    The Windows minidump scan above only works on Windows — Android/Fire OS
    writes native crashes to /data/tombstones/, which is root-only and NOT
    readable by the sandboxed Kodi app, so Firestick crashes were invisible.

    Instead we keep a `service.monitor_active` flag in the vault:
      - `_run_player_monitor` sets it True on start and clears it in its
        `finally` block, which runs on a clean Kodi shutdown (Monitor abort)
        but is SKIPPED when the process dies hard (SIGSEGV / OOM-kill / ANR).
      - So if this flag is still True at the next startup, the previous
        session's monitor armed it but never got to disarm it — an unclean
        exit.

    This can't distinguish a genuine crash from a force-stop (both skip the
    finally), so the user-facing wording is "ended unexpectedly", not
    "crashed". main() consumes (clears) the flag after detecting so the same
    event isn't re-reported on a subsequent boot where the monitor never runs.

    Returns a record dict when an unclean exit is detected, else None.
    """
    try:
        payload = vault.read()
    except Exception:
        return None
    service_state = payload.get("service", {}) if isinstance(payload, dict) else {}
    if not service_state.get("monitor_active"):
        return None

    started_at = float(service_state.get("monitor_started_at") or 0)
    # Consume the flag so we don't re-surface on a later boot where the
    # monitor never re-arms it (e.g. firstrun not complete).
    try:
        service_state["monitor_active"] = False
        payload["service"] = service_state
        vault.write(payload)
    except Exception as exc:
        xbmc.log("Aegis: failed clearing monitor_active flag: {}".format(exc), xbmc.LOGWARNING)

    return {"started_at": started_at}


def surface_unclean_previous_exit(record: Optional[Dict]) -> None:
    """User-visible signal for an unclean previous exit (crash / kill / ANR).

    Distinct wording from the Windows minidump path — we know the previous
    session didn't shut down cleanly, but not the cause.
    """
    if not record:
        return
    started_at = record.get("started_at") or 0
    if started_at:
        when = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(started_at))
        detail = "previous session (started {}) ended unexpectedly".format(when)
    else:
        detail = "previous session ended unexpectedly"
    xbmc.log(
        "Aegis crash-detect: {} — no clean shutdown recorded (crash, OOM-kill, "
        "or force-stop). On Android this is the only crash signal available "
        "(tombstones are root-only).".format(detail),
        xbmc.LOGWARNING,
    )
    try:
        xbmcgui.Dialog().notification(
            "Aegis",
            "Kodi didn't shut down cleanly last time (see kodi.log)",
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
    except Exception as exc:
        xbmc.log("Aegis: unclean-exit toast failed: {}".format(exc), xbmc.LOGWARNING)


def mark_monitor_active(vault: Any, active: bool) -> None:
    """Arm/disarm the heartbeat flag read by `detect_unclean_previous_exit`.

    Best-effort: a failed write just means we might miss a crash signal or
    emit a false one — never worth taking down the service thread over.
    """
    try:
        payload = vault.read()
        service_state = payload.setdefault("service", {})
        service_state["monitor_active"] = active
        if active:
            service_state["monitor_started_at"] = int(time.time())
        vault.write(payload)
    except Exception as exc:
        xbmc.log(
            "Aegis: failed to {} monitor heartbeat: {}".format(
                "arm" if active else "clear", exc
            ),
            xbmc.LOGWARNING,
        )


def surface_recent_crashes(crashes: List[Dict]) -> None:
    """User-visible signal for a crash since the last clean start.

    Two channels:
      1. LOGERROR lines that show up in kodi.log with enough detail to
         correlate against the dump file (path, mtime, size). This is
         what we'd want to see when triaging — it makes the next session's
         log self-documenting about the previous session's crash.
      2. A single short toast so a user who isn't tailing the log still
         notices ("Kodi recovered from a crash at HH:MM — see kodi.log
         for the dump path"). Throttled to one toast per startup,
         regardless of how many dumps were found.
    """
    if not crashes:
        return
    for crash in crashes:
        when = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(crash["mtime"]))
        xbmc.log(
            "Aegis crash-detect: previous Kodi session crashed at {} "
            "(dump {} bytes at {})".format(when, crash["size_bytes"], crash["path"]),
            xbmc.LOGERROR,
        )
    when_latest = time.strftime("%H:%M", time.localtime(crashes[0]["mtime"]))
    try:
        xbmcgui.Dialog().notification(
            "Aegis",
            "Kodi recovered from a crash at {} (see kodi.log)".format(when_latest),
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
    except Exception as exc:
        # Non-fatal — the LOGERROR lines above are the real signal,
        # the toast is just convenience.
        xbmc.log("Aegis: crash-detect toast failed: {}".format(exc), xbmc.LOGWARNING)
