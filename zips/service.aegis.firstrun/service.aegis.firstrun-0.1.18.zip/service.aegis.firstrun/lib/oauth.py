"""Debrid OAuth device flows + token refresh (Real-Debrid, AllDebrid).

Extracted from service.py (behaviour-preserving). Nearly self-contained: the
vault is duck-typed and the guarded HTTP session factory is injected
(session_factory=), so this module reaches back into the entry point for nothing.
Injecting the session (rather than importing GuardedSession here) also preserves
the test seam — tests monkeypatch service.GuardedSession and the delegators forward
that binding in.

redact_mapping is a netguard utility (faked at the aegis_netguard module level in
tests), so it's imported directly.
"""
from __future__ import annotations

import time
from typing import Any, Callable, Dict, Optional

import xbmc
import xbmcgui
from aegis_netguard import redact_mapping

# Real-Debrid device-OAuth endpoints + AllDebrid PIN flow. Public client id is
# RD's documented device-flow app id (not a secret). Grant type is RD's device
# grant URN. These live here (the OAuth module's natural home) and are re-exported
# from service.py for existing references + tests.
RD_PUBLIC_CLIENT_ID = "X245A4XAIBGVM"
RD_DEVICE_CODE_URL = "https://api.real-debrid.com/oauth/v2/device/code"
RD_DEVICE_CREDENTIALS_URL = "https://api.real-debrid.com/oauth/v2/device/credentials"
RD_TOKEN_URL = "https://api.real-debrid.com/oauth/v2/token"
RD_DEVICE_GRANT_TYPE = "http://oauth.net/grant_type/device/1.0"

AD_AGENT = "Aegis"
AD_PIN_GET_URL = "https://api.alldebrid.com/v4/pin/get"

SessionFactory = Callable[[], Any]


def refresh_rd_token_if_needed(vault: Any, *, session_factory: SessionFactory) -> None:
    try:
        payload = vault.read()
    except Exception:
        return

    rd_data = payload.get("rd")
    if not isinstance(rd_data, dict):
        return

    expires_at = int(rd_data.get("expires_at", 0) or 0)
    if expires_at - int(time.time()) >= 60:
        return

    refresh_token = rd_data.get("refresh_token")
    client_id = rd_data.get("client_id")
    client_secret = rd_data.get("client_secret")
    if not (refresh_token and client_id and client_secret):
        return

    session = session_factory()
    try:
        response = session.post(
            RD_TOKEN_URL,
            data={
                "client_id": client_id,
                "client_secret": client_secret,
                "code": refresh_token,
                "grant_type": RD_DEVICE_GRANT_TYPE,
            },
            timeout=15,
        )
    except Exception:
        return

    if response.status_code == 401:
        payload.pop("rd", None)
        vault.write(payload)
        xbmcgui.Dialog().notification(
            "Aegis",
            "Real-Debrid authorization revoked — re-authorize in Settings",
            xbmcgui.NOTIFICATION_WARNING,
            5000,
        )
        return

    if response.status_code != 200:
        return

    token_payload = response.json()
    now = int(time.time())
    rd_data["access_token"] = token_payload.get("access_token", rd_data.get("access_token", ""))
    rd_data["refresh_token"] = token_payload.get("refresh_token", refresh_token)
    rd_data["expires_at"] = now + int(token_payload.get("expires_in", 0) or 0)
    rd_data["token_type"] = token_payload.get("token_type", rd_data.get("token_type", "Bearer"))
    payload["rd"] = rd_data
    vault.write(payload)


def run_rd_device_flow(vault: Any, *, session_factory: SessionFactory) -> None:
    session = session_factory()

    # RD device-code endpoint: GET with query params. Verified against the live API
    # on 2026-05-17: POST returns 403 ("wrong_parameter") with URL params or 404
    # ("unknown_method") with a form body; only GET returns 200 with the device code.
    # DESIGN.md §7.2 incorrectly documents POST; treat the live API as source of truth.
    device_response = session.get(
        RD_DEVICE_CODE_URL,
        params={"client_id": RD_PUBLIC_CLIENT_ID, "new_credentials": "yes"},
        timeout=15,
    )
    device_response.raise_for_status()
    device_data = device_response.json()

    device_code = device_data["device_code"]
    user_code = device_data["user_code"]
    verification_url = device_data.get("verification_url") or "https://real-debrid.com/device"
    interval = max(1, int(device_data.get("interval", 5)))
    expires_in = max(interval, int(device_data.get("expires_in", 600)))
    deadline = int(time.time()) + expires_in

    xbmc.log(
        "Aegis RD device code: {} | URL: {} | Expires in: {} seconds".format(
            user_code, verification_url, expires_in
        ),
        xbmc.LOGINFO,
    )

    # Kodi 21 xbmcgui.Dialog().yesno signature: (heading, message, nolabel, yeslabel, autoclose).
    # Kodi 17-era line1/line2/line3 positional args are removed; combine into one message
    # with \n. Calling with the old 7-arg shape raises silently and we'd poll with no UI.
    try:
        proceed = xbmcgui.Dialog().yesno(
            "Aegis Real-Debrid",
            "[B]Go to:[/B] {}\n[B]Enter code:[/B] {}".format(verification_url, user_code),
            "Cancel",
            "I've authorized the device",
            900000,  # 15 min autoclose matches device code expiration
        )
    except Exception as dialog_exc:
        xbmc.log("Aegis RD dialog error (continuing anyway): {}".format(dialog_exc), xbmc.LOGWARNING)
        proceed = True  # Assume user will authorize; continue polling

    if not proceed:
        raise RuntimeError("Real-Debrid authorization canceled by user")

    client_credentials: Optional[Dict[str, str]] = None
    poll_attempt = 0
    while int(time.time()) < deadline:
        poll_attempt += 1
        credentials_response = session.get(
            RD_DEVICE_CREDENTIALS_URL,
            params={"client_id": RD_PUBLIC_CLIENT_ID, "code": device_code},
            timeout=15,
        )

        if credentials_response.status_code == 200:
            payload = credentials_response.json()
            if payload.get("client_id") and payload.get("client_secret"):
                xbmc.log(
                    "Aegis RD credentials received on attempt {}".format(poll_attempt),
                    xbmc.LOGINFO,
                )
                client_credentials = {
                    "client_id": payload["client_id"],
                    "client_secret": payload["client_secret"],
                }
                break
            xbmc.log(
                "Aegis RD credentials response OK but missing client_id/secret (attempt {})".format(
                    poll_attempt
                ),
                xbmc.LOGDEBUG,
            )
            time.sleep(interval)
            continue

        payload = credentials_response.json() if credentials_response.status_code in {400, 403, 410} else {}
        error_code = payload.get("error", "")

        if credentials_response.status_code == 400 and error_code == "authorization_pending":
            if poll_attempt % 5 == 0:  # Log every 5th attempt to avoid spam
                xbmc.log(
                    "Aegis RD waiting for authorization (attempt {})".format(poll_attempt),
                    xbmc.LOGDEBUG,
                )
            time.sleep(interval)
            continue

        if credentials_response.status_code == 400 and error_code == "slow_down":
            xbmc.log(
                "Aegis RD slow_down; increasing interval to {} seconds".format(interval + 5),
                xbmc.LOGDEBUG,
            )
            interval += 5
            time.sleep(interval)
            continue

        if credentials_response.status_code == 403 or error_code == "access_denied":
            raise PermissionError("Real-Debrid authorization was denied by user")

        if credentials_response.status_code == 410 or error_code == "expired_token":
            xbmc.log(
                "Aegis RD device code expired (status={}, error_code={})".format(
                    credentials_response.status_code, error_code
                ),
                xbmc.LOGERROR,
            )
            raise TimeoutError("Real-Debrid device code expired before approval")

        time.sleep(interval)

    if client_credentials is None:
        xbmc.log(
            "Aegis RD device flow timed out: deadline={}, now={}, attempts={}".format(
                deadline, int(time.time()), poll_attempt
            ),
            xbmc.LOGERROR,
        )
        raise TimeoutError("Real-Debrid device flow timed out before approval")

    xbmc.log(
        "Aegis RD exchanging device code for access token",
        xbmc.LOGINFO,
    )

    token_response = session.post(
        RD_TOKEN_URL,
        data={
            "client_id": client_credentials["client_id"],
            "client_secret": client_credentials["client_secret"],
            "code": device_code,
            "grant_type": RD_DEVICE_GRANT_TYPE,
        },
        timeout=15,
    )
    token_response.raise_for_status()
    token_payload = token_response.json()

    xbmc.log(
        "Aegis RD token payload received: expires_in={}, has_access_token={}".format(
            token_payload.get("expires_in", "N/A"),
            "access_token" in token_payload,
        ),
        xbmc.LOGINFO,
    )

    now = int(time.time())
    rd_entry = {
        "access_token": token_payload["access_token"],
        "refresh_token": token_payload["refresh_token"],
        "expires_at": now + int(token_payload.get("expires_in", 0)),
        "client_id": client_credentials["client_id"],
        "client_secret": client_credentials["client_secret"],
        "token_type": token_payload.get("token_type", "Bearer"),
        "created_at": now,
    }
    vault.upsert("rd", rd_entry)

    xbmc.log(
        "Aegis RD OAuth success: {}".format(redact_mapping({"access_token": rd_entry["access_token"]})),
        xbmc.LOGINFO,
    )


def run_ad_device_flow(vault: Any, *, session_factory: SessionFactory) -> None:
    session = session_factory()

    pin_response = session.get(
        AD_PIN_GET_URL,
        params={"agent": AD_AGENT},
        timeout=15,
    )
    pin_response.raise_for_status()
    pin_payload = pin_response.json()
    pin_data = pin_payload.get("data", {})

    pin = str(pin_data.get("pin", "")).strip()
    user_url = str(pin_data.get("user_url", "")).strip()
    check_url = str(pin_data.get("check_url", "")).strip()
    expires_in = int(pin_data.get("expires_in", 600) or 600)
    if not (pin and user_url and check_url):
        raise RuntimeError("AllDebrid PIN flow did not return expected fields")

    deadline = int(time.time()) + min(600, max(10, expires_in))

    xbmc.log(
        "Aegis AD PIN issued: pin={} url={} expires_in={}".format(pin, user_url, expires_in),
        xbmc.LOGINFO,
    )

    proceed = xbmcgui.Dialog().yesno(
        "Aegis AllDebrid",
        "[B]Go to:[/B] {}\n[B]Enter PIN:[/B] {}".format(user_url, pin),
        "Cancel",
        "I've authorized the device",
        900000,
    )
    if not proceed:
        raise RuntimeError("AllDebrid authorization canceled by user")

    ad_apikey = ""
    while int(time.time()) < deadline:
        check_response = session.get(check_url, timeout=15)
        check_response.raise_for_status()
        check_payload = check_response.json()
        check_data = check_payload.get("data", {})

        if check_data.get("activated"):
            ad_apikey = str(check_data.get("apikey", "")).strip()
            if not ad_apikey:
                raise RuntimeError("AllDebrid activation completed but no apikey returned")
            break

        time.sleep(5)

    if not ad_apikey:
        raise TimeoutError("AllDebrid PIN flow timed out before approval")

    now = int(time.time())
    ad_entry = {
        "apikey": ad_apikey,
        "created_at": now,
    }
    vault.upsert("ad", ad_entry)

    xbmc.log(
        "Aegis AD OAuth success: {}".format(redact_mapping({"apikey": ad_apikey})),
        xbmc.LOGINFO,
    )


def debrid_status_label(vault: Any) -> str:
    """Return a human-readable debrid status for the skin status chip."""
    try:
        rd = vault.read().get("rd", {})
    except Exception:
        return ""

    if not rd:
        return ""

    # RD access tokens are short-lived (~1h) but auto-refresh on every Kodi
    # startup via refresh_rd_token_if_needed. The refresh_token does not
    # expire unless the user revokes app access (per RD's own docs). So the
    # chip should show "Active" whenever a refresh_token exists, and only
    # warn when re-auth is actually needed.
    if not rd.get("refresh_token"):
        return "Debrid: Re-auth needed"
    return "Debrid: Active"
