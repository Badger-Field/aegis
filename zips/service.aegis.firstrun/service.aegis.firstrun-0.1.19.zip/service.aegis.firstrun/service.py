import hashlib
import inspect
import os
import re
import secrets
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import tomllib  # type: ignore[attr-defined]
except ModuleNotFoundError:
    tomllib = None

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from aegis_netguard import GuardedSession
from aegis_vault import VaultStore

# Add our own lib/ to sys.path so in-addon helper modules (playback_defaults etc.)
# import as top-level modules, mirroring plugin.video.aegis. Service addons don't
# get their lib/ on the path automatically (no xbmc.python.module extension).
_FIRSTRUN_LIB = Path(__file__).resolve().parent / "lib"
if str(_FIRSTRUN_LIB) not in sys.path:
    sys.path.insert(0, str(_FIRSTRUN_LIB))

import crashdetect  # type: ignore[import-not-found]
import oauth  # type: ignore[import-not-found]
import playback_defaults  # type: ignore[import-not-found]
import pvr_setup  # type: ignore[import-not-found]
import umbrella_sync  # type: ignore[import-not-found]

try:
    from fast_sources import get_fast_sources
    from iptv_org import IPTV_ORG_REGION_LABELS, get_iptv_org_category_sources, get_iptv_org_sources
    from merge import EPG_WINDOW_FUTURE_HOURS, merge
    from sources import Source, SourceRegistry
except ImportError:
    merge = None
    Source = None
    SourceRegistry = None
    get_iptv_org_sources = None
    get_iptv_org_category_sources = None
    IPTV_ORG_REGION_LABELS = None
    get_fast_sources = None
    # Conservative fallback matching the current tvhub default. Real
    # imports above replace this when tvhub is on sys.path; this branch
    # only fires in degraded harness runs where the merge module
    # isn't reachable.
    EPG_WINDOW_FUTURE_HOURS = 6


try:
    ADDON = xbmcaddon.Addon()
except RuntimeError:
    # Some harness invocations do not provide addon execution context.
    ADDON = xbmcaddon.Addon("service.aegis.firstrun")
PLUGIN_ADDON_ID = "plugin.video.aegis"

# The debrid OAuth flows + their endpoints now live in lib/oauth.py. Re-exported
# here so existing references (and tests reading service.RD_* / service.AD_*)
# keep working.
RD_PUBLIC_CLIENT_ID = oauth.RD_PUBLIC_CLIENT_ID
RD_DEVICE_CODE_URL = oauth.RD_DEVICE_CODE_URL
RD_DEVICE_CREDENTIALS_URL = oauth.RD_DEVICE_CREDENTIALS_URL
RD_TOKEN_URL = oauth.RD_TOKEN_URL
RD_DEVICE_GRANT_TYPE = oauth.RD_DEVICE_GRANT_TYPE

AD_AGENT = oauth.AD_AGENT
AD_PIN_GET_URL = oauth.AD_PIN_GET_URL

# The umbrella/testneto credential maps + provider set now live in
# lib/umbrella_sync.py (their natural home). Re-exported here so existing
# references (and tests that read service.UMBRELLA_* / TESTNETO_*) keep working.
UMBRELLA_RD_MAP = umbrella_sync.UMBRELLA_RD_MAP
UMBRELLA_RD_ENABLE_KEY = umbrella_sync.UMBRELLA_RD_ENABLE_KEY
UMBRELLA_AD_MAP = umbrella_sync.UMBRELLA_AD_MAP
UMBRELLA_AD_ENABLE_KEY = umbrella_sync.UMBRELLA_AD_ENABLE_KEY
UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID = umbrella_sync.UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID
UMBRELLA_EXTERNAL_PROVIDER_MODULE_NAME = umbrella_sync.UMBRELLA_EXTERNAL_PROVIDER_MODULE_NAME
TESTNETO_DEFAULT_ON_PROVIDERS = umbrella_sync.TESTNETO_DEFAULT_ON_PROVIDERS

# Local HLS-rewrite proxy. Strips EXT-X-DISCONTINUITY tags from Samsung TV+ /
# Roku / Plex Live manifests before they reach inputstream.ffmpegdirect,
# eliminating the decoder re-init stutter at ad-break boundaries (PR #43).
# Nothing declares it as a hard dependency (routing degrades gracefully to
# direct ffmpegdirect when it's absent), so on fresh installs it never lands
# unless firstrun installs it — which is why Firesticks were silently running
# without the stutter fix.
AEGIS_PROXY_ADDON_ID = "script.module.aegis.proxy"


def _safe_get_setting_bool(addon: xbmcaddon.Addon, setting_id: str, default: bool = False) -> bool:
    """Read setting as string first to avoid Kodi logging type-mismatch exceptions."""
    raw = ""
    try:
        raw = addon.getSetting(setting_id)
    except Exception:
        try:
            raw = addon.getSettingString(setting_id)
        except Exception:
            pass

    normalized = str(raw).strip().lower()
    if normalized in {"true", "1", "yes", "on"}:
        return True
    if normalized in {"false", "0", "no", "off"}:
        return False
    if normalized == "":
        return default

    xbmc.log(
        "Aegis: invalid bool setting value for {}.{}={!r}; using default {}".format(
            addon.getAddonInfo("id"), setting_id, raw, default
        ),
        xbmc.LOGWARNING,
    )
    return default


def _safe_get_setting_int(addon: xbmcaddon.Addon, setting_id: str, default: int = 0) -> int:
    """Read setting as string first to avoid Kodi logging type-mismatch exceptions."""
    raw = ""
    try:
        raw = addon.getSetting(setting_id)
    except Exception:
        try:
            raw = addon.getSettingString(setting_id)
        except Exception:
            pass

    try:
        return int(str(raw).strip())
    except Exception:
        if str(raw).strip() == "":
            return default
        xbmc.log(
            "Aegis: invalid int setting value for {}.{}={!r}; using default {}".format(
                addon.getAddonInfo("id"), setting_id, raw, default
            ),
            xbmc.LOGWARNING,
        )
        return default


def _safe_set_setting_bool(addon: xbmcaddon.Addon, setting_id: str, value: bool) -> None:
    """Set bool settings safely across Kodi schema variants."""
    string_value = "true" if value else "false"
    try:
        addon.setSetting(setting_id, string_value)
        return
    except Exception:
        pass

    try:
        addon.setSettingBool(setting_id, value)
    except Exception as exc:
        xbmc.log(
            "Aegis: failed to write bool setting {}.{}={} ({})".format(
                addon.getAddonInfo("id"), setting_id, string_value, exc
            ),
            xbmc.LOGWARNING,
        )


def _plugin_addon() -> Optional[xbmcaddon.Addon]:
    try:
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.aegis)"):
            if not inspect.isfunction(xbmcaddon.Addon):
                return None
    except Exception:
        return None
    try:
        return xbmcaddon.Addon(PLUGIN_ADDON_ID)
    except Exception:
        return None


def _umbrella_addon() -> Optional[xbmcaddon.Addon]:
    try:
        if not xbmc.getCondVisibility("System.HasAddon(plugin.video.umbrella)"):
            if not inspect.isfunction(xbmcaddon.Addon):
                return None
    except Exception:
        return None
    try:
        return xbmcaddon.Addon("plugin.video.umbrella")
    except Exception:
        return None


def _parse_curated_toml_fallback(content: str) -> List[Dict]:
    addons: List[Dict] = []
    current: Optional[Dict] = None
    key_value = re.compile(r'^(\w+)\s*=\s*"(.*)"\s*$')

    for raw_line in content.splitlines():
        line = raw_line.strip()
        if line == "[[addon]]":
            if current:
                addons.append(current)
            current = {}
            continue
        if not line or line.startswith("#") or line.startswith("["):
            continue
        if current is None:
            continue
        match = key_value.match(line)
        if match:
            current[match.group(1)] = match.group(2)

    if current:
        addons.append(current)
    return addons


def _load_toml_document(path: Path) -> dict:
    if tomllib is not None:
        with path.open("rb") as handle:
            return tomllib.load(handle)
    return {"addon": _parse_curated_toml_fallback(path.read_text(encoding="utf-8"))}


def _repository_addon_xml_path() -> Path:
    return Path(xbmcvfs.translatePath("special://home/addons/repository.aegis/addon.xml"))


def _resolve_update_manifest_urls() -> Optional[Tuple[str, str]]:
    repo_xml = _repository_addon_xml_path()
    if not repo_xml.exists():
        return None

    root = ET.parse(str(repo_xml)).getroot()
    info_url = (root.findtext(".//extension[@point='xbmc.addon.repository']/dir/info") or "").strip()
    checksum_url = (root.findtext(".//extension[@point='xbmc.addon.repository']/dir/checksum") or "").strip()
    if not info_url or not checksum_url:
        return None

    if "{REPO_BASE_URL}" in info_url or "{REPO_BASE_URL}" in checksum_url:
        return None

    return info_url, checksum_url


def _check_update_channel(vault: VaultStore) -> None:
    """Run opt-in weekly update-channel checks for repository manifest integrity."""
    try:
        plugin = _plugin_addon()
        if plugin is None:
            return
        if not _safe_get_setting_bool(plugin, "auto_update_enabled", default=False):
            return

        payload = vault.read()
        setup = payload.setdefault("setup", {})
        update_state = setup.setdefault("update_channel", {})

        now = int(time.time())
        last_checked = int(update_state.get("last_checked_at", 0) or 0)
        if last_checked and (now - last_checked) < (7 * 86400):
            return

        status = "fail"
        reason = ""

        urls = _resolve_update_manifest_urls()
        if urls is None:
            reason = "repository manifest URLs unavailable"
        else:
            info_url, checksum_url = urls
            session = GuardedSession()
            try:
                checksum_resp = session.get(checksum_url, timeout=15)
                info_resp = session.get(info_url, timeout=20)
            except Exception as exc:
                reason = "manifest fetch failed: {}".format(exc)
            else:
                if checksum_resp.status_code != 200:
                    reason = "checksum fetch failed: HTTP {}".format(checksum_resp.status_code)
                elif info_resp.status_code != 200:
                    reason = "manifest fetch failed: HTTP {}".format(info_resp.status_code)
                else:
                    expected = checksum_resp.text.strip().lower()
                    actual = hashlib.md5(info_resp.content).hexdigest()
                    if expected != actual:
                        reason = "manifest checksum mismatch"
                    else:
                        xbmc.executebuiltin("UpdateAddonRepos")
                        status = "pass"
                        reason = "manifest checksum verified"

        update_state["last_checked_at"] = now
        update_state["last_result"] = status
        update_state["last_reason"] = reason
        if status == "pass":
            update_state["last_success_at"] = now

        setup["update_channel"] = update_state
        payload["setup"] = setup
        vault.write(payload)

        if status == "fail":
            xbmcgui.Dialog().notification(
                "Aegis",
                "Update check failed: {}".format(reason),
                xbmcgui.NOTIFICATION_WARNING,
                4000,
            )
            xbmc.log("Aegis Updates: {}".format(reason), xbmc.LOGWARNING)
        else:
            xbmc.log("Aegis Updates: {}".format(reason), xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log("Aegis Updates: check failed: {}".format(exc), xbmc.LOGWARNING)


def _check_live_tv_refresh_schedule(vault: VaultStore) -> None:
    """Check and execute live-TV refresh based on schedule setting (L7 feature)."""
    try:
        plugin = _plugin_addon()
        if plugin is None:
            return
        schedule_option = _safe_get_setting_int(plugin, "live_tv_refresh_schedule", default=0)
        # 0=never, 1=weekly, 2=on_kodi_startup
        
        if schedule_option == 0:
            # Never refresh
            return
        
        # Read vault to check last refresh time
        current = vault.read()
        if "live_tv" not in current:
            current["live_tv"] = {}
        
        live_tv_data = current["live_tv"]
        last_refresh = live_tv_data.get("last_refresh_at", 0)
        now = int(time.time())
        
        # Check if refresh needed
        should_refresh = False
        if schedule_option == 1:  # Weekly
            # Refresh if more than 7 days since last refresh
            if now - last_refresh > 7 * 86400:
                should_refresh = True
        elif schedule_option == 2:  # On Kodi startup + periodic
            # The merged EPG window is EPG_WINDOW_FUTURE_HOURS forward
            # (imported from tvhub merge.py — single source of truth so
            # a future widening/tightening of the window automatically
            # keeps the refresh cadence in sync). The ticker polls every
            # _REFRESH_TICKER_SECONDS. We need the cooldown to fire
            # *before* the EPG window expires — if we only re-checked
            # at exactly the window edge the ticker could land up to
            # one tick interval late, leaving the user with empty
            # guide for that gap. Subtract one ticker interval as
            # margin (e.g. 5h30m for a 6h window + 30m ticker).
            cooldown = EPG_WINDOW_FUTURE_HOURS * 3600 - _REFRESH_TICKER_SECONDS
            if now - last_refresh >= cooldown:
                should_refresh = True
        
        if not should_refresh:
            xbmc.log("Aegis Live-TV: refresh not needed based on schedule", xbmc.LOGINFO)
            return
        
        xbmc.log("Aegis Live-TV: executing scheduled refresh", xbmc.LOGINFO)
        
        # Execute refresh (same logic as _setup_live_tv, but with result tracking)
        if SourceRegistry is None:
            xbmc.log("Aegis Live-TV: tvhub modules unavailable; skipping scheduled refresh", xbmc.LOGWARNING)
            return
        
        registry = SourceRegistry(vault)
        if not registry.get_enabled():
            xbmc.log("Aegis Live-TV: no enabled sources; skipping scheduled refresh", xbmc.LOGINFO)
            return
        
        out_dir = _tvhub_output_dir()
        out_dir.mkdir(parents=True, exist_ok=True)
        
        session = GuardedSession()
        result = merge(registry, out_dir, session)
        
        xbmc.log(
            "Aegis Live-TV: scheduled refresh complete channels={} deduped={} errors={}".format(
                result.total_channels,
                result.dedup_count,
                len(result.errors),
            ),
            xbmc.LOGINFO,
        )
        
        # Update last refresh timestamp
        live_tv_data["last_refresh_at"] = now
        live_tv_data["last_refresh_result"] = {
            "total_channels": result.total_channels,
            "dedup_count": result.dedup_count,
            "error_count": len(result.errors),
        }
        current["live_tv"] = live_tv_data
        vault.write(current)
    except Exception as exc:
        xbmc.log("Aegis Live-TV: scheduled refresh failed: {}".format(exc), xbmc.LOGWARNING)



def _vault_dir() -> Path:
    path = xbmcvfs.translatePath("special://masterprofile/aegis")
    return Path(path)


def _consent_text() -> str:
    return (
        "Aegis installs only pinned addons from a single repository. "
        "No telemetry is sent. Debrid and optional Trakt account setup occurs after consent."
    )

def _is_harness_runtime() -> bool:
    # Avoid Addon(...) lookups here because Kodi logs unknown IDs as errors.
    return bool(
        xbmc.getCondVisibility("System.HasAddon(service.aegis.harness)")
        or xbmc.getCondVisibility("System.HasAddon(service.aegis.click_through_harness)")
        or xbmc.getCondVisibility("System.HasAddon(service.aegis.live_tv_harness)")
    )


def _capture_consent(vault: VaultStore) -> bool:
    # Reuse previously persisted consent to avoid re-prompt loops in harness/headless runs.
    try:
        existing = vault.read().get("consent", {})
        if existing.get("v1_accepted_at"):
            return True
    except Exception:
        pass

    try:
        existing_setting = ""
        if hasattr(ADDON, "getSettingString"):
            existing_setting = (ADDON.getSettingString("consent_accepted_at") or "").strip()
        else:
            existing_setting = (ADDON.getSetting("consent_accepted_at") or "").strip()
        if existing_setting:
            return True
    except Exception:
        pass

    try:
        accepted = xbmcgui.Dialog().yesno("Aegis Consent", _consent_text())
    except Exception as dialog_exc:
        xbmc.log("Aegis consent dialog error (continuing anyway): {}".format(dialog_exc), xbmc.LOGWARNING)
        accepted = True

    if _is_harness_runtime():
        xbmc.log("Aegis: harness runtime detected; auto-accepting consent", xbmc.LOGINFO)
        accepted = True

    if not accepted:
        xbmc.log("Aegis first run aborted: consent not granted", xbmc.LOGWARNING)
        return False

    accepted_at = int(time.time())
    vault.upsert("consent", {"v1_accepted_at": accepted_at})
    try:
        ADDON.setSettingString(
            "consent_accepted_at",
            time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(accepted_at)),
        )
    except Exception:
        xbmc.log("Aegis: unable to persist consent timestamp in addon settings", xbmc.LOGWARNING)
    return True


def _rd_enabled() -> bool:
    plugin_addon = _plugin_addon()
    if plugin_addon is None:
        return False
    # Match the XML default from plugin.video.aegis/resources/settings.xml.
    # Kodi's addon.getSetting() returns "" (not the XML default) for settings
    # the user has never touched; without a matching code-side default a
    # never-edited fresh install reads provider_rd_enabled as False and the
    # self-heal wizard branch never fires the RD device flow.
    return _safe_get_setting_bool(plugin_addon, "provider_rd_enabled", default=True)


def _ad_enabled() -> bool:
    plugin_addon = _plugin_addon()
    if plugin_addon is None:
        return False
    # New setting id is ad_enabled; provider_ad_enabled is kept as compatibility fallback.
    return _safe_get_setting_bool(plugin_addon, "ad_enabled", default=_safe_get_setting_bool(plugin_addon, "provider_ad_enabled", default=False))


def _apply_skin() -> None:
    """First-run Step 2: activate skin.aegis. Delegates to lib/playback_defaults;
    the headless-harness guard stays here so the lib module stays dependency-free."""
    if _is_harness_runtime():
        return
    playback_defaults.apply_skin()


def _select_debrid_providers() -> None:
    """First-run Step 3: let the user pick debrid provider(s) and persist the
    enable flags into plugin.video.aegis settings, so the OAuth gates in main()
    fire for the chosen providers.

    Without this the auto-run wizard only set up whatever was enabled by default
    (RD on, AD off), so "AllDebrid setup never triggers". No-ops in a headless
    harness; a *cancelled* dialog (None) keeps existing flags so RD's default-on
    survives, while an explicit empty selection disables all (matching the
    plugin's own provider dialog)."""
    if _is_harness_runtime():
        return
    plugin_addon = _plugin_addon()
    if plugin_addon is None:
        return
    # Order MUST match the plugin's own provider dialog (plugin.video.aegis
    # default.py): Real-Debrid, Premiumize, AllDebrid -- so the two entry
    # points present identical choices.
    labels = ["Real-Debrid", "Premiumize", "AllDebrid"]
    preselect: List[int] = []
    if _rd_enabled():
        preselect.append(0)
    if _safe_get_setting_bool(plugin_addon, "provider_pm_enabled", default=False):
        preselect.append(1)
    if _ad_enabled():
        preselect.append(2)
    try:
        selected = xbmcgui.Dialog().multiselect(
            "Aegis — Debrid Providers", labels, preselect=preselect
        )
    except Exception as exc:
        xbmc.log("Aegis: provider select dialog error: {}".format(exc), xbmc.LOGWARNING)
        return
    if selected is None:
        return  # cancelled: keep existing flags (RD default-on survives)
    rd, pm, ad = 0 in selected, 1 in selected, 2 in selected
    _safe_set_setting_bool(plugin_addon, "provider_rd_enabled", rd)
    _safe_set_setting_bool(plugin_addon, "provider_ad_enabled", ad)
    _safe_set_setting_bool(plugin_addon, "ad_enabled", ad)
    _safe_set_setting_bool(plugin_addon, "provider_pm_enabled", pm)
    xbmc.log("Aegis provider selection: rd={} ad={} pm={}".format(rd, ad, pm), xbmc.LOGINFO)


def _has_rd_token(vault: VaultStore) -> bool:
    """True iff the vault holds a usable Real-Debrid token. Used by the
    self-heal branch in main() to detect that an enabled provider hasn't
    been OAuth'd yet so we re-fire the device flow."""
    try:
        rd = vault.read().get("rd", {}) if vault else {}
    except Exception:
        return False
    return bool(rd.get("refresh_token") or rd.get("access_token"))


def _has_ad_token(vault: VaultStore) -> bool:
    try:
        ad = vault.read().get("ad", {}) if vault else {}
    except Exception:
        return False
    return bool(ad.get("apikey"))


def _apply_language_defaults() -> None:
    """Default audio + subtitle language to English (one-shot). Delegates to
    lib/playback_defaults; the headless-harness guard stays here."""
    if _is_harness_runtime():
        return
    playback_defaults.apply_language_defaults()


def _ensure_advancedsettings_cache() -> None:
    """Write the streaming read-buffer advancedsettings.xml (idempotent).
    Delegates to lib/playback_defaults; the headless-harness guard stays here."""
    if _is_harness_runtime():
        return
    playback_defaults.ensure_advancedsettings_cache()


def _umbrella_settings_path() -> Path:
    profile = Path(xbmcvfs.translatePath("special://profile"))
    return profile / "addon_data" / "plugin.video.umbrella" / "settings.xml"


def _load_settings_root(path: Path) -> ET.Element:
    if path.exists():
        root = ET.parse(str(path)).getroot()
        if root.tag != "settings":
            root = ET.Element("settings")
        root.set("version", root.get("version") or "2")
        return root
    root = ET.Element("settings")
    root.set("version", "2")
    return root


def _umbrella_setting_type(setting_id: str) -> str:
    if setting_id in {UMBRELLA_RD_ENABLE_KEY, UMBRELLA_AD_ENABLE_KEY}:
        return "boolean"
    return "string"


def _get_setting_node(root: ET.Element, setting_id: str) -> ET.Element:
    for node in root.findall("setting"):
        if node.get("id") == setting_id:
            current = (node.get("type") or "").strip().lower()
            if current == "bool":
                node.set("type", "boolean")
            elif not current:
                node.set("type", _umbrella_setting_type(setting_id))
            return node
    node = ET.SubElement(root, "setting")
    node.set("id", setting_id)
    node.set("type", _umbrella_setting_type(setting_id))
    return node


def _write_settings(path: Path, root: ET.Element) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(str(path), encoding="utf-8", xml_declaration=True)


def _sync_umbrella_rd_settings(vault: VaultStore, rd_enabled: bool) -> None:
    umbrella_sync.sync_umbrella_rd_settings(
        vault, rd_enabled,
        umbrella_addon=_umbrella_addon, safe_set_bool=_safe_set_setting_bool)


def _sync_umbrella_ad_settings(vault: VaultStore, ad_enabled: bool) -> None:
    umbrella_sync.sync_umbrella_ad_settings(
        vault, ad_enabled,
        umbrella_addon=_umbrella_addon, safe_set_bool=_safe_set_setting_bool)


def _sync_umbrella_external_provider() -> None:
    umbrella_sync.sync_umbrella_external_provider(
        umbrella_addon=_umbrella_addon,
        ensure_addon_installed=_ensure_kodi_addon_installed,
        safe_set_bool=_safe_set_setting_bool)


def _sync_umbrella_silent_defaults() -> None:
    umbrella_sync.sync_umbrella_silent_defaults(
        umbrella_addon=_umbrella_addon,
        safe_get_bool=_safe_get_setting_bool, safe_set_bool=_safe_set_setting_bool)


def _sync_testneto_defaults() -> None:
    umbrella_sync.sync_testneto_defaults(
        safe_get_bool=_safe_get_setting_bool, safe_set_bool=_safe_set_setting_bool)


def _refresh_rd_token_if_needed(vault: VaultStore) -> None:
    oauth.refresh_rd_token_if_needed(vault, session_factory=GuardedSession)


def _run_rd_device_flow(vault: VaultStore) -> None:
    oauth.run_rd_device_flow(vault, session_factory=GuardedSession)


def _run_ad_device_flow(vault: VaultStore) -> None:
    oauth.run_ad_device_flow(vault, session_factory=GuardedSession)


def _debrid_status_label(vault: VaultStore) -> str:
    return oauth.debrid_status_label(vault)


def _update_skin_properties(vault: VaultStore) -> None:
    """Push status strings into Kodi Home window properties for the skin chip.

    The skin reads Window(Home).Property(aegis.debrid.status) and
    Window(Home).Property(aegis.netguard.status) without executing any Python.
    """
    def _enabled(value) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "on"}
        if isinstance(value, (int, float)):
            return value != 0
        return False

    payload = {}
    try:
        payload = vault.read()
    except Exception:
        payload = {}

    rd = payload.get("rd", {}) if isinstance(payload, dict) else {}
    tv_data = {}
    if isinstance(payload, dict):
        tv_data = payload.get("tv", {}) or payload.get("live_tv", {}) or {}

    home = xbmcgui.Window(10000)
    home.setProperty("aegis.debrid.status", _debrid_status_label(vault))
    home.setProperty("aegis.netguard.status", "HTTPS-only \u2713")
    home.setProperty("aegis.rd.configured", "1" if bool(rd.get("refresh_token") or rd.get("access_token")) else "")
    home.setProperty("aegis.livetv.enabled", "1" if _enabled(tv_data.get("enabled")) else "")
    home.setProperty("aegis.gaming.enabled", "1" if xbmc.getCondVisibility("System.HasAddon(plugin.program.iagl)") else "")
    trakt = payload.get("trakt", {}) if isinstance(payload, dict) else {}
    home.setProperty("aegis.trakt.linked", "1" if trakt.get("access_token") else "")


def _setup_remote_control(vault: VaultStore) -> None:
    """Configure optional authenticated remote control (step 0) via JSON-RPC on port 8080."""
    # Keep signature minimal for Kodi 21 compatibility across wrappers.
    enable_remote = xbmcgui.Dialog().yesno(
        "Aegis — Remote Control",
        "Enable remote control via JSON-RPC on port 8080?\n\nYou can control Kodi from external apps.",
    )
    
    if not enable_remote:
        # Clear remote control settings if they existed
        try:
            current = vault.read()
            current.pop("remote_control", None)
            vault.write(current)
        except Exception:
            pass
        return
    
    # Generate random 16-char password (≈90 bits entropy from urlsafe base64)
    password = secrets.token_urlsafe(12)
    
    # Apply Kodi settings via executebuiltin
    settings_cmds = [
        "SetSettingValue(services.webserver, true)",
        "SetSettingValue(services.webserverusername, kodi)",
        f"SetSettingValue(services.webserverpassword, {password})",
        "SetSettingValue(services.webserverssl, false)",
        "SetSettingValue(services.zeroconf, true)",
        "SetSettingValue(services.airplay, false)",
        "SetSettingValue(services.upnp, false)",
        "SetSettingValue(services.devicecontroller, false)",
    ]
    
    for cmd in settings_cmds:
        try:
            xbmc.executebuiltin(cmd)
        except Exception as exc:
            xbmc.log(f"Failed to apply remote control setting: {cmd}. Error: {exc}", xbmc.LOGWARNING)
    
    # Store credentials in vault
    try:
        current = vault.read()
        if "setup" not in current:
            current["setup"] = {}
        current["setup"]["remote_control"] = {
            "username": "kodi",
            "password": password,
            "port": 8080,
            "enabled_at": int(time.time()),
        }
        vault.write(current)
        xbmc.log("Aegis: Remote control configured on port 8080", xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log(f"Failed to record remote control credentials in vault: {exc}", xbmc.LOGERROR)
    
    xbmcgui.Dialog().notification(
        "Aegis",
        "Remote control enabled on port 8080. Use kodi:<password>@<hostname>:8080",
        xbmcgui.NOTIFICATION_INFO,
        5000,
    )


def _load_curated_addons() -> List[Dict]:
    """Load the curated addons allowlist from curated.toml."""
    try:
        addon_path = xbmcvfs.translatePath("special://home/addons/plugin.video.aegis")
        curated_path = Path(addon_path) / "resources" / "defaults" / "curated.toml"
        
        if not curated_path.exists():
            xbmc.log("Curated addons file not found: {}".format(curated_path), xbmc.LOGWARNING)
            return []
        
        data = _load_toml_document(curated_path)
        
        return data.get("addon", [])
    except Exception as exc:
        xbmc.log("Failed to load curated addons: {}".format(exc), xbmc.LOGERROR)
        return []


def _install_curated_addons(vault: VaultStore) -> None:
    """Offer user to install curated addons from official Kodi repository (step 7)."""
    addons = _load_curated_addons()
    if not addons:
        return
    
    # Build list for multiselect dialog
    addon_labels = [addon.get("label", addon.get("id")) for addon in addons]
    addon_ids = [addon.get("id") for addon in addons]
    
    selected_indices = xbmcgui.Dialog().multiselect(
        "Aegis — Curated Free Content",
        addon_labels,
        preselect=[],  # None selected by default
    )
    
    if selected_indices is None or not selected_indices:
        # User canceled or didn't select anything
        return
    
    selected_ids = [addon_ids[i] for i in selected_indices]
    
    # Store selection in vault
    try:
        current = vault.read()
        if "setup" not in current:
            current["setup"] = {}
        current["setup"]["curated_installed"] = selected_ids
        vault.write(current)
    except Exception as exc:
        xbmc.log("Failed to record curated selection in vault: {}".format(exc), xbmc.LOGWARNING)
    
    # Install each selected addon via Kodi RPC
    for addon_id in selected_ids:
        try:
            xbmc.executebuiltin(f"InstallAddon({addon_id})")
            xbmc.log("Aegis: Installed curated addon {}".format(addon_id), xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log("Failed to install curated addon {}: {}".format(addon_id, exc), xbmc.LOGERROR)
    
    xbmcgui.Dialog().notification(
        "Aegis",
        "Curated addons installation started.",
        xbmcgui.NOTIFICATION_INFO,
        3000,
    )


def _tvhub_output_dir() -> Path:
    return pvr_setup.tvhub_output_dir()


def _pvr_iptvsimple_settings_ids() -> Optional[Dict[str, str]]:
    return pvr_setup.pvr_iptvsimple_settings_ids()


def _ensure_kodi_addon_installed(addon_id: str, timeout_seconds: int = 60) -> bool:
    """Install a Kodi addon from the official repo if not already present.

    Used for pvr.iptvsimple and its declared inputstream dependencies
    (inputstream.ffmpegdirect, inputstream.rtmp). pvr.iptvsimple's
    addon.xml declares these as required but Kodi only warns at startup
    when they're missing — it then loads the addon anyway, and crashes
    later when a code path tries to dispatch to the missing inputstream.
    Installing them up front closes that crash window.
    """
    cond = "System.HasAddon({})".format(addon_id)
    if xbmc.getCondVisibility(cond):
        return True
    xbmc.executebuiltin("InstallAddon({})".format(addon_id))
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if xbmc.getCondVisibility(cond):
            return True
        # xbmc.sleep is abort-aware: Kodi shutdown returns immediately
        # instead of holding the service thread for the full poll
        # interval. With dep install layered on top of pvr.iptvsimple
        # this loop can run 3× — up to 3 × timeout_seconds of blocking
        # if every install hangs. Matches the plugin's mirror helper.
        xbmc.sleep(1000)
    return False


def _ensure_pvr_iptvsimple_installed(timeout_seconds: int = 60) -> bool:
    return pvr_setup.ensure_pvr_iptvsimple_installed(
        ensure_addon_installed=_ensure_kodi_addon_installed, timeout_seconds=timeout_seconds)


def _secure_wipe_file(path: Path) -> None:
    pvr_setup.secure_wipe_file(path)


def _wipe_then_clear_setting(addon, setting_id: str) -> None:
    pvr_setup.wipe_then_clear_setting(addon, setting_id)


def _disable_live_tv_paths() -> None:
    pvr_setup.disable_live_tv_paths()


def _validate_custom_url(session: GuardedSession, url: str) -> bool:
    return pvr_setup.validate_custom_url(session, url)


def _select_regions_and_populate_sources(vault: VaultStore) -> None:
    """Show region selection dialog and populate SourceRegistry (L6 feature)."""
    if SourceRegistry is None or get_iptv_org_sources is None or IPTV_ORG_REGION_LABELS is None:
        xbmc.log("Aegis Live-TV: tvhub modules unavailable; skipping region selection", xbmc.LOGINFO)
        return

    registry = SourceRegistry(vault)
    
    # Multi-select dialog for regions
    region_keys = sorted(IPTV_ORG_REGION_LABELS.keys())
    region_labels = [IPTV_ORG_REGION_LABELS[k] for k in region_keys]
    
    dialog = xbmcgui.Dialog()
    selected_indices = dialog.multiselect(
        "Aegis — Select Live-TV Regions",
        region_labels,
        preselect=[]  # No default pre-selection
    )
    
    if selected_indices is None:
        # User cancelled
        xbmc.log("Aegis Live-TV: region selection cancelled", xbmc.LOGINFO)
        return
    
    selected_regions = [region_keys[i] for i in selected_indices]
    xbmc.log("Aegis Live-TV: selected regions: {}".format(selected_regions), xbmc.LOGINFO)
    
    # Add selected iptv-org sources to registry
    for source_dict in get_iptv_org_sources(selected_regions):
        try:
            registry.upsert(Source(**source_dict))
        except Exception as exc:
            xbmc.log("Aegis Live-TV: failed adding region source: {}".format(exc), xbmc.LOGWARNING)

    # Add FAST channel sources (Pluto TV / Samsung TV+ / Plex / Roku / Tubi via
    # BuddyChewChew CI + jmp2.uk JWT-minting redirectors). These dedup-win over
    # iptv-org's rebroadcasters for channels that exist in both, and bring the
    # working-stream rate from ~50% to ~95%.
    if get_fast_sources is not None:
        for source_dict in get_fast_sources(selected_regions):
            try:
                registry.upsert(Source(**source_dict))
            except Exception as exc:
                xbmc.log("Aegis Live-TV: failed adding FAST source: {}".format(exc), xbmc.LOGWARNING)

    # Always pull iptv-org's curated sports category playlist (region-agnostic).
    # This gives sports breadth that the per-region pulls miss — e.g. niche
    # international sports networks tagged sports there but absent from US/UK
    # streams. Dedup folds sports channels that also exist in FAST/region pulls.
    if get_iptv_org_category_sources is not None:
        for source_dict in get_iptv_org_category_sources(["sports"]):
            try:
                registry.upsert(Source(**source_dict))
            except Exception as exc:
                xbmc.log(
                    "Aegis Live-TV: failed adding iptv-org category source: {}".format(exc),
                    xbmc.LOGWARNING,
                )

    # Optional: custom m3u URL
    if dialog.yesno(
        "Aegis — Custom Live-TV Source",
        "Add a custom m3u or m3u8 URL?\n\nThis will be checked for accessibility.",
    ):
        custom_url = dialog.input(
            "Aegis — Enter Custom Live-TV URL",
            "https://",
            xbmcgui.INPUT_ALPHANUM,
        )
        if custom_url and custom_url != "https://":
            session = GuardedSession()
            if _validate_custom_url(session, custom_url):
                try:
                    custom_source = Source(
                        id="custom-m3u",
                        kind="url_m3u",
                        url=custom_url,
                        enabled=True,
                        priority=40
                    )
                    registry.upsert(custom_source)
                    xbmc.log("Aegis Live-TV: added custom source", xbmc.LOGINFO)
                except Exception as exc:
                    xbmc.log("Aegis Live-TV: failed adding custom source: {}".format(exc), xbmc.LOGWARNING)
            else:
                dialog.notification(
                    "Aegis",
                    "Custom URL unreachable. Skipping.",
                    xbmcgui.NOTIFICATION_WARNING,
                    5000
                )
    
    # Optional: add Famelack
    if dialog.yesno(
        "Aegis — Famelack Live-TV",
        "Enable Famelack Family Pack?\n\nHighly curated, but smaller channel set.",
    ):
        try:
            famelack_source = Source(
                id="famelack-family-pack",
                kind="url_m3u",
                url="https://raw.githubusercontent.com/Famelack/iptv/master/famelack-family-pack.m3u",
                enabled=True,
                priority=20
            )
            registry.upsert(famelack_source)
            xbmc.log("Aegis Live-TV: added Famelack source", xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log("Aegis Live-TV: failed adding Famelack: {}".format(exc), xbmc.LOGWARNING)
    
    # Store selection in vault for reference
    try:
        current = vault.read()
        if "live_tv" not in current:
            current["live_tv"] = {}
        current["live_tv"]["selected_regions"] = selected_regions
        vault.write(current)
    except Exception as exc:
        xbmc.log("Aegis Live-TV: failed to store region selection in vault: {}".format(exc), xbmc.LOGWARNING)


def _setup_live_tv(vault: VaultStore, enabled: bool = True) -> None:
    try:
        current = vault.read()
        if "tv" not in current:
            current["tv"] = {}
        current["tv"]["enabled"] = bool(enabled)
        vault.write(current)
    except Exception as exc:
        xbmc.log("Aegis Live-TV: failed to persist tv.enabled in vault: {}".format(exc), xbmc.LOGWARNING)

    if not enabled:
        _disable_live_tv_paths()
        return

    if merge is None or SourceRegistry is None:
        xbmc.log("Aegis Live-TV: tvhub modules unavailable in sys.path", xbmc.LOGWARNING)
        return

    registry = SourceRegistry(vault)

    # Reconcile FAST sources on every setup pass: derive from whatever regions
    # the user originally selected so this auto-heals installs that pre-date the
    # FAST integration. Idempotent — upsert replaces by id.
    if get_fast_sources is not None and Source is not None:
        try:
            stored = vault.read()
            selected_regions = (stored.get("live_tv") or {}).get("selected_regions") or []
            for source_dict in get_fast_sources(selected_regions):
                try:
                    registry.upsert(Source(**source_dict))
                except Exception as exc:
                    xbmc.log("Aegis Live-TV: failed reconciling FAST source: {}".format(exc), xbmc.LOGWARNING)
        except Exception as exc:
            xbmc.log("Aegis Live-TV: FAST reconcile pass failed: {}".format(exc), xbmc.LOGWARNING)

    # Reconcile the iptv-org sports category source on every setup pass.
    # Region-agnostic, so it works for installs that haven't picked regions yet.
    if get_iptv_org_category_sources is not None and Source is not None:
        try:
            for source_dict in get_iptv_org_category_sources(["sports"]):
                try:
                    registry.upsert(Source(**source_dict))
                except Exception as exc:
                    xbmc.log(
                        "Aegis Live-TV: failed reconciling iptv-org category source: {}".format(exc),
                        xbmc.LOGWARNING,
                    )
        except Exception as exc:
            xbmc.log("Aegis Live-TV: iptv-org category reconcile pass failed: {}".format(exc), xbmc.LOGWARNING)

    if not registry.get_enabled():
        xbmc.log("Aegis Live-TV: no enabled sources in tv.sources; skipping", xbmc.LOGINFO)
        return

    if not _ensure_pvr_iptvsimple_installed():
        xbmc.log("Aegis Live-TV: pvr.iptvsimple install timed out", xbmc.LOGWARNING)
        return

    ids = _pvr_iptvsimple_settings_ids()
    if not ids:
        xbmc.log("Aegis Live-TV: aborting due to unresolved pvr.iptvsimple setting ids", xbmc.LOGWARNING)
        return

    out_dir = _tvhub_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)

    session = GuardedSession()
    result = merge(registry, out_dir, session)
    xbmc.log(
        "Aegis Live-TV: merge result channels={} deduped={} errors={}".format(
            result.total_channels,
            result.dedup_count,
            len(result.errors),
        ),
        xbmc.LOGINFO,
    )

    # Record the merge timestamp so the periodic ticker (schedule==2)
    # doesn't immediately re-merge on its first wake. Without this,
    # last_refresh_at stays at 0 and the cooldown check
    # (now - last_refresh >= 5h30m) trivially passes on the first
    # 30-minute tick, costing the user an unnecessary full merge ~30
    # minutes after firstrun completed.
    try:
        snapshot = vault.read()
        live_tv_data = snapshot.setdefault("live_tv", {})
        live_tv_data["last_refresh_at"] = int(time.time())
        live_tv_data["last_refresh_result"] = {
            "total_channels": result.total_channels,
            "dedup_count": result.dedup_count,
            "error_count": len(result.errors),
        }
        vault.write(snapshot)
    except Exception as exc:
        xbmc.log(
            "Aegis Live-TV: failed recording initial last_refresh_at: {}".format(exc),
            xbmc.LOGWARNING,
        )

    pvr = xbmcaddon.Addon("pvr.iptvsimple")
    pvr.setSetting(ids["m3uPathType"], "0")
    pvr.setSetting(ids["m3uPath"], str(out_dir / "merged.m3u"))
    pvr.setSetting(ids["epgPathType"], "0")
    pvr.setSetting(ids["epgPath"], str(out_dir / "merged-epg.xml"))
    pvr.setSetting(ids["m3uRefreshMode"], "0")

    # Kodi 21's pvr.iptvsimple v21+ uses per-instance settings stored in
    # `userdata/addon_data/pvr.iptvsimple/instance-settings-*.xml`. setSetting()
    # above only writes the base addon settings.xml; if an instance file is
    # present, mirror our values there too so the PVR client actually picks
    # them up. Without this, the merge runs successfully but pvr.iptvsimple
    # reports "no channels available" because its instance config is empty.
    _mirror_paths_to_pvr_instance_settings(
        m3u_path=str(out_dir / "merged.m3u"),
        epg_path=str(out_dir / "merged-epg.xml"),
    )


def _mirror_paths_to_pvr_instance_settings(m3u_path: str, epg_path: str) -> None:
    pvr_setup.mirror_paths_to_pvr_instance_settings(m3u_path, epg_path)


# Where Windows writes per-process minidumps when an app fast-fails.
# Linux Kodi doesn't use this path so the detector silently no-ops there
# (Path.glob on a non-existent dir yields an empty iterator). Keeping the
# constant module-level so tests can monkeypatch it.
_WINDOWS_CRASHDUMPS_DIR = Path(os.environ.get("LOCALAPPDATA", "")) / "CrashDumps" if os.environ.get("LOCALAPPDATA") else None


def _scan_recent_kodi_crashes(vault: VaultStore, *, max_age_hours: int = 48) -> List[Dict]:
    return crashdetect.scan_recent_kodi_crashes(
        vault, _WINDOWS_CRASHDUMPS_DIR, max_age_hours=max_age_hours)


def _detect_unclean_previous_exit(vault: VaultStore) -> Optional[Dict]:
    return crashdetect.detect_unclean_previous_exit(vault)


def _surface_unclean_previous_exit(record: Optional[Dict]) -> None:
    crashdetect.surface_unclean_previous_exit(record)


def _mark_monitor_active(vault: VaultStore, active: bool) -> None:
    crashdetect.mark_monitor_active(vault, active)


def _surface_recent_crashes(crashes: List[Dict]) -> None:
    crashdetect.surface_recent_crashes(crashes)


def main() -> None:
    vault = VaultStore(_vault_dir())

    # Crash detection runs first so the user sees the toast / log message
    # within seconds of Kodi finishing its skin load, not buried 30s into
    # the firstrun flow. Cheap (one directory scan, one vault read+write).
    #
    # Two independent detectors:
    #   1. Windows minidump scan (%LOCALAPPDATA%\CrashDumps) — precise, but
    #      Windows-only.
    #   2. Cross-platform heartbeat flag — catches Android/Fire OS crashes and
    #      kills where no app-readable dump exists (tombstones are root-only).
    try:
        crashes = _scan_recent_kodi_crashes(vault)
        _surface_recent_crashes(crashes)
    except Exception as exc:
        xbmc.log("Aegis: crash-detect failed: {}".format(exc), xbmc.LOGWARNING)

    try:
        unclean = _detect_unclean_previous_exit(vault)
        _surface_unclean_previous_exit(unclean)
    except Exception as exc:
        xbmc.log("Aegis: unclean-exit detect failed: {}".format(exc), xbmc.LOGWARNING)

    # L7: Check live-TV refresh schedule (runs independently from firstrun flow)
    _check_live_tv_refresh_schedule(vault)
    _check_update_channel(vault)

    try:
        _sync_umbrella_rd_settings(vault, _rd_enabled())
    except Exception as exc:
        xbmc.log("Aegis Umbrella token sync failed: {}".format(exc), xbmc.LOGWARNING)

    try:
        _sync_umbrella_ad_settings(vault, _ad_enabled())
    except Exception as exc:
        xbmc.log("Aegis Umbrella AD sync failed: {}".format(exc), xbmc.LOGWARNING)

    # Reconcile umbrella's external_provider wiring on every service start so
    # installs that pre-date testneto auto-heal once the addon lands.
    try:
        _sync_umbrella_external_provider()
    except Exception as exc:
        xbmc.log("Aegis Umbrella external_provider sync failed: {}".format(exc), xbmc.LOGWARNING)

    try:
        _sync_umbrella_silent_defaults()
    except Exception as exc:
        xbmc.log("Aegis Umbrella silent defaults sync failed: {}".format(exc), xbmc.LOGWARNING)

    try:
        _sync_testneto_defaults()
    except Exception as exc:
        xbmc.log("Aegis testneto defaults sync failed: {}".format(exc), xbmc.LOGWARNING)

    # Playback resilience defaults (both idempotent / one-shot-guarded, so they
    # run every start but only act once and never override a later user choice):
    #  - English audio+subtitle language (fixes foreign-audio-on-multitrack)
    #  - a streaming read-buffer config in advancedsettings.xml (fixes buffering)
    try:
        _apply_language_defaults()
    except Exception as exc:
        xbmc.log("Aegis language defaults failed: {}".format(exc), xbmc.LOGWARNING)

    try:
        _ensure_advancedsettings_cache()
    except Exception as exc:
        xbmc.log("Aegis advancedsettings cache failed: {}".format(exc), xbmc.LOGWARNING)

    _refresh_rd_token_if_needed(vault)
    _update_skin_properties(vault)

    # Self-heal: even when firstrun_complete is True, re-fire the OAuth flow
    # for any debrid provider that's enabled in plugin.video.aegis settings
    # but missing its token in the vault. This covers three real-world cases:
    #   1. User enabled RD/AD AFTER initial firstrun completed.
    #   2. Initial firstrun set firstrun_complete=True before reaching OAuth
    #      because the providers weren't enabled at the time (or the dialogs
    #      were speed-dismissed by the Fire TV remote).
    #   3. Vault was wiped (tamper detection, format migration) so tokens
    #      need to be re-acquired even though the addon-side flag survives.
    # Without this branch the user is stuck unless they manually flip
    # firstrun_complete in the addon settings, and that toggle isn't always
    # discoverable from the Kodi UI on every platform (Fire OS in particular).
    firstrun_done = _safe_get_setting_bool(ADDON, "firstrun_complete", default=False)
    rd_enabled = _rd_enabled()
    ad_enabled = _ad_enabled()
    rd_has_token = _has_rd_token(vault)
    ad_has_token = _has_ad_token(vault)
    rd_needs_oauth = rd_enabled and not rd_has_token
    ad_needs_oauth = ad_enabled and not ad_has_token

    xbmc.log(
        "Aegis firstrun gate: firstrun_done={} rd_enabled={} rd_has_token={} "
        "ad_enabled={} ad_has_token={}".format(
            firstrun_done, rd_enabled, rd_has_token, ad_enabled, ad_has_token
        ),
        xbmc.LOGINFO,
    )

    if firstrun_done and not (rd_needs_oauth or ad_needs_oauth):
        return

    if firstrun_done:
        xbmc.log(
            "Aegis: firstrun_complete=True but provider OAuth state missing "
            "(rd={}, ad={}); re-firing wizard".format(rd_needs_oauth, ad_needs_oauth),
            xbmc.LOGINFO,
        )

    # Step 0: Remote control setup (optional, before consent)
    _setup_remote_control(vault)

    if not _capture_consent(vault):
        return

    # Step 3: debrid provider selection, genuine first run only. Writes the
    # enable flags the OAuth gates below read; without it AllDebrid never fired.
    if not firstrun_done:
        _select_debrid_providers()

    # Debrid OAuth. A provider failure (including a user-cancelled device code)
    # is NON-FATAL: keep going so the OTHER selected provider still gets set up
    # and the skin/curated/live-TV steps still run. Previously an RD failure
    # `return`ed and silently skipped AllDebrid entirely. Track the failure and
    # leave firstrun_complete False at the end so the self-heal branch re-fires
    # only the failed provider on the next launch.
    oauth_ok = True
    if _rd_enabled():
        try:
            _run_rd_device_flow(vault)
            _sync_umbrella_rd_settings(vault, True)
        except Exception as exc:
            xbmc.log("Aegis RD OAuth setup failed: {}".format(exc), xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                "Aegis",
                "Real-Debrid setup didn't finish; will retry next launch.",
                xbmcgui.NOTIFICATION_WARNING,
                5000,
            )
            oauth_ok = False

    if _ad_enabled():
        try:
            _run_ad_device_flow(vault)
            _sync_umbrella_ad_settings(vault, True)
        except Exception as exc:
            xbmc.log("Aegis AD OAuth setup failed: {}".format(exc), xbmc.LOGERROR)
            xbmcgui.Dialog().notification(
                "Aegis",
                "AllDebrid setup didn't finish; will retry next launch.",
                xbmcgui.NOTIFICATION_WARNING,
                5000,
            )
            oauth_ok = False

    # Step 7: Offer curated addons installation (optional)
    _install_curated_addons(vault)

    # Step L6: Region selection and custom sources for live-TV
    _select_regions_and_populate_sources(vault)

    # Step 6 (L5 baseline): wire pvr.iptvsimple to merged tvhub output if sources exist.
    _setup_live_tv(vault, enabled=True)

    # Step 2 (applied LAST on purpose): switching skins reloads the whole GUI,
    # which races the wizard's own modal dialogs when done mid-flow -- the user
    # saw "many popups at once" and a stray press cancelled the RD device code.
    # Applying it after every interactive step is dialog-race-free.
    _apply_skin()

    if not oauth_ok:
        # A selected provider still needs OAuth, so DON'T mark first-run complete.
        # firstrun_done is derived solely from firstrun_complete, so the next
        # launch re-runs the full wizard path (consent is remembered via the
        # vault, but the provider/region multiselects re-prompt) and the self-heal
        # branch re-fires the failed provider's device flow. Skin, curated addons
        # and live-TV are already applied, so the retry is cheap.
        return

    xbmcgui.Dialog().notification(
        "Aegis",
        "First-run setup complete.",
        xbmcgui.NOTIFICATION_INFO,
        4000,
    )

    # Mark first-run as complete
    _safe_set_setting_bool(ADDON, "firstrun_complete", True)

    # Record completion timestamp
    try:
        current = vault.read()
        if "setup" not in current:
            current["setup"] = {}
        current["setup"]["firstrun_complete_at"] = int(time.time())
        vault.write(current)
    except Exception as e:
        xbmc.log(f"Failed to record firstrun completion in vault: {e}", xbmc.LOGWARNING)


# xbmc.Player only exists in a real Kodi runtime; tests stub `xbmc` with a
# minimal mock that doesn't include it. Fall back to `object` so the class
# can be imported (the player loop never runs under pytest anyway).
_PLAYER_BASE = getattr(xbmc, "Player", object)


class _ResumePlayerMonitor(_PLAYER_BASE):  # type: ignore[misc, valid-type]
    """Capture playback resume position for the Continue Watching widget.

    Kodi fires onPlayBackStarted with the playing item; we keep its
    title + identifiers so we can attribute the position when playback
    ends. We sample position on onPlayBackPaused and onPlayBackStopped
    rather than polling — this is enough to bucket items as 5-90%
    watched and surface them, and avoids waking the CPU during a quiet
    movie watch.

    Records go into the Aegis Vault via plugin.video.aegis.lib.library_state.
    We don't import the helper module at startup because the plugin's
    `lib` dir isn't on sys.path here; we resolve it lazily on first
    capture so a profile without plugin.video.aegis installed (e.g.
    headless live-tv-only) doesn't break the service.
    """

    def __init__(self) -> None:
        super().__init__()
        self._current: Optional[Dict[str, Any]] = None
        self._library_state = None  # lazy-imported

    def _import_helper(self):
        if self._library_state is not None:
            return self._library_state
        try:
            plugin_addon = xbmcaddon.Addon("plugin.video.aegis")
            plugin_path = xbmcvfs.translatePath(plugin_addon.getAddonInfo("path"))
            import os as _os
            import sys as _sys
            # Use os.path.join so the separator matches the host (Kodi
            # runs on Windows/macOS/Linux; translatePath returns native
            # separators, mixing in a literal "/" can confuse sys.path).
            lib_path = _os.path.join(plugin_path, "lib")
            if lib_path not in _sys.path:
                _sys.path.insert(0, lib_path)
            import library_state  # type: ignore[import-not-found]
            self._library_state = library_state
        except Exception as exc:
            xbmc.log(
                "Aegis player monitor: library_state helper unavailable: {}".format(exc),
                xbmc.LOGWARNING,
            )
            self._library_state = False  # cache the failure so we don't retry every event
        return self._library_state if self._library_state else None

    def _identify(self) -> Optional[Dict[str, Any]]:
        """Pull title / type / id from the currently playing item, if any.

        Returns None when the item isn't a movie/episode we can resume
        (live TV, music, plugin streams without metadata, etc.) so we
        don't pollute the Continue Watching list with unidentifiable
        rows.
        """
        try:
            if not self.isPlayingVideo():
                return None
        except Exception:
            return None
        try:
            video_info = self.getVideoInfoTag()
        except Exception:
            return None

        def _safe(getter, default=None):
            """Call getter() and return its value, treating only None/''
            as "missing" (returns default). Legitimate numeric 0 values
            (e.g. season=0 for TV specials) are preserved — using a
            blanket `v if v else default` would silently drop them and
            break episode identification."""
            try:
                v = getter()
            except Exception:
                return default
            if v is None or v == "":
                return default
            return v

        media_type = _safe(video_info.getMediaType, "")
        if media_type not in ("movie", "episode"):
            return None  # only movies + TV episodes feed Continue Watching

        # Prefer IMDB / TMDB / Trakt ids in that order — IMDB has the
        # widest cross-source recognition. Trakt ID is best for episode
        # sync since Trakt's playback API keys on Trakt IDs.
        #
        # For episodes specifically: Trakt's `/sync/playback/episodes`
        # response gives us the SHOW's imdb id (see
        # `_one_trakt_playback_record` — it deliberately pulls `show.ids`,
        # not `episode.ids`). To keep local and Trakt-sourced records
        # using the same `(type, id)` dedup key, we have to capture the
        # show-level imdb here too. `VideoPlayer.IMDBNumber` is Kodi's
        # active-item label and resolves to the show's imdb when an
        # episode is the active item (it's what Umbrella's resume routing
        # already uses). If it's empty we fall back to the per-uniqueID
        # lookup below — better an episode-level id than no id at all.
        unique_id = ""
        if media_type == "episode":
            try:
                show_imdb = xbmc.getInfoLabel("VideoPlayer.IMDBNumber") or ""
            except Exception:
                show_imdb = ""
            if show_imdb:
                unique_id = "imdb:{}".format(show_imdb)
        if not unique_id:
            try:
                for prefer in ("imdb", "tmdb", "trakt", "tvdb"):
                    v = video_info.getUniqueID(prefer)
                    if v:
                        unique_id = "{}:{}".format(prefer, v)
                        break
            except Exception:
                pass
        if not unique_id:
            return None  # without an id we can't reliably dedup

        return {
            "type": "movie" if media_type == "movie" else "episode",
            "id": unique_id,
            "title": _safe(video_info.getTitle, "") or "",
            "year": _safe(video_info.getYear, 0) or None,
            "show": _safe(video_info.getTVShowTitle, "") if media_type == "episode" else None,
            # Default to None (not 0) when season/episode numbering is
            # missing — otherwise we'd store season=0/episode=0 and the
            # UI would render misleading "S00E00" labels.
            "season": _safe(video_info.getSeason, None) if media_type == "episode" else None,
            "episode": _safe(video_info.getEpisode, None) if media_type == "episode" else None,
            "poster": _safe(lambda: video_info.getArt("poster"), "") or "",
        }

    def onPlayBackStarted(self) -> None:  # noqa: N802 (Kodi callback name)
        self._current = self._identify()

    def onAVStarted(self) -> None:  # noqa: N802
        # Some sources only populate metadata after AV-started — re-identify
        # if onPlayBackStarted missed the id.
        if self._current is None:
            self._current = self._identify()

    def _capture(self) -> None:
        cur = self._current
        if not cur:
            return
        try:
            pos = float(self.getTime())
            dur = float(self.getTotalTime())
        except Exception:
            return
        helper = self._import_helper()
        if helper is None:
            return
        completed = False
        # Decide the mutation up-front (no vault I/O required), then
        # apply it inside a fresh read-merge-write right before persisting
        # so concurrent writers to other subtrees (e.g. favorites
        # toggles, first-run sync) don't get stomped by stale local state.
        upsert_rec: Optional[Dict[str, Any]] = None
        drop_key: Optional[Tuple[str, str]] = None
        if helper.should_record_resume(pos, dur):
            upsert_rec = helper.make_resume_record(
                item_type=cur["type"],
                item_id=cur["id"],
                title=cur["title"],
                position_sec=pos,
                duration_sec=dur,
                poster=cur.get("poster", "") or "",
                year=cur.get("year"),
                show=cur.get("show"),
                season=cur.get("season"),
                episode=cur.get("episode"),
            )
        elif dur > 0 and pos / dur >= helper.RESUME_MAX_PERCENT:
            # Effectively complete — drop any prior partial so a finished
            # watch doesn't keep showing on Continue Watching.
            drop_key = (cur["type"], cur["id"])
            completed = True

        # Read the vault exactly once per capture. Player pause/stop
        # fires frequently — every spurious read/JSON-parse adds up. The
        # token is pulled from the same dict we'll later write through
        # apply_resume_to_vault, so a write here covers both purposes.
        # Race window: another addon path (favorites toggle, first-run
        # sync) writing the vault between our read and write would have
        # its changes stomped. The window is sub-millisecond and the
        # other writers are rare; not worth the disk I/O cost of a
        # second fresh read just for safety.
        data = None
        trakt_token = ""
        v = None
        try:
            v = VaultStore(_vault_dir())
            data = v.read()
            trakt_token = (data.get("trakt", {}) or {}).get("access_token", "") or ""
        except Exception as exc:
            xbmc.log("Aegis player monitor: vault read failed: {}".format(exc), xbmc.LOGWARNING)

        # Only touch the vault on the write side when there's an actual
        # mutation. An abort < RESUME_MIN_PERCENT on a clip with no
        # prior partial means we have nothing local to persist.
        if (upsert_rec is not None or drop_key is not None) and data is not None and v is not None:
            try:
                helper.apply_resume_to_vault(data, upsert=upsert_rec, drop=drop_key)
                v.write(data)
            except Exception as exc:
                xbmc.log("Aegis player monitor: capture failed: {}".format(exc), xbmc.LOGWARNING)
                # Even if local write failed, still try the Trakt scrobble
                # below — Trakt is independent state and shouldn't be held
                # hostage to a local I/O hiccup.

        # Best-effort Trakt scrobble sync (no-op when Trakt isn't linked).
        # Fires on every player pause/stop so cross-device state stays in
        # sync, regardless of whether the local vault was updated above —
        # Trakt scrobbles capture the playback event itself, not just the
        # ones that pass our local resume gate.
        if trakt_token:
            try:
                self._scrobble_trakt(cur, pos, dur, completed=completed, token=trakt_token)
            except Exception as exc:
                xbmc.log("Aegis player monitor: Trakt scrobble skipped: {}".format(exc), xbmc.LOGDEBUG)

    def _scrobble_trakt(
        self, cur: Dict[str, Any], pos: float, dur: float, *, completed: bool, token: str
    ) -> None:
        """POST to Trakt's scrobble API so other devices see the same
        playback state. Uses progress percent rather than absolute
        position (per Trakt's API contract). The Trakt access token is
        passed in by the caller (which already has the vault data
        loaded) rather than re-reading the vault here — that re-read
        would double the disk I/O on every pause/stop.
        """
        if GuardedSession is None or not token:
            return
        if dur <= 0:
            return
        progress_pct = max(0.0, min(100.0, (pos / dur) * 100.0))

        # Map our tagged id back to Trakt's `ids` block. Trakt supports
        # imdb/tmdb/trakt directly; tvdb only for shows/episodes.
        item_id = cur.get("id", "")
        if ":" not in item_id:
            return
        prefix, _, raw = item_id.partition(":")
        ids: Dict[str, Any] = {}
        if prefix == "imdb":
            ids["imdb"] = raw
        elif prefix in ("tmdb", "trakt", "tvdb") and raw:
            try:
                ids[prefix] = int(raw)
            except ValueError:
                return
        # Bail if the prefix wasn't one Trakt recognizes — an empty
        # `ids` block produces a 400 and wastes a request.
        if not ids:
            return

        # Pull app version from the addon's own metadata so this doesn't
        # drift from the version users see in Kodi's addon manager.
        try:
            app_version = ADDON.getAddonInfo("version") or "0.0.0"
        except Exception:
            app_version = "0.0.0"
        body: Dict[str, Any] = {"progress": progress_pct, "app_version": app_version}
        if cur["type"] == "movie":
            body["movie"] = {"title": cur.get("title", ""), "ids": ids}
            if cur.get("year"):
                body["movie"]["year"] = cur["year"]
        else:
            ep_block: Dict[str, Any] = {"ids": ids}
            if cur.get("season") is not None:
                ep_block["season"] = cur["season"]
            if cur.get("episode") is not None:
                ep_block["number"] = cur["episode"]
            body["episode"] = ep_block
            if cur.get("show"):
                body["show"] = {"title": cur["show"]}

        endpoint = "stop" if completed else "pause"
        url = "https://api.trakt.tv/scrobble/" + endpoint
        session = GuardedSession(headers={
            "trakt-api-version": "2",
            "trakt-api-key": "aegis",
        })
        session.headers["Authorization"] = "Bearer {}".format(token)
        # Tight timeout — scrobble is fire-and-forget; we shouldn't hold
        # up the user's pause/stop UX waiting for Trakt.
        session.post(url, json=body, timeout=5)

    def onPlayBackPaused(self) -> None:  # noqa: N802
        self._capture()

    def onPlayBackStopped(self) -> None:  # noqa: N802
        self._capture()
        self._current = None

    def onPlayBackEnded(self) -> None:  # noqa: N802
        # End-of-stream is a natural completion — capture handles the
        # "dropping a completed item" branch.
        self._capture()
        self._current = None



# How often the schedule-check ticker re-runs. 30 minutes is well under
# the 6h EPG window so we never miss the boundary by more than this much.
# The cooldown in _check_live_tv_refresh_schedule subtracts one of these
# from the window to compensate, so a single late tick can't leave the
# EPG empty.
_REFRESH_TICKER_SECONDS = 30 * 60


# Window property the plugin reads to discover the proxy port. Lives
# on the Kodi home window (id 10000) which all addons can access.
# Cleared on Kodi exit when the home window tears down.
_AEGIS_PROXY_PORT_PROPERTY = "aegis_proxy_port"


def _start_aegis_proxy() -> "tuple[Any, Any, int]":
    """Start the local m3u8 proxy and publish its port on the home
    window. The proxy strips SCTE-35 discontinuity tags from Samsung
    TV+ / Roku / Plex Live manifests before they reach
    inputstream.ffmpegdirect — eliminates the 1-15s decoder re-init
    stutter at every ad-break boundary.

    Returns `(server, module, port)` on success. On failure (proxy
    module unavailable, bind error, etc.) returns `(None, None, 0)`
    and logs a warning — the plugin's routing code then falls back
    to passing the upstream URL directly to ffmpegdirect (the
    pre-PR-43 behaviour, exercised by
    `test_samsung_url_falls_back_to_pipe_tail_when_proxy_is_not_running`
    in tests/test_ffmpegdirect_routing.py).

    The module reference is returned alongside the server so
    `_stop_aegis_proxy` can call `module.stop_server(server)`
    without re-importing — re-importing was fragile because it
    relied on `sys.path` still containing the proxy lib dir at
    teardown time, and on `import server` not colliding with any
    other module named `server` in the process. Caching the
    reference removes both fragility sources.
    """
    # Auto-install the proxy the first time we need it. On fresh installs it
    # isn't present (no addon declares it as a hard dependency), so without
    # this the HLS-rewrite stutter fix silently never activates — observed on
    # Firesticks where every boot logged "Unknown addon id
    # 'script.module.aegis.proxy'". _ensure_kodi_addon_installed short-circuits
    # when already installed, so steady-state boots pay no cost.
    if not _ensure_kodi_addon_installed(AEGIS_PROXY_ADDON_ID, timeout_seconds=60):
        xbmc.log(
            "Aegis proxy: {} install attempt timed out; routing will pass URLs "
            "to ffmpegdirect directly (no discontinuity stripping)".format(AEGIS_PROXY_ADDON_ID),
            xbmc.LOGWARNING,
        )
        return None, None, 0

    try:
        # Lazy import so the test harness (which stubs xbmc but not
        # this addon) doesn't choke on the proxy import path.
        plugin_addon = xbmcaddon.Addon(AEGIS_PROXY_ADDON_ID)
        proxy_path = xbmcvfs.translatePath(plugin_addon.getAddonInfo("path"))
        import os as _os
        import sys as _sys
        lib_path = _os.path.join(proxy_path, "lib")
        if lib_path not in _sys.path:
            _sys.path.insert(0, lib_path)
        import server as proxy_server  # type: ignore[import-not-found]
    except Exception as exc:
        xbmc.log(
            "Aegis proxy: import failed, routing will pass URLs to ffmpegdirect directly: {}".format(exc),
            xbmc.LOGWARNING,
        )
        return None, None, 0

    try:
        server, port = proxy_server.start_server()
    except Exception as exc:
        xbmc.log(
            "Aegis proxy: bind/start failed, falling back to direct routing: {}".format(exc),
            xbmc.LOGWARNING,
        )
        return None, None, 0

    try:
        xbmcgui.Window(10000).setProperty(_AEGIS_PROXY_PORT_PROPERTY, str(port))
    except Exception as exc:
        xbmc.log(
            "Aegis proxy: failed to publish port to home window: {}".format(exc),
            xbmc.LOGWARNING,
        )
    xbmc.log(
        "Aegis proxy: serving HLS rewrite on 127.0.0.1:{}".format(port),
        xbmc.LOGINFO,
    )
    return server, proxy_server, port


def _stop_aegis_proxy(server, proxy_module) -> None:
    """Tell the proxy server to stop + clear the published port. Best
    effort — Kodi is tearing down anyway.

    `proxy_module` is the `server` module reference returned by
    `_start_aegis_proxy`. Both args are None when start_server
    failed; the early-return makes the no-op path explicit.
    """
    if server is None or proxy_module is None:
        return
    try:
        proxy_module.stop_server(server)
    except Exception as exc:
        xbmc.log(
            "Aegis proxy: shutdown failed (Kodi exiting anyway): {}".format(exc),
            xbmc.LOGWARNING,
        )
    try:
        xbmcgui.Window(10000).clearProperty(_AEGIS_PROXY_PORT_PROPERTY)
    except Exception:
        pass


def _run_player_monitor() -> None:
    """Combined long-running loop: holds the Continue Watching Player
    monitor alive AND drives the periodic live-TV schedule check.

    Both jobs need a persistent presence in the service process — the
    Player binding so Kodi can dispatch onPlayBack* callbacks to the
    `_ResumePlayerMonitor` instance, the schedule check so users who
    keep Kodi open across the EPG window expiry get their guide
    refreshed before it drains. We share a single Monitor.waitForAbort
    loop instead of fighting for which fn gets to block main thread.

    Tick interval is _REFRESH_TICKER_SECONDS (~30 min). The Player's
    callbacks fire asynchronously from Kodi's player thread regardless
    of how often this loop wakes; the interval only matters for the
    schedule-check cadence.

    The Aegis HLS proxy is also started here (and torn down when this
    loop returns) so its lifetime tracks the service process.
    """
    monitor = xbmc.Monitor()
    player = _ResumePlayerMonitor()  # noqa: F841 — kept alive for Kodi callbacks
    proxy_server, proxy_module, _proxy_port = _start_aegis_proxy()

    # Arm the cross-platform crash heartbeat. The matching disarm is in the
    # finally below, which runs on a clean Monitor abort but is skipped if the
    # process dies hard — leaving the flag armed for next boot to detect.
    try:
        _mark_monitor_active(VaultStore(_vault_dir()), True)
    except Exception as exc:
        xbmc.log("Aegis: failed to arm crash heartbeat: {}".format(exc), xbmc.LOGWARNING)

    try:
        while not monitor.waitForAbort(_REFRESH_TICKER_SECONDS):
            # Re-read the schedule on each wake so a user who switches
            # from "Never"/"Weekly" → "On Kodi startup + every few hours"
            # via Settings during a Kodi session sees the change take
            # effect on the next tick instead of having to restart Kodi.
            # The read is cheap (one xbmcaddon getSetting call) and runs
            # at most once per 30-min tick.
            plugin = _plugin_addon()
            schedule_option = (
                _safe_get_setting_int(plugin, "live_tv_refresh_schedule", default=0)
                if plugin is not None else 0
            )
            # Schedule 0 ("Never") and 1 ("Weekly") fire from main() at
            # Kodi launch — for weekly the once-per-launch check is enough
            # because the 7-day cooldown is much wider than any realistic
            # Kodi session. Only schedule 2 needs the periodic re-check.
            if schedule_option != 2:
                continue
            try:
                vault = VaultStore(_vault_dir())
                _check_live_tv_refresh_schedule(vault)
            except Exception as exc:
                xbmc.log(
                    "Aegis Live-TV: periodic refresh check failed: {}".format(exc),
                    xbmc.LOGWARNING,
                )
    finally:
        # Clean Monitor abort reached this finally → record a clean shutdown so
        # next boot doesn't false-report. A hard crash / OOM-kill never runs
        # this, leaving monitor_active armed (the whole point).
        try:
            _mark_monitor_active(VaultStore(_vault_dir()), False)
        except Exception as exc:
            xbmc.log("Aegis: failed to clear crash heartbeat: {}".format(exc), xbmc.LOGWARNING)
        _stop_aegis_proxy(proxy_server, proxy_module)


if __name__ == "__main__":
    main()
    # Combined player-monitor + refresh-ticker loop. Player binding kept
    # alive for Continue Watching capture; schedule check drives the
    # periodic live-TV refresh so users who keep Kodi open don't watch
    # the guide drain.
    if _safe_get_setting_bool(ADDON, "firstrun_complete", default=False):
        _run_player_monitor()