"""Live-TV orchestration: region selection + source population + PVR merge.

Extracted from service.py (behaviour-preserving). This is the tvhub-COUPLED half
of live-TV setup and the natural owner of the tvhub integration imports
(SourceRegistry/merge/Source/get_*), which is why the import block lives here now.
The tvhub-free PVR/file plumbing it drives lives in pvr_setup.py.

Decoupled from the entry point by injection: the guarded HTTP session factory and
the generic Kodi addon installer are passed in, and the vault is duck-typed. The
periodic-refresh scheduler stays in service.py (its schedule-decision logic reads
plugin settings) and reads the tvhub bindings back off this module
(livetv.SourceRegistry / livetv.merge / livetv.EPG_WINDOW_FUTURE_HOURS), so both
sides share one source of truth for those symbols — and tests patch them here.
"""
from __future__ import annotations

import time
from typing import Any, Callable

import pvr_setup
import xbmc
import xbmcaddon
import xbmcgui

try:
    from fast_sources import get_fast_sources
    from iptv_org import IPTV_ORG_REGION_LABELS, get_iptv_org_category_sources, get_iptv_org_sources
    from merge import EPG_WINDOW_FUTURE_HOURS, merge
    from sources import Source, SourceRegistry
except ImportError:
    merge = None
    Source = None
    SourceRegistry = None
    get_iptv_org_sources = None
    get_iptv_org_category_sources = None
    IPTV_ORG_REGION_LABELS = None
    get_fast_sources = None
    # Conservative fallback matching the current tvhub default. Real
    # imports above replace this when tvhub is on sys.path; this branch
    # only fires in degraded harness runs where the merge module
    # isn't reachable.
    EPG_WINDOW_FUTURE_HOURS = 6

SessionFactory = Callable[[], Any]


def select_regions_and_populate_sources(vault: Any, *, session_factory: SessionFactory) -> None:
    """Show region selection dialog and populate SourceRegistry (L6 feature)."""
    if SourceRegistry is None or get_iptv_org_sources is None or IPTV_ORG_REGION_LABELS is None:
        xbmc.log("Aegis Live-TV: tvhub modules unavailable; skipping region selection", xbmc.LOGINFO)
        return

    registry = SourceRegistry(vault)

    # Multi-select dialog for regions
    region_keys = sorted(IPTV_ORG_REGION_LABELS.keys())
    region_labels = [IPTV_ORG_REGION_LABELS[k] for k in region_keys]

    dialog = xbmcgui.Dialog()
    selected_indices = dialog.multiselect(
        "Aegis — Select Live-TV Regions",
        region_labels,
        preselect=[]  # No default pre-selection
    )

    if selected_indices is None:
        # User cancelled
        xbmc.log("Aegis Live-TV: region selection cancelled", xbmc.LOGINFO)
        return

    selected_regions = [region_keys[i] for i in selected_indices]
    xbmc.log("Aegis Live-TV: selected regions: {}".format(selected_regions), xbmc.LOGINFO)

    # Add selected iptv-org sources to registry
    for source_dict in get_iptv_org_sources(selected_regions):
        try:
            registry.upsert(Source(**source_dict))
        except Exception as exc:
            xbmc.log("Aegis Live-TV: failed adding region source: {}".format(exc), xbmc.LOGWARNING)

    # Add FAST channel sources (Pluto TV / Samsung TV+ / Plex / Roku / Tubi via
    # BuddyChewChew CI + jmp2.uk JWT-minting redirectors). These dedup-win over
    # iptv-org's rebroadcasters for channels that exist in both, and bring the
    # working-stream rate from ~50% to ~95%.
    if get_fast_sources is not None:
        for source_dict in get_fast_sources(selected_regions):
            try:
                registry.upsert(Source(**source_dict))
            except Exception as exc:
                xbmc.log("Aegis Live-TV: failed adding FAST source: {}".format(exc), xbmc.LOGWARNING)

    # Always pull iptv-org's curated sports category playlist (region-agnostic).
    # This gives sports breadth that the per-region pulls miss — e.g. niche
    # international sports networks tagged sports there but absent from US/UK
    # streams. Dedup folds sports channels that also exist in FAST/region pulls.
    if get_iptv_org_category_sources is not None:
        for source_dict in get_iptv_org_category_sources(["sports"]):
            try:
                registry.upsert(Source(**source_dict))
            except Exception as exc:
                xbmc.log(
                    "Aegis Live-TV: failed adding iptv-org category source: {}".format(exc),
                    xbmc.LOGWARNING,
                )

    # Optional: custom m3u URL
    if dialog.yesno(
        "Aegis — Custom Live-TV Source",
        "Add a custom m3u or m3u8 URL?\n\nThis will be checked for accessibility.",
    ):
        custom_url = dialog.input(
            "Aegis — Enter Custom Live-TV URL",
            "https://",
            xbmcgui.INPUT_ALPHANUM,
        )
        if custom_url and custom_url != "https://":
            session = session_factory()
            if pvr_setup.validate_custom_url(session, custom_url):
                try:
                    custom_source = Source(
                        id="custom-m3u",
                        kind="url_m3u",
                        url=custom_url,
                        enabled=True,
                        priority=40
                    )
                    registry.upsert(custom_source)
                    xbmc.log("Aegis Live-TV: added custom source", xbmc.LOGINFO)
                except Exception as exc:
                    xbmc.log("Aegis Live-TV: failed adding custom source: {}".format(exc), xbmc.LOGWARNING)
            else:
                dialog.notification(
                    "Aegis",
                    "Custom URL unreachable. Skipping.",
                    xbmcgui.NOTIFICATION_WARNING,
                    5000
                )

    # Optional: add Famelack
    if dialog.yesno(
        "Aegis — Famelack Live-TV",
        "Enable Famelack Family Pack?\n\nHighly curated, but smaller channel set.",
    ):
        try:
            famelack_source = Source(
                id="famelack-family-pack",
                kind="url_m3u",
                url="https://raw.githubusercontent.com/Famelack/iptv/master/famelack-family-pack.m3u",
                enabled=True,
                priority=20
            )
            registry.upsert(famelack_source)
            xbmc.log("Aegis Live-TV: added Famelack source", xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log("Aegis Live-TV: failed adding Famelack: {}".format(exc), xbmc.LOGWARNING)

    # Store selection in vault for reference
    try:
        current = vault.read()
        if "live_tv" not in current:
            current["live_tv"] = {}
        current["live_tv"]["selected_regions"] = selected_regions
        vault.write(current)
    except Exception as exc:
        xbmc.log("Aegis Live-TV: failed to store region selection in vault: {}".format(exc), xbmc.LOGWARNING)


def setup_live_tv(
    vault: Any,
    enabled: bool = True,
    *,
    session_factory: SessionFactory,
    ensure_addon_installed,
) -> None:
    try:
        current = vault.read()
        if "tv" not in current:
            current["tv"] = {}
        current["tv"]["enabled"] = bool(enabled)
        vault.write(current)
    except Exception as exc:
        xbmc.log("Aegis Live-TV: failed to persist tv.enabled in vault: {}".format(exc), xbmc.LOGWARNING)

    if not enabled:
        pvr_setup.disable_live_tv_paths()
        return

    if merge is None or SourceRegistry is None:
        xbmc.log("Aegis Live-TV: tvhub modules unavailable in sys.path", xbmc.LOGWARNING)
        return

    registry = SourceRegistry(vault)

    # Reconcile FAST sources on every setup pass: derive from whatever regions
    # the user originally selected so this auto-heals installs that pre-date the
    # FAST integration. Idempotent — upsert replaces by id.
    if get_fast_sources is not None and Source is not None:
        try:
            stored = vault.read()
            selected_regions = (stored.get("live_tv") or {}).get("selected_regions") or []
            for source_dict in get_fast_sources(selected_regions):
                try:
                    registry.upsert(Source(**source_dict))
                except Exception as exc:
                    xbmc.log("Aegis Live-TV: failed reconciling FAST source: {}".format(exc), xbmc.LOGWARNING)
        except Exception as exc:
            xbmc.log("Aegis Live-TV: FAST reconcile pass failed: {}".format(exc), xbmc.LOGWARNING)

    # Reconcile the iptv-org sports category source on every setup pass.
    # Region-agnostic, so it works for installs that haven't picked regions yet.
    if get_iptv_org_category_sources is not None and Source is not None:
        try:
            for source_dict in get_iptv_org_category_sources(["sports"]):
                try:
                    registry.upsert(Source(**source_dict))
                except Exception as exc:
                    xbmc.log(
                        "Aegis Live-TV: failed reconciling iptv-org category source: {}".format(exc),
                        xbmc.LOGWARNING,
                    )
        except Exception as exc:
            xbmc.log("Aegis Live-TV: iptv-org category reconcile pass failed: {}".format(exc), xbmc.LOGWARNING)

    if not registry.get_enabled():
        xbmc.log("Aegis Live-TV: no enabled sources in tv.sources; skipping", xbmc.LOGINFO)
        return

    if not pvr_setup.ensure_pvr_iptvsimple_installed(ensure_addon_installed=ensure_addon_installed):
        xbmc.log("Aegis Live-TV: pvr.iptvsimple install timed out", xbmc.LOGWARNING)
        return

    ids = pvr_setup.pvr_iptvsimple_settings_ids()
    if not ids:
        xbmc.log("Aegis Live-TV: aborting due to unresolved pvr.iptvsimple setting ids", xbmc.LOGWARNING)
        return

    out_dir = pvr_setup.tvhub_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)

    session = session_factory()
    result = merge(registry, out_dir, session)
    xbmc.log(
        "Aegis Live-TV: merge result channels={} deduped={} errors={}".format(
            result.total_channels,
            result.dedup_count,
            len(result.errors),
        ),
        xbmc.LOGINFO,
    )

    # Record the merge timestamp so the periodic ticker (schedule==2)
    # doesn't immediately re-merge on its first wake. Without this,
    # last_refresh_at stays at 0 and the cooldown check
    # (now - last_refresh >= 5h30m) trivially passes on the first
    # 30-minute tick, costing the user an unnecessary full merge ~30
    # minutes after firstrun completed.
    try:
        snapshot = vault.read()
        live_tv_data = snapshot.setdefault("live_tv", {})
        live_tv_data["last_refresh_at"] = int(time.time())
        live_tv_data["last_refresh_result"] = {
            "total_channels": result.total_channels,
            "dedup_count": result.dedup_count,
            "error_count": len(result.errors),
        }
        vault.write(snapshot)
    except Exception as exc:
        xbmc.log(
            "Aegis Live-TV: failed recording initial last_refresh_at: {}".format(exc),
            xbmc.LOGWARNING,
        )

    pvr = xbmcaddon.Addon("pvr.iptvsimple")
    pvr.setSetting(ids["m3uPathType"], "0")
    pvr.setSetting(ids["m3uPath"], str(out_dir / "merged.m3u"))
    pvr.setSetting(ids["epgPathType"], "0")
    pvr.setSetting(ids["epgPath"], str(out_dir / "merged-epg.xml"))
    pvr.setSetting(ids["m3uRefreshMode"], "0")

    # Kodi 21's pvr.iptvsimple v21+ uses per-instance settings stored in
    # `userdata/addon_data/pvr.iptvsimple/instance-settings-*.xml`. setSetting()
    # above only writes the base addon settings.xml; if an instance file is
    # present, mirror our values there too so the PVR client actually picks
    # them up. Without this, the merge runs successfully but pvr.iptvsimple
    # reports "no channels available" because its instance config is empty.
    pvr_setup.mirror_paths_to_pvr_instance_settings(
        m3u_path=str(out_dir / "merged.m3u"),
        epg_path=str(out_dir / "merged-epg.xml"),
    )
