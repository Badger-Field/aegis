"""PVR (pvr.iptvsimple) client wiring + live-TV path plumbing.

Extracted from service.py (behaviour-preserving). This is the tvhub-free half of
live-TV setup: locating/validating pvr.iptvsimple's settings, installing it and
its required inputstreams, writing/wiping the merged m3u+epg paths (base settings
and per-instance), and the custom-URL HEAD check.

Self-contained: everything here talks only to Kodi (xbmc*/files) and duck-typed
args. The one service.py collaborator it needs -- the generic addon installer --
is injected (ensure_addon_installed=). The tvhub-coupled orchestrators
(_setup_live_tv / _select_regions_and_populate_sources) stay in service.py, which
keeps thin delegators here so existing call sites + tests (which patch
service._pvr_iptvsimple_settings_ids etc. and call service._tvhub_output_dir)
are unaffected.
"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, Optional

import xbmc
import xbmcaddon
import xbmcvfs


def tvhub_output_dir() -> Path:
    return Path(xbmcvfs.translatePath("special://profile/addon_data/script.module.aegis.tvhub/"))


def pvr_iptvsimple_settings_ids() -> Optional[Dict[str, str]]:
    expected = {
        "m3uPathType": "m3uPathType",
        "m3uPath": "m3uPath",
        "epgPathType": "epgPathType",
        "epgPath": "epgPath",
        "m3uRefreshMode": "m3uRefreshMode",
    }
    # pvr.iptvsimple may be installed as a system addon (Kodi distribution),
    # under the user profile, or in a portable_data tree. Ask Kodi for the
    # canonical install path rather than guessing via special://home.
    settings_xml: Optional[Path] = None
    try:
        addon_path = xbmcaddon.Addon("pvr.iptvsimple").getAddonInfo("path")
        if addon_path:
            candidate = Path(addon_path) / "resources" / "settings.xml"
            if candidate.exists():
                settings_xml = candidate
    except Exception as exc:
        xbmc.log("Aegis Live-TV: failed locating pvr.iptvsimple via xbmcaddon: {}".format(exc), xbmc.LOGWARNING)

    if settings_xml is None:
        # Fallback path probes for older Kodi profile layouts.
        for fallback in (
            "special://home/addons/pvr.iptvsimple/resources/settings.xml",
            "special://xbmc/addons/pvr.iptvsimple/resources/settings.xml",
        ):
            candidate = Path(xbmcvfs.translatePath(fallback))
            if candidate.exists():
                settings_xml = candidate
                break

    if settings_xml is None:
        xbmc.log("Aegis Live-TV: pvr.iptvsimple settings.xml not found", xbmc.LOGWARNING)
        return None

    try:
        root = ET.parse(str(settings_xml)).getroot()
        ids = {node.get("id", "") for node in root.findall(".//setting")}
        for key in expected:
            if key not in ids:
                xbmc.log(
                    "Aegis Live-TV: expected pvr.iptvsimple setting id missing: {}".format(key),
                    xbmc.LOGWARNING,
                )
                return None
    except Exception as exc:
        xbmc.log("Aegis Live-TV: failed parsing pvr.iptvsimple settings.xml: {}".format(exc), xbmc.LOGWARNING)
        return None

    try:
        addon = xbmcaddon.Addon("pvr.iptvsimple")
        for key in expected:
            addon.getSetting(key)
    except Exception as exc:
        xbmc.log("Aegis Live-TV: pvr.iptvsimple settings probe failed: {}".format(exc), xbmc.LOGWARNING)
        return None

    return expected


def ensure_pvr_iptvsimple_installed(*, ensure_addon_installed, timeout_seconds: int = 60) -> bool:
    """Install pvr.iptvsimple AND its required inputstream dependencies.

    Why install the deps explicitly: pvr.iptvsimple's addon.xml declares
    inputstream.ffmpegdirect and inputstream.rtmp as required, but Kodi's
    InstallAddon RPC does NOT pull required dependencies automatically
    in this version (Omega/21.3) — leaving the user with a partially-
    installed PVR client that warns at every startup ("CAddonMgr:
    'inputstream.ffmpegdirect' required by 'pvr.iptvsimple' is missing")
    and then crashes during background PVR work (observed:
    FAST_FAIL_FATAL_APP_EXIT in ucrtbase!abort, ~30s after EPG load).

    Deps are treated as REQUIRED — installing pvr.iptvsimple without
    them would recreate the exact crash-prone partial-install state
    this function exists to avoid. If a dep can't install, return False
    so the caller skips PVR setup entirely; the user will see a clear
    log line + retry on next firstrun rather than a silent crash 30s
    after EPG load.

    The generic addon installer is injected (ensure_addon_installed=) so this
    module stays decoupled from service.py's entry point.
    """
    # Order matters: deps first so pvr.iptvsimple's runtime dispatch can
    # find them when it initializes.
    for dep_id in ("inputstream.ffmpegdirect", "inputstream.rtmp"):
        if not ensure_addon_installed(dep_id, timeout_seconds=timeout_seconds):
            # main() marks firstrun_complete right after _setup_live_tv
            # returns, so there's no auto-retry on next launch. Point the
            # user at the actually-actionable paths instead: install the
            # dep manually from the Kodi repo and either trigger the
            # plugin's "Refresh Now" route (which calls the parallel
            # plugin-side installer) or force-rerun firstrun from
            # Aegis settings.
            xbmc.log(
                "Aegis Live-TV: required dep {} did not install — skipping "
                "pvr.iptvsimple to avoid the missing-dep crash mode. Install "
                "the dep manually from the Kodi repository (Settings → Add-ons "
                "→ Install from repository → Kodi Add-on repository → "
                "VideoPlayer InputStream → {}), then either trigger Aegis "
                "Live-TV → Refresh Now or force-rerun first-run setup.".format(
                    dep_id, dep_id
                ),
                xbmc.LOGERROR,
            )
            return False
    return ensure_addon_installed("pvr.iptvsimple", timeout_seconds=timeout_seconds)


def secure_wipe_file(path: Path) -> None:
    if not path.exists():
        return
    try:
        original = path.read_text(encoding="utf-8", errors="ignore")
        path.write_text(" " * len(original), encoding="utf-8")
    except Exception:
        pass
    try:
        path.unlink(missing_ok=True)
    except Exception:
        pass


def wipe_then_clear_setting(addon: Any, setting_id: str) -> None:
    current = addon.getSetting(setting_id) or ""
    if current:
        addon.setSetting(setting_id, " " * len(current))
    addon.setSetting(setting_id, "")


def disable_live_tv_paths() -> None:
    if not xbmc.getCondVisibility("System.HasAddon(pvr.iptvsimple)"):
        return
    ids = pvr_iptvsimple_settings_ids()
    if not ids:
        return
    try:
        pvr = xbmcaddon.Addon("pvr.iptvsimple")
        wipe_then_clear_setting(pvr, ids["m3uPath"])
        wipe_then_clear_setting(pvr, ids["epgPath"])
    except Exception as exc:
        xbmc.log("Aegis Live-TV: failed wiping pvr.iptvsimple paths: {}".format(exc), xbmc.LOGWARNING)

    secure_wipe_file(tvhub_output_dir() / "merged.m3u")


def validate_custom_url(session: Any, url: str) -> bool:
    """Validate custom m3u URL via HEAD request."""
    try:
        resp = session.head(url, timeout=5)
        return resp.status_code == 200
    except Exception as exc:
        xbmc.log("Aegis: custom URL validation failed: {}".format(exc), xbmc.LOGINFO)
        return False


def mirror_paths_to_pvr_instance_settings(m3u_path: str, epg_path: str) -> None:
    instance_dir = Path(xbmcvfs.translatePath("special://profile/addon_data/pvr.iptvsimple/"))
    if not instance_dir.exists():
        return
    pairs = [
        ('<setting id="m3uPathType" default="true">1</setting>', '<setting id="m3uPathType">0</setting>'),
        ('<setting id="m3uPath" default="true" />', '<setting id="m3uPath">{}</setting>'.format(m3u_path)),
        ('<setting id="epgPathType" default="true">1</setting>', '<setting id="epgPathType">0</setting>'),
        ('<setting id="epgPath" default="true" />', '<setting id="epgPath">{}</setting>'.format(epg_path)),
        ('<setting id="m3uRefreshMode" default="true">0</setting>', '<setting id="m3uRefreshMode">2</setting>'),
    ]
    for inst_file in instance_dir.glob("instance-settings-*.xml"):
        try:
            text = inst_file.read_text(encoding="utf-8")
            updated = text
            for old, new in pairs:
                if old in updated:
                    updated = updated.replace(old, new, 1)
            if updated != text:
                inst_file.write_text(updated, encoding="utf-8")
                xbmc.log("Aegis Live-TV: mirrored paths into {}".format(inst_file.name), xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log(
                "Aegis Live-TV: failed mirroring instance-settings {}: {}".format(inst_file.name, exc),
                xbmc.LOGWARNING,
            )
