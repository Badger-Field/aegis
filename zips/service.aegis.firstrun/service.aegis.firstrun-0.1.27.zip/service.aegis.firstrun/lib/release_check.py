"""Is this install behind the published Aegis release?

Why this exists (2026-11-11/12): a Fire TV stick ran a three-month-old build --
old buffer settings, old debrid logic -- and every surface on it looked
current, because nothing compared what is installed with what is published.
Two different faults produce that state and both were invisible:
  - nothing newer was ever published (the 2026-09-18 merge never got a release);
  - something newer is published but Kodi's updater is not installing it.
The first is caught at the source by tools/check_release_drift.py. This module
catches the second on the device, and makes the first visible there too once a
release does land.

Read-only by design: it fetches the same public manifest Kodi's own updater
polls, compares versions, and records the result in the vault for the health
screen. It never installs, updates or refreshes anything -- Kodi owns that.

Record (vault key ``release_status``), absent = never checked:
  checked_at       last time the manifest was fetched and compared
  behind           [[addon_id, installed, published], ...]
  behind_since     {addon_id: first time it was seen behind}; this is what
                   separates "published an hour ago, Kodi installs within a
                   day" from "has been behind for a week, updates are stuck"
  compared         how many installed addons were found in the manifest
  last_attempt_at / last_error   set when a check could not be completed; the
                   last good verdict is kept, never overwritten by a failure
"""
from __future__ import annotations

import gzip
import time
import xml.etree.ElementTree as ET
from typing import Any, Callable, Dict, List, Optional

import xbmc
import xbmcaddon

VAULT_KEY = "release_status"
RECHECK_SECONDS = 24 * 3600
# Kodi's updater polls roughly daily, so an addon still behind after two days
# is not "waiting for the next poll" any more.
STUCK_SECONDS = 48 * 3600

SessionFactory = Callable[[], Any]


def version_key(version: str) -> tuple:
    """Sortable key for Kodi-style dotted versions ("0.1.9" < "0.1.10")."""
    key = []
    for part in str(version).strip().split("."):
        key.append((0, int(part), "") if part.isdigit() else (1, 0, part))
    return tuple(key)


def parse_manifest(data: bytes) -> Dict[str, str]:
    """{addon_id: version} from addons.xml, plain or gzip."""
    if data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data)
    root = ET.fromstring(data)
    return {a.get("id", ""): a.get("version", "") for a in root.iter("addon") if a.get("id")}


def installed_versions(addon_ids: Any) -> Dict[str, str]:
    """Versions of the listed addons that are actually installed here. An addon
    that is not installed is left out: optional addons are not "behind"."""
    found: Dict[str, str] = {}
    for addon_id in addon_ids:
        try:
            version = xbmcaddon.Addon(addon_id).getAddonInfo("version")
        except Exception:
            continue
        if version:
            found[addon_id] = version
    return found


def needs_check(record: Any, now: Optional[int] = None) -> bool:
    now = int(time.time()) if now is None else now
    if not isinstance(record, dict):
        return True
    try:
        last = max(int(record.get("checked_at", 0) or 0), int(record.get("last_attempt_at", 0) or 0))
    except (TypeError, ValueError):
        return True
    return now - last >= RECHECK_SECONDS


def check_release(vault: Any, *, session_factory: SessionFactory, info_url: Optional[str],
                  now: Optional[int] = None) -> Dict[str, Any]:
    """Fetch the published manifest, compare with what is installed, persist
    and return the record. Never raises."""
    now = int(time.time()) if now is None else now
    try:
        payload = vault.read()
    except Exception as exc:
        xbmc.log("Aegis release check: vault unreadable ({})".format(type(exc).__name__), xbmc.LOGWARNING)
        return {}
    if not isinstance(payload, dict):
        return {}
    previous = payload.get(VAULT_KEY)
    record: Dict[str, Any] = dict(previous) if isinstance(previous, dict) else {}

    def _failed(reason: str) -> Dict[str, Any]:
        record["last_attempt_at"] = now
        record["last_error"] = reason
        xbmc.log("Aegis release check: not completed ({})".format(reason), xbmc.LOGWARNING)
        return _persist(vault, payload, record)

    if not info_url:
        # A development build has a placeholder repository URL. That is "cannot
        # look", which must not read as "up to date".
        return _failed("no published repository configured")
    try:
        response = session_factory().get(info_url, timeout=20)
    except Exception as exc:
        # Type name only: the exception text embeds the URL.
        return _failed(type(exc).__name__)
    if response.status_code != 200:
        return _failed("HTTP {}".format(response.status_code))
    try:
        published = parse_manifest(response.content)
    except Exception:
        return _failed("unparseable manifest")
    if not published:
        return _failed("empty manifest")

    installed = installed_versions(sorted(published))
    behind: List[List[str]] = []
    for addon_id, have in sorted(installed.items()):
        want = published[addon_id]
        if version_key(have) < version_key(want):
            behind.append([addon_id, have, want])

    old_since = record.get("behind_since")
    old_since = old_since if isinstance(old_since, dict) else {}
    since: Dict[str, int] = {}
    for addon_id, _have, _want in behind:
        try:
            since[addon_id] = int(old_since.get(addon_id) or now)
        except (TypeError, ValueError):
            since[addon_id] = now

    record = {"checked_at": now, "behind": behind, "behind_since": since, "compared": len(installed)}
    xbmc.log("Aegis release check: {} installed addons compared, {} behind{}".format(
        len(installed), len(behind),
        " ({})".format(", ".join("{} {}->{}".format(*b) for b in behind)) if behind else ""),
        xbmc.LOGINFO)
    return _persist(vault, payload, record)


def _persist(vault: Any, payload: Dict[str, Any], record: Dict[str, Any]) -> Dict[str, Any]:
    payload[VAULT_KEY] = record
    try:
        vault.write(payload)
    except Exception as exc:
        xbmc.log("Aegis release check: could not persist ({})".format(type(exc).__name__), xbmc.LOGWARNING)
    return record


def stuck(record: Any, now: Optional[int] = None) -> List[str]:
    """Addon ids that have been behind the published release for longer than
    STUCK_SECONDS -- i.e. automatic updates are not doing their job."""
    now = int(time.time()) if now is None else now
    if not isinstance(record, dict):
        return []
    since = record.get("behind_since")
    if not isinstance(since, dict):
        return []
    result = []
    for entry in record.get("behind") or []:
        try:
            addon_id = entry[0]
            if now - int(since.get(addon_id, now)) >= STUCK_SECONDS:
                result.append(addon_id)
        except (TypeError, ValueError, IndexError):
            continue
    return result
