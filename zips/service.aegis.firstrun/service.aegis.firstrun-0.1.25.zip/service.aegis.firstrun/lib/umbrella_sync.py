"""Sync Aegis vault credentials + policy into the vendored umbrella / testneto.

Extracted from service.py (behaviour-preserving). Decoupled from the entry point
by dependency injection: the umbrella-addon accessor, the safe get/set-bool
helpers, and the addon-installer are all passed in, so this module never reaches
back into service.py. The thin delegators in service.py wire the real helpers.

Covers: RD/AD credential sync (through the addon API, never raw XML), external
scraper wiring, phone-home suppression (DESIGN.md §8), and the default testneto
provider set.
"""
from __future__ import annotations

from typing import Any, Callable

import xbmc
import xbmcaddon

# Vault-key → umbrella-setting-id maps for the two debrid providers. Umbrella
# stores tokens under its own setting ids; we mirror the vault's canonical keys
# into them so the scraper authenticates as the same account the wizard linked.
UMBRELLA_RD_MAP = {
    "realdebridtoken": "access_token",
    "realdebridrefresh": "refresh_token",
    "realdebrid.clientid": "client_id",
    "realdebridsecret": "client_secret",
}
UMBRELLA_RD_ENABLE_KEY = "realdebrid.enable"

UMBRELLA_AD_MAP = {
    "alldebridtoken": "apikey",
}
UMBRELLA_AD_ENABLE_KEY = "alldebrid.enable"

# Aegis-vendored external scraper for umbrella. Without an external provider,
# umbrella only finds streams in the user's own RD cloud — no new content discovery.
# See audit/passed/script.module.testneto.md for the audit + strip rationale.
UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID = "script.module.testneto"
UMBRELLA_EXTERNAL_PROVIDER_MODULE_NAME = "testneto"

# testneto providers we ensure are enabled on first run for broader fringe-content
# coverage (regional reality TV, foreign content, obscure episodes, etc.). All are
# JSON-API providers that never trigger the dangerous code paths cfscrape would
# otherwise need. Users can disable individually in testneto settings.
#
# These are deliberately the DEBRID-CACHE aggregators (Torrentio / Comet /
# MediaFusion / Torz / Zilean) rather than plain torrent-site scrapers: they
# query what's already cached across the Real-Debrid / debrid network, which
# both (a) widens coverage of thinly-seeded content like older reality-TV
# episodes and (b) resolves instantly to a playable link (already cached) instead
# of returning a magnet that then has to be cached on demand. (knaben and DMM
# used to be here too -- see TESTNETO_RETIRED_PROVIDERS for why they were
# dropped.) torrentio/zilean are already testneto-default-on but are
# listed here so the intended set is explicit and survives an upstream default
# change. sync_testneto_defaults only flips false->true, so re-listing is a
# no-op for already-enabled providers.
TESTNETO_DEFAULT_ON_PROVIDERS = (
    "torrentio",
    "zilean",
    "comet",
    "mediafusion",
    "torz",
)

# Providers we USED to force on and now switch off once. Both were measured
# dead on 2026-09-18 and were costing every scrape its full timeout:
#  - knaben: knaben.eu stopped answering (149/150 scrapes timed out; 5/5 direct
#    probes got no response in 20s).
#  - dmm: the DMM API now answers 403 "Authentication not provided", which
#    testneto surfaces as KeyError: 'results' on every scrape.
# Dropping them from the default-on list alone is NOT enough: installs that
# already ran the sync have them saved as true and would keep paying the
# timeout forever. The disable is one-shot (vault flag) so a user who turns one
# back on -- e.g. once DMM auth lands in testneto -- keeps it on.
TESTNETO_RETIRED_PROVIDERS = (
    "knaben",
    "dmm",
)


def sync_umbrella_rd_settings(
    vault: Any,
    rd_enabled: bool,
    *,
    umbrella_addon: Callable[[], Any],
    safe_set_bool: Callable[[Any, str, bool], None],
) -> None:
    """Sync RD credentials into Umbrella through addon API, not raw XML edits."""
    umbrella = umbrella_addon()
    if umbrella is None:
        return
    vault_data = vault.read()
    rd_data = vault_data.get("rd", {})

    if rd_enabled and rd_data:
        for umbrella_key, vault_key in UMBRELLA_RD_MAP.items():
            umbrella.setSetting(umbrella_key, str(rd_data.get(vault_key, "")))
        safe_set_bool(umbrella, UMBRELLA_RD_ENABLE_KEY, True)
        return

    # Wipe-on-disable for scraper-side token material.
    for umbrella_key in UMBRELLA_RD_MAP:
        current = ""
        try:
            current = umbrella.getSettingString(umbrella_key)
        except Exception:
            pass
        if current:
            try:
                umbrella.setSetting(umbrella_key, " " * len(current))
            except Exception:
                pass
        umbrella.setSetting(umbrella_key, "")

    safe_set_bool(umbrella, UMBRELLA_RD_ENABLE_KEY, False)


def sync_umbrella_ad_settings(
    vault: Any,
    ad_enabled: bool,
    *,
    umbrella_addon: Callable[[], Any],
    safe_set_bool: Callable[[Any, str, bool], None],
) -> None:
    """Sync AD credentials into Umbrella through addon API, not raw XML edits."""
    umbrella = umbrella_addon()
    if umbrella is None:
        return
    vault_data = vault.read()
    ad_data = vault_data.get("ad", {})

    if ad_enabled and ad_data:
        for umbrella_key, vault_key in UMBRELLA_AD_MAP.items():
            umbrella.setSetting(umbrella_key, str(ad_data.get(vault_key, "")))

        username = ad_data.get("username")
        if username:
            umbrella.setSetting("alldebridusername", str(username))
        if "expirynotice" in ad_data:
            safe_set_bool(umbrella, "alldebridexpirynotice", bool(ad_data.get("expirynotice")))
        if "priority" in ad_data:
            try:
                umbrella.setSetting("alldebrid.priority", str(int(ad_data.get("priority"))))
            except Exception:
                pass

        safe_set_bool(umbrella, UMBRELLA_AD_ENABLE_KEY, True)
        return

    # Wipe-on-disable for scraper-side token material.
    for umbrella_key in UMBRELLA_AD_MAP:
        current = ""
        try:
            current = umbrella.getSettingString(umbrella_key)
        except Exception:
            pass
        if current:
            try:
                umbrella.setSetting(umbrella_key, " " * len(current))
            except Exception:
                pass
        umbrella.setSetting(umbrella_key, "")

    safe_set_bool(umbrella, UMBRELLA_AD_ENABLE_KEY, False)


def sync_umbrella_external_provider(
    *,
    umbrella_addon: Callable[[], Any],
    ensure_addon_installed: Callable[..., bool],
    safe_set_bool: Callable[[Any, str, bool], None],
) -> None:
    """Configure umbrella to dispatch to script.module.testneto as its external scraper.

    Auto-installs script.module.testneto from any registered Kodi repository
    (Aegis Repository ships it) the first time the service runs. Without an
    external provider umbrella only finds streams already cached in the user's
    own RD account — no new content discovery — which historically required a
    manual install step that wasn't documented anywhere except this docstring.

    Idempotent on subsequent boots: ensure_addon_installed short-circuits
    when System.HasAddon already reports the module as installed.
    """
    umbrella = umbrella_addon()
    if umbrella is None:
        return
    if not ensure_addon_installed(UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID, timeout_seconds=60):
        xbmc.log(
            "Aegis Umbrella: {} install attempt timed out; skipping external_provider "
            "wiring (sources will be RD-cache-only until next service start)".format(
                UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID
            ),
            xbmc.LOGWARNING,
        )
        return

    try:
        umbrella.setSetting("external_provider.module", UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID)
        umbrella.setSetting("external_provider.name", UMBRELLA_EXTERNAL_PROVIDER_MODULE_NAME)
        safe_set_bool(umbrella, "provider.external.enabled", True)
        xbmc.log(
            "Aegis Umbrella: external_provider set to {} / {}".format(
                UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID, UMBRELLA_EXTERNAL_PROVIDER_MODULE_NAME
            ),
            xbmc.LOGINFO,
        )
    except Exception as exc:
        xbmc.log("Aegis Umbrella: external_provider wiring failed: {}".format(exc), xbmc.LOGWARNING)


def sync_umbrella_silent_defaults(
    *,
    umbrella_addon: Callable[[], Any],
    safe_get_bool: Callable[..., bool],
    safe_set_bool: Callable[[Any, str, bool], None],
) -> None:
    """Suppress vendored umbrella's phone-home behaviours per DESIGN.md §8.

    Per Aegis policy, vendored addons must not run their own auto-update
    notification loops or third-party update channels — updates flow only
    through repository.aegis. Set the relevant umbrella settings to false on
    every service start so users who toggle them back on in umbrella's UI
    will see them re-disabled next launch (this is intentional: the
    documented Aegis policy overrides per-addon defaults).
    """
    umbrella = umbrella_addon()
    if umbrella is None:
        return
    for key in ("general.checkAddonUpdates",):
        if safe_get_bool(umbrella, key, default=False):
            safe_set_bool(umbrella, key, False)
            xbmc.log("Aegis Umbrella: disabled {} (phone-home suppressed per DESIGN §8)".format(key), xbmc.LOGINFO)


def sync_umbrella_performance_defaults(
    *,
    umbrella_addon: Callable[[], Any],
    safe_get_bool: Callable[..., bool],
    safe_set_bool: Callable[[Any, str, bool], None],
) -> None:
    """Tune umbrella's scrape for a fast, clean family experience.

    Measured on 2026-08-02 against a live scrape (Disclosure Day, ~0.9s to
    sources) with these on:
      - preemptive.termination.{movie,tv}: stop scraping the moment enough good
        sources are in hand instead of burning the full timeout — the biggest
        time-to-play win. OFF by umbrella default.
      - remove.cam.sources: drop cam/screener junk from the results (quality).
      - scrapers.timeout: cap the slow-tail wait. Umbrella's 60s default is far
        too long when a title simply has no sources; 30s fails faster without
        losing real hits (preemptive termination already covers the has-sources
        case).

    Applied ONCE per install: the caller (service.main) gates this on a vault flag
    so it runs a single time rather than every launch — a user who later disables
    one of these keeps their choice. This function itself just sets the values
    (it flips the booleans ON and lowers the 60s timeout); the one-shot semantics
    live at the call site.
    """
    umbrella = umbrella_addon()
    if umbrella is None:
        return
    for key in ("preemptive.termination.movie", "preemptive.termination.tv", "remove.cam.sources"):
        if not safe_get_bool(umbrella, key, default=False):
            safe_set_bool(umbrella, key, True)
            xbmc.log("Aegis Umbrella: enabled {} (fast/clean scrape default)".format(key), xbmc.LOGINFO)
    try:
        if (umbrella.getSetting("scrapers.timeout") or "").strip() == "60":
            umbrella.setSetting("scrapers.timeout", "30")
            xbmc.log("Aegis Umbrella: scrapers.timeout 60 -> 30 (cap slow-tail wait)", xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log("Aegis Umbrella: failed setting scrapers.timeout: {}".format(exc), xbmc.LOGWARNING)
    # Autoplay is its own one-shot (added after the scrape defaults shipped), so a
    # later install re-runs ONLY this part without re-asserting the scrape
    # settings above. See the v2 gating in service.main.
    sync_umbrella_autoplay_default(umbrella_addon=lambda: umbrella)


def sync_umbrella_autoplay_default(*, umbrella_addon: Callable[[], Any]) -> None:
    """Flip umbrella to Netflix-style autoplay: click a movie/episode and the top
    source plays — no source-select list.

    play.mode.{movie,tv}=1 flips umbrella's default "Source Select" (0) to "Auto
    Play". Validated on-device 2026-08-02 (select -> ~6s -> fullscreen, no
    dialog). Umbrella activates it via a Home-window property set by
    control.refresh_playAction at its next init (fresh install: firstrun sets this
    before umbrella first runs; existing install: takes effect on the next Kodi
    restart). Only flips the untouched "0" default, so a user who chose a
    different play mode keeps it.
    """
    umbrella = umbrella_addon()
    if umbrella is None:
        return
    for key in ("play.mode.movie", "play.mode.tv"):
        try:
            if (umbrella.getSetting(key) or "0").strip() == "0":
                umbrella.setSetting(key, "1")
                xbmc.log("Aegis Umbrella: {} -> 1 (autoplay top source)".format(key), xbmc.LOGINFO)
        except Exception as exc:
            xbmc.log("Aegis Umbrella: failed setting {}: {}".format(key, exc), xbmc.LOGWARNING)


def retire_testneto_providers(
    *,
    safe_get_bool: Callable[..., bool],
    safe_set_bool: Callable[[Any, str, bool], None],
) -> bool:
    """Switch off TESTNETO_RETIRED_PROVIDERS. Returns True once all are off.

    Returns False when testneto is absent/unloadable or a write didn't stick,
    so the caller does NOT record the one-shot flag -- otherwise a later
    testneto install (or a transient settings failure) would find the
    retirement already "done" and the dead providers left on.
    """
    if not xbmc.getCondVisibility("System.HasAddon({})".format(UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID)):
        return False
    try:
        testneto = xbmcaddon.Addon(UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID)
    except Exception:
        return False
    all_off = True
    for provider_id in TESTNETO_RETIRED_PROVIDERS:
        key = "provider.{}".format(provider_id)
        if not safe_get_bool(testneto, key, default=False):
            continue
        safe_set_bool(testneto, key, False)
        # safe_set_bool is best-effort and reports nothing, so read back: the
        # caller records the one-shot flag on True, and a write that silently
        # failed must be retried next boot rather than leave the provider on
        # forever.
        if safe_get_bool(testneto, key, default=True):
            all_off = False
            xbmc.log("Aegis testneto: could not disable retired provider {}; will retry next start".format(provider_id), xbmc.LOGWARNING)
        else:
            xbmc.log("Aegis testneto: disabled retired provider {} (upstream dead)".format(provider_id), xbmc.LOGINFO)
    return all_off


def sync_testneto_defaults(
    *,
    safe_get_bool: Callable[..., bool],
    safe_set_bool: Callable[[Any, str, bool], None],
) -> None:
    """Enable our chosen broader-coverage providers in testneto.

    Idempotent — only flips false → true, never overrides a user-set true → false.
    """
    if not xbmc.getCondVisibility("System.HasAddon({})".format(UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID)):
        return
    try:
        testneto = xbmcaddon.Addon(UMBRELLA_EXTERNAL_PROVIDER_ADDON_ID)
    except Exception:
        return
    for provider_id in TESTNETO_DEFAULT_ON_PROVIDERS:
        key = "provider.{}".format(provider_id)
        if not safe_get_bool(testneto, key, default=False):
            safe_set_bool(testneto, key, True)
            xbmc.log("Aegis testneto: enabled provider {} (broader fringe coverage)".format(provider_id), xbmc.LOGINFO)

    # Prefer English audio at the scraper layer: drop sources whose only audio is
    # a foreign single track, and prioritise English-language results
    # (results.language already defaults to "English" in testneto). Complements
    # Kodi's locale.audiolanguage default. Idempotent false->true only, so a user
    # who turns these back off keeps them off.
    for key in ("filter.foreign.single.audio", "results.language_filter"):
        if not safe_get_bool(testneto, key, default=False):
            safe_set_bool(testneto, key, True)
            xbmc.log("Aegis testneto: enabled {} (English-audio preference)".format(key), xbmc.LOGINFO)
