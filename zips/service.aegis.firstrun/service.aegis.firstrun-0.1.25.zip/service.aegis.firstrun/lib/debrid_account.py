"""Debrid ACCOUNT probes: is the linked account actually able to play anything?

Why this exists (2026-11-11): the Real-Debrid subscription lapsed to a free
account. The OAuth token stayed perfectly valid, so every Aegis surface kept
saying "linked" / "Debrid: Active" while every playback died as an unexplained
"unplayable item". Token presence proves the login works; it says nothing about
whether the provider will resolve a link. Only the provider's own account
endpoint answers that, so we ask it.

The result is persisted in the vault under ``account_status`` so the health
route (a different addon, no shared lib) can render it without a second probe.

States, and the rule that keeps them honest:
  premium      provider confirmed a paid account
  free         provider confirmed the account is NOT premium (playback will fail)
  auth_failed  provider rejected the saved credential
  (absent)     never checked -- must never render the same as "premium"
A probe that could not reach the provider does NOT overwrite the last confirmed
state (an offline boot must not flip the chip), it only records the failed
attempt; consumers decide freshness from ``checked_at``.
"""
from __future__ import annotations

import time
from typing import Any, Callable, Dict, Optional

import xbmc

RD_USER_URL = "https://api.real-debrid.com/rest/1.0/user"
AD_USER_URL = "https://api.alldebrid.com/v4/user"
AD_AGENT = "Aegis"

STATE_PREMIUM = "premium"
STATE_FREE = "free"
STATE_AUTH_FAILED = "auth_failed"

VAULT_KEY = "account_status"

# A confirmed state older than this is treated as "unverified" by the chip:
# the service re-probes on every start and every RECHECK_SECONDS, so a record
# this old means the probes have been failing, not that nothing changed.
STALE_SECONDS = 48 * 3600
RECHECK_SECONDS = 6 * 3600
EXPIRY_WARN_DAYS = 7

SessionFactory = Callable[[], Any]


class ProbeUnreachable(Exception):
    """The provider could not be asked (network, 5xx, unparseable body)."""


def probe_rd(access_token: str, session: Any) -> Dict[str, Any]:
    """Ask Real-Debrid about the account. Returns {state, expires_at, detail};
    raises ProbeUnreachable when no verdict could be obtained."""
    try:
        response = session.get(
            RD_USER_URL,
            headers={"Authorization": "Bearer {}".format(access_token)},
            timeout=15,
        )
    except Exception as exc:
        # Type name only, and rom None: requests exceptions embed the full
        # URL (and can carry headers), so neither the text nor the chained
        # exception may reach a log line.
        raise ProbeUnreachable(type(exc).__name__) from None

    if response.status_code in (401, 403):
        return {"state": STATE_AUTH_FAILED, "expires_at": 0,
                "detail": "HTTP {}".format(response.status_code)}
    if response.status_code != 200:
        raise ProbeUnreachable("HTTP {}".format(response.status_code))
    try:
        body = response.json()
        account_type = str(body.get("type", "")).lower()
        premium_seconds = int(body.get("premium", 0) or 0)
    except Exception:
        raise ProbeUnreachable("unparseable response") from None

    # Both conditions, deliberately: `premium` is seconds of paid time left and
    # is the field that hits 0 at lapse. RD's `expiration` field is NOT used --
    # on a free account it returns now+1h, which reads as "valid for an hour".
    if account_type == "premium" and premium_seconds > 0:
        return {"state": STATE_PREMIUM,
                "expires_at": int(time.time()) + premium_seconds, "detail": ""}
    return {"state": STATE_FREE, "expires_at": 0,
            "detail": "type={}".format(account_type or "?")}


def probe_ad(apikey: str, session: Any) -> Dict[str, Any]:
    """Ask AllDebrid about the account. Same contract as probe_rd."""
    try:
        response = session.get(
            AD_USER_URL,
            params={"agent": AD_AGENT},
            headers={"Authorization": "Bearer {}".format(apikey)},
            timeout=15,
        )
    except Exception as exc:
        raise ProbeUnreachable(type(exc).__name__) from None

    if response.status_code >= 500:
        raise ProbeUnreachable("HTTP {}".format(response.status_code))
    try:
        body = response.json()
    except Exception:
        raise ProbeUnreachable("unparseable response") from None

    if body.get("status") != "success":
        code = str((body.get("error") or {}).get("code", ""))
        # AllDebrid reports a bad key as an error body (often still HTTP 200),
        # so the status code alone would read as healthy.
        if code.startswith("AUTH") or response.status_code in (401, 403):
            return {"state": STATE_AUTH_FAILED, "expires_at": 0, "detail": code or "auth"}
        raise ProbeUnreachable(code or "HTTP {}".format(response.status_code))

    user = (body.get("data") or {}).get("user") or {}
    try:
        until = int(user.get("premiumUntil", 0) or 0)
    except (TypeError, ValueError):
        until = 0
    if user.get("isPremium") and until > int(time.time()):
        return {"state": STATE_PREMIUM, "expires_at": until, "detail": ""}
    return {"state": STATE_FREE, "expires_at": 0,
            "detail": "trial" if user.get("isTrial") else ""}


def check_accounts(vault: Any, *, session_factory: SessionFactory) -> Dict[str, Dict[str, Any]]:
    """Probe every linked provider and persist the verdicts. Returns the full
    ``account_status`` mapping (possibly carrying older confirmed states for
    providers that could not be reached this time)."""
    try:
        payload = vault.read()
    except Exception as exc:
        xbmc.log("Aegis account check: vault unreadable ({})".format(type(exc).__name__),
                 xbmc.LOGWARNING)
        return {}
    if not isinstance(payload, dict):
        return {}

    existing = payload.get(VAULT_KEY)
    status: Dict[str, Dict[str, Any]] = dict(existing) if isinstance(existing, dict) else {}
    now = int(time.time())

    credentials = {
        "rd": ((payload.get("rd") or {}).get("access_token"), probe_rd),
        "ad": ((payload.get("ad") or {}).get("apikey"), probe_ad),
    }
    changed = False
    session = None
    for key, (credential, probe) in credentials.items():
        if not credential:
            # Unlinked: drop any verdict so a stale "premium" can't outlive the
            # credential it was measured with.
            if key in status:
                status.pop(key)
                changed = True
            continue
        if session is None:
            session = session_factory()
        try:
            verdict = probe(credential, session)
        except ProbeUnreachable as exc:
            record = dict(status.get(key) or {})
            record["last_attempt_at"] = now
            record["last_error"] = str(exc)
            status[key] = record
            changed = True
            xbmc.log("Aegis account check: {} unreachable ({})".format(key, exc),
                     xbmc.LOGWARNING)
            continue
        status[key] = {
            "state": verdict["state"],
            "expires_at": int(verdict.get("expires_at", 0) or 0),
            "detail": verdict.get("detail", ""),
            "checked_at": now,
        }
        changed = True
        xbmc.log(
            "Aegis account check: {} state={} days_left={}".format(
                key, verdict["state"], days_left(status[key], now)),
            xbmc.LOGINFO,
        )

    if changed:
        payload[VAULT_KEY] = status
        try:
            vault.write(payload)
        except Exception as exc:
            xbmc.log("Aegis account check: could not persist ({})".format(type(exc).__name__),
                     xbmc.LOGWARNING)
    return status


def confirmed_state(record: Optional[Dict[str, Any]], now: Optional[int] = None) -> str:
    """The provider-confirmed state if we have a fresh one, else "" (= never
    looked, or looked too long ago to trust)."""
    if not isinstance(record, dict):
        return ""
    now = int(time.time()) if now is None else now
    try:
        checked_at = int(record.get("checked_at", 0) or 0)
    except (TypeError, ValueError):
        return ""
    if not checked_at or now - checked_at > STALE_SECONDS:
        return ""
    state = str(record.get("state", ""))
    if state == STATE_PREMIUM:
        # A "premium" verdict whose paid time has since run out is no longer a
        # fact about the account; don't keep asserting it until the next probe.
        try:
            if int(record.get("expires_at", 0) or 0) <= now:
                return ""
        except (TypeError, ValueError):
            return ""
    return state


def days_left(record: Optional[Dict[str, Any]], now: Optional[int] = None) -> Optional[int]:
    if not isinstance(record, dict) or record.get("state") != STATE_PREMIUM:
        return None
    now = int(time.time()) if now is None else now
    try:
        remaining = int(record.get("expires_at", 0) or 0) - now
    except (TypeError, ValueError):
        return None
    return max(0, remaining // 86400)


def needs_recheck(status: Dict[str, Dict[str, Any]], linked: Any, now: Optional[int] = None) -> bool:
    """True when any linked provider has no verdict newer than RECHECK_SECONDS."""
    now = int(time.time()) if now is None else now
    for key in linked:
        record = status.get(key) if isinstance(status, dict) else None
        try:
            checked_at = int((record or {}).get("checked_at", 0) or 0)
        except (TypeError, ValueError):
            checked_at = 0
        if now - checked_at >= RECHECK_SECONDS:
            return True
    return False


_NAMES = {"rd": "Real-Debrid", "ad": "AllDebrid"}


def user_warning(status: Dict[str, Dict[str, Any]], now: Optional[int] = None) -> str:
    """One actionable sentence for a toast, or "" when nothing needs doing.

    Only speaks when playback is at risk: a provider that is merely non-premium
    while ANOTHER linked provider is premium stays quiet here (it is still shown
    on the health screen) so a deliberately-unused account doesn't nag on every
    launch.
    """
    now = int(time.time()) if now is None else now
    states = {k: confirmed_state(v, now) for k, v in (status or {}).items()}
    premium = [k for k, s in states.items() if s == STATE_PREMIUM]
    if premium:
        soonest = min(premium, key=lambda k: status[k].get("expires_at", 0))
        left = days_left(status[soonest], now)
        # Warn only when EVERY premium provider is inside the window.
        if left is not None and all(
                (days_left(status[k], now) or 0) <= EXPIRY_WARN_DAYS for k in premium):
            return "{} premium expires in {} day{} - renew to keep playback working".format(
                _NAMES.get(soonest, soonest), left, "" if left == 1 else "s")
        return ""
    for wanted, text in (
            (STATE_FREE, "{} account is not premium - playback will fail until it is renewed"),
            (STATE_AUTH_FAILED, "{} rejected the saved login - re-authorize in Aegis settings")):
        for key, state in states.items():
            if state == wanted:
                return text.format(_NAMES.get(key, key))
    return ""
