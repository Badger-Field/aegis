"""First-run playback defaults: skin activation + English language + cache.

Extracted from service.py (behaviour-preserving). Self-contained: the headless-
harness guard stays with the caller in service.py (these are only invoked when
not in the harness), so this module depends on nothing from the entry point.
"""
from __future__ import annotations

import json

import xbmc

# Kodi's factory-default values for the language prefs (i.e. "the user has not
# chosen"). We only set English when the current value is still one of these, so
# the default never fights a user who later picks another language.
AUDIO_LANG_FACTORY_DEFAULTS = {"mediadefault", "original", "default"}
SUB_LANG_FACTORY_DEFAULTS = {"original", "default"}

# Streaming read-buffer defaults. Kodi's default buffer is small, so a
# high-bitrate source over a marginal network re-buffers ("pausing and pausing").
#
# Kodi 21 made the cache GUI settings (Settings > Services > Caching) and those
# are authoritative: an advancedsettings.xml <cache> block is loaded and then
# ignored. The build used to write exactly that block, so the fix was inert on
# every Kodi 21 box -- measured 2026-09-18: file present with memorysize 50 MB,
# yet the player reported "Memory Size: 20 MB / Read Factor: 4.00x".
#
# (setting, Kodi factory default, our value). Only applied while the setting is
# still at the factory default, so a user's own choice always wins. Kodi holds
# ~3x memorysize in RAM: 48 MB -> ~150 MB, safe on a 1 GB Fire TV stick.
# filecache.buffermode is deliberately left alone: Kodi 21's default (4, all
# network filesystems) already buffers HTTP streams.
FILECACHE_DEFAULTS = (
    ("filecache.memorysize", 20, 48),   # MB
    ("filecache.readfactor", 400, 1000),  # x100: 4x -> 10x fill rate
)


def current_skin() -> str:
    """Return the currently-active skin addon id via JSON-RPC, or ""."""
    try:
        resp = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","id":1,"method":"Settings.GetSettingValue",'
            '"params":{"setting":"lookandfeel.skin"}}'
        )
        return str(json.loads(resp).get("result", {}).get("value", ""))
    except Exception:
        return ""


def jsonrpc_get_setting(setting_id: str):
    try:
        resp = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
            "params": {"setting": setting_id},
        }))
        return json.loads(resp).get("result", {}).get("value")
    except Exception:
        return None


def jsonrpc_set_setting(setting_id: str, value) -> bool:
    try:
        resp = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
            "params": {"setting": setting_id, "value": value},
        }))
        return json.loads(resp).get("result") is True
    except Exception:
        return False


def apply_skin() -> None:
    """Activate skin.aegis as the active Kodi skin (first-run Step 2).

    The wizard used to push only the skin's status *properties* but never
    actually switched Kodi to skin.aegis, so a fresh install stayed on Estuary
    ("the skin doesn't stick"). Set it via JSON-RPC Settings.SetSettingValue,
    which applies immediately WITHOUT the Settings-UI "keep this change?" 15s
    revert dialog. Idempotent: no-ops if the skin isn't installed or is already
    active.
    """
    try:
        if not xbmc.getCondVisibility("System.HasAddon(skin.aegis)"):
            xbmc.log("Aegis: skin.aegis not installed; cannot apply skin", xbmc.LOGWARNING)
            return
        if current_skin() == "skin.aegis":
            return
        resp = xbmc.executeJSONRPC(
            '{"jsonrpc":"2.0","id":1,"method":"Settings.SetSettingValue",'
            '"params":{"setting":"lookandfeel.skin","value":"skin.aegis"}}'
        )
        if json.loads(resp).get("result") is True:
            xbmc.log("Aegis: activated skin.aegis", xbmc.LOGINFO)
            xbmc.sleep(1500)  # let the skin reload settle before further dialogs
        else:
            xbmc.log("Aegis: failed to activate skin.aegis ({})".format(resp), xbmc.LOGWARNING)
    except Exception as exc:
        xbmc.log("Aegis: skin apply error: {}".format(exc), xbmc.LOGWARNING)


def apply_language_defaults() -> None:
    """Default audio + subtitle language to English (one-shot).

    Fixes the common "starts in a foreign language / Russian subs on multi-track
    releases" complaint: Kodi then auto-selects the English audio track and
    prefers English subtitles. One-shot by construction — only applied while the
    settings are still at Kodi's factory default, so it never overrides a user
    who later picks another language.
    """
    try:
        # A read that fails returns None -> skip (don't treat a transient
        # JSON-RPC failure as "still at factory default" and stomp a user choice).
        audio = jsonrpc_get_setting("locale.audiolanguage")
        if (
            audio is not None
            and str(audio).strip().lower() in AUDIO_LANG_FACTORY_DEFAULTS
            and jsonrpc_set_setting("locale.audiolanguage", "English")
        ):
            xbmc.log("Aegis: default audio language set to English", xbmc.LOGINFO)
        sub = jsonrpc_get_setting("locale.subtitlelanguage")
        if (
            sub is not None
            and str(sub).strip().lower() in SUB_LANG_FACTORY_DEFAULTS
            and jsonrpc_set_setting("locale.subtitlelanguage", "English")
        ):
            xbmc.log("Aegis: default subtitle language set to English", xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log("Aegis: language defaults error: {}".format(exc), xbmc.LOGWARNING)


def ensure_filecache_settings() -> None:
    """Raise Kodi's streaming read-buffer from its factory default (see
    FILECACHE_DEFAULTS). Takes effect for the next playback; no restart."""
    for setting_id, factory, ours in FILECACHE_DEFAULTS:
        try:
            current = jsonrpc_get_setting(setting_id)
            # A failed read (None) or any non-factory value is left alone --
            # never treat "couldn't read" as "still default" and stomp a choice.
            if current is None or current != factory:
                continue
            if jsonrpc_set_setting(setting_id, ours):
                xbmc.log("Aegis: {} {} -> {}".format(setting_id, factory, ours), xbmc.LOGINFO)
            else:
                xbmc.log("Aegis: failed to set {} to {}".format(setting_id, ours), xbmc.LOGWARNING)
        except Exception as exc:
            xbmc.log("Aegis: filecache default {} error: {}".format(setting_id, exc), xbmc.LOGWARNING)
