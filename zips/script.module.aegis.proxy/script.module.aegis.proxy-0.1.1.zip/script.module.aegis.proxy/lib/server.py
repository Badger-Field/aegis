"""Local HTTP proxy that strips SCTE-35 discontinuity tags from HLS
manifests and forwards segment requests with provider-specific
headers attached.

Architecture:

    inputstream.ffmpegdirect
              │
              ▼
    http://127.0.0.1:PORT/p?u=<url>&h=<headers>
              │
              ▼
    aegis.proxy.server (this module)
              │
              ▼ (with `h` headers applied)
    upstream (Samsung TV+ / Roku Channel / Plex Live)

When the upstream response is a manifest (Content-Type or `.m3u8`
extension), the proxy:
  - strips `EXT-X-DISCONTINUITY` and SCTE-35 hint tags via
    `manifest.rewrite_manifest` (see lib/manifest.py)
  - rewrites variant / segment URIs to point back at this proxy with
    the same headers attached, so the whole chain stays inside our
    rewriting + auth-header path

When the upstream response is a segment (.ts, .m4s, .mp4), the proxy
streams it through unchanged.

URL scheme:

    /p?u=<urlsafe-b64 url>&h=<urlsafe-b64 headers-json>

Both `u` and `h` are URL-safe base64 to keep us out of the percent-
encoding morass that comes with nesting URLs inside URLs. `h` is the
JSON-encoded form of a {"Header-Name": "value"} dict.

Security boundary:

  - Server binds to 127.0.0.1 only — never reachable from the LAN.
  - Hostname allow-list (`_UPSTREAM_HOST_ALLOWLIST`) limits which
    upstream targets we'll fetch, so a compromised client (e.g. a
    malicious m3u in the addon data dir) can't turn the proxy into an
    SSRF gadget pointed at internal services.
  - No request body forwarded upstream (proxy is GET-only).
  - Manifest size cap (`_MAX_MANIFEST_BYTES`) and overall timeout
    keep one bad upstream from wedging the server thread.

Lifecycle:

  - `start_server()` binds to a random ephemeral port and spawns a
    daemon thread running the HTTP server.
  - Returns the chosen port so the service caller can publish it
    (vault / xbmcgui Window prop) for the plugin to read.
  - `stop_server()` gracefully shuts the server down.

This module deliberately avoids xbmc/xbmcaddon/xbmcvfs imports so
the test suite can exercise it via standard library only.
"""
from __future__ import annotations

import base64
import json
import logging
import socket
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional, Tuple
from urllib.parse import parse_qs, urlparse

try:
    from . import manifest as _manifest_mod
    from . import throughput as _throughput_mod
except ImportError:  # pragma: no cover
    import manifest as _manifest_mod  # type: ignore[no-redef]
    import throughput as _throughput_mod  # type: ignore[no-redef]


_log = logging.getLogger(__name__)


# Hostnames the proxy will forward to. Anything else gets a 403.
# Each entry matches either the exact hostname or any subdomain.
# Order doesn't matter (linear scan, short list).
_UPSTREAM_HOST_ALLOWLIST: Tuple[str, ...] = (
    # FAST aggregator redirector (Samsung, Roku, Plex jmp2 forms,
    # Pluto, Tubi all go through here).
    "jmp2.uk",
    # Samsung TV+ CDN edges. Samsung redirects to *.samsungtvplus.com
    # and various cloudfront fronts; we accept anything ending in
    # one of these suffixes via the subdomain match.
    "samsungtvplus.com",
    # Plex Live media + manifest endpoints.
    "plex.tv",
    "provider.plex.tv",
    # Roku Channel CDN edges.
    "roku.com",
    "therokuchannel.roku.com",
    # Cloudfront and Akamai edges that Samsung / Plex / Roku redirect
    # to. These are broad but limited to the major CDN suffix patterns
    # — we're not opening the door to arbitrary http endpoints.
    "cloudfront.net",
    "akamaihd.net",
    "akamaized.net",
)

_MAX_MANIFEST_BYTES = 2 * 1024 * 1024  # 2 MB — generous cap; real
                                       # masters are ~5-50 KB.
_UPSTREAM_TIMEOUT_SECONDS = 8
_SEGMENT_CHUNK_BYTES = 64 * 1024

# Dynamic bitrate ceiling. The proxy caps the master playlist to what the
# measured proxy->CDN link sustains (throughput.py), with headroom so a dip
# doesn't immediately underrun. Until a measurement exists (cold start, first
# play after a Kodi restart), fall back to a conservative default so the very
# first stream is smooth rather than over-committing to 1080p; the estimate then
# refines from real segment fetches and the next master fetch (channel switch /
# reconnect) adapts upward if the link proves fast.
_BANDWIDTH_HEADROOM = 0.75
_DEFAULT_MAX_BANDWIDTH = 3_000_000  # bits/sec — keeps up to ~540p on cold start


def _current_max_bandwidth() -> int:
    """Bits/sec ceiling for the master-manifest cap, from the measured link."""
    bytes_per_sec = _throughput_mod.tracker.estimate_bytes_per_sec()
    if bytes_per_sec is None:
        return _DEFAULT_MAX_BANDWIDTH
    return int(bytes_per_sec * 8 * _BANDWIDTH_HEADROOM)


def _b64url_encode(data: bytes) -> str:
    """URL-safe base64 with stripped padding. Kept symmetric with
    `_b64url_decode` so a round-trip doesn't lose bytes."""
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64url_decode(text: str) -> bytes:
    """Inverse of `_b64url_encode` — restores padding before decoding
    so the helper accepts both padded and unpadded inputs."""
    pad = (-len(text)) % 4
    return base64.urlsafe_b64decode(text + ("=" * pad))


def encode_proxy_target(url: str, headers: Optional[dict] = None) -> str:
    """Build the query-string portion of a proxy URL: `?u=...&h=...`.

    The caller composes the full URL by prefixing the server's base
    (e.g. `http://127.0.0.1:48001/p`).
    """
    parts = ["u=" + _b64url_encode(url.encode("utf-8"))]
    if headers:
        parts.append(
            "h=" + _b64url_encode(json.dumps(headers, separators=(",", ":")).encode("utf-8"))
        )
    return "?" + "&".join(parts)


def _is_host_allowed(host: str) -> bool:
    """True iff `host` is on the upstream allow-list (exact or as a
    subdomain of an allow-listed suffix). Defends against the proxy
    being turned into an SSRF gadget."""
    if not host:
        return False
    host = host.lower()
    for allowed in _UPSTREAM_HOST_ALLOWLIST:
        if host == allowed or host.endswith("." + allowed):
            return True
    return False


def _decode_proxy_query(query: str) -> Tuple[Optional[str], Optional[dict]]:
    """Pull `u` and (optionally) `h` out of a proxy URL's query
    string. Returns `(url, headers)` or `(None, None)` on any
    decoding failure — caller responds with 400."""
    try:
        qs = parse_qs(query, keep_blank_values=False)
        url_list = qs.get("u")
        if not url_list:
            return None, None
        url = _b64url_decode(url_list[0]).decode("utf-8")
        headers: Optional[dict] = None
        headers_list = qs.get("h")
        if headers_list:
            headers = json.loads(_b64url_decode(headers_list[0]).decode("utf-8"))
            if not isinstance(headers, dict):
                return None, None
        return url, headers
    except Exception:
        return None, None


class _ProxyHandler(BaseHTTPRequestHandler):
    """Per-request handler. Subclassed from the stdlib HTTP base so
    we get free request-line parsing + connection management.

    Logging is silenced (the default `log_message` writes to stderr,
    which the Kodi process redirects to kodi.log at INFO level —
    we don't want a per-request entry there)."""

    # The "Server:" header value. Identifies us in case the upstream
    # ever sees our requests (which it shouldn't — we don't forward
    # this header). Mostly cosmetic.
    server_version = "AegisProxy/1.0"

    def log_message(self, fmt: str, *args) -> None:  # noqa: N802
        # Default impl writes to stderr → kodi.log. Suppress per-
        # request access logs entirely to keep kodi.log readable.
        # Real errors are logged via `_log` calls below.
        return

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path != "/p":
            self._respond_status(404, "not found")
            return
        url, headers = _decode_proxy_query(parsed.query)
        if not url:
            self._respond_status(400, "bad request")
            return
        upstream_host = (urlparse(url).hostname or "").lower()
        if not _is_host_allowed(upstream_host):
            self._respond_status(403, "host not in allow-list")
            return
        try:
            self._serve(url, headers or {})
        except Exception as exc:
            _log.warning("proxy serve failed for %s: %s", url, exc)
            try:
                self._respond_status(502, "upstream failed")
            except Exception:
                # Connection may have closed already; nothing useful
                # we can do.
                pass

    def _serve(self, url: str, headers: dict) -> None:
        """Fetch the upstream URL with `headers` applied, decide
        whether it's a manifest or a segment based on Content-Type +
        URL extension, and either rewrite-and-respond (manifest)
        or stream-through (segment)."""
        req = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=_UPSTREAM_TIMEOUT_SECONDS) as resp:
            content_type = resp.headers.get("Content-Type")
            # The URL we ASKED for might have redirected; use the
            # final URL as the manifest base so relative URI
            # resolution lands on the right CDN edge.
            final_url = resp.geturl() or url
            is_manifest = (
                _manifest_mod.is_m3u8_content_type(content_type)
                or _manifest_mod.looks_like_m3u8_extension(urlparse(final_url).path)
            )
            if is_manifest:
                # Bounded read — real manifests are tiny; an attacker
                # mirror that streams unbounded body shouldn't be
                # able to memory-DoS us.
                body = resp.read(_MAX_MANIFEST_BYTES).decode("utf-8", errors="replace")
                rewritten = _manifest_mod.rewrite_manifest(
                    body, final_url, lambda u: self._proxy_url_for(u, headers),
                    max_bandwidth=_current_max_bandwidth(),
                )
                payload = rewritten.encode("utf-8")
                self.send_response(200)
                # Use the standard HLS mime so ffmpegdirect's
                # dispatch logic is unambiguous about manifest-vs-
                # segment even if the upstream sent text/plain.
                self.send_header("Content-Type", "application/vnd.apple.mpegurl")
                self.send_header("Content-Length", str(len(payload)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(payload)
                return
            # Segment passthrough. Stream the upstream body straight
            # to the client without buffering more than one chunk —
            # segments can be multiple MB on high-bitrate variants
            # and we don't want to materialise the whole thing.
            self.send_response(200)
            if content_type:
                self.send_header("Content-Type", content_type)
            content_length = resp.headers.get("Content-Length")
            if content_length:
                self.send_header("Content-Length", content_length)
            self.end_headers()
            # Time ONLY the upstream reads (not the writes to ffmpeg) so the
            # throughput sample reflects CDN delivery speed, not ffmpeg's demux-
            # buffer backpressure — the whole point is to learn the real link
            # rate that ffmpeg's localhost-blind ABR can't see (throughput.py).
            total_bytes = 0
            read_seconds = 0.0
            while True:
                _t0 = time.perf_counter()
                chunk = resp.read(_SEGMENT_CHUNK_BYTES)
                _dt = time.perf_counter() - _t0
                if not chunk:
                    # Don't fold the terminating empty read into the estimate —
                    # it adds time but zero bytes, systematically underestimating
                    # throughput.
                    break
                read_seconds += _dt
                total_bytes += len(chunk)
                self.wfile.write(chunk)
            _throughput_mod.tracker.record(total_bytes, read_seconds)

    def _proxy_url_for(self, absolute_url: str, headers: dict) -> str:
        """Build a proxy URL that, when fetched, will retrieve
        `absolute_url` with the same headers we used here. Used to
        rewrite variant + segment URIs in manifests so the whole
        playback chain stays inside our proxy."""
        host = self.server.server_address[0]
        port = self.server.server_address[1]
        return "http://{}:{}/p{}".format(host, port, encode_proxy_target(absolute_url, headers))

    def _respond_status(self, code: int, reason: str) -> None:
        self.send_response(code)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(reason)))
        self.end_headers()
        self.wfile.write(reason.encode("ascii", errors="replace"))


def _find_free_port() -> int:
    """Bind to port 0 to let the OS pick a free ephemeral port,
    then close — we'll bind again in the actual server. There's a
    small race window between close + re-bind but it doesn't matter
    in practice: localhost ephemeral collisions are rare and the
    fallback is to re-call this function."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])
    finally:
        sock.close()


def start_server(port: Optional[int] = None) -> Tuple[ThreadingHTTPServer, int]:
    """Bind a `ThreadingHTTPServer` to 127.0.0.1 and start its
    serve-forever loop in a daemon thread. Returns the server
    instance + bound port so the caller can publish the port and
    later call `stop_server`.

    `port=None` (default) lets the OS pick an ephemeral. Passing an
    explicit port is mainly useful in tests where the choice matters
    for deterministic URLs.
    """
    bind_port = port if port is not None else _find_free_port()
    server = ThreadingHTTPServer(("127.0.0.1", bind_port), _ProxyHandler)
    thread = threading.Thread(target=server.serve_forever, name="aegis-proxy", daemon=True)
    thread.start()
    return server, int(server.server_address[1])


def stop_server(server: ThreadingHTTPServer) -> None:
    """Tell the serve-forever loop to exit + close the listening
    socket. The daemon thread cleans up on its own once
    `serve_forever` returns."""
    try:
        server.shutdown()
    finally:
        server.server_close()
