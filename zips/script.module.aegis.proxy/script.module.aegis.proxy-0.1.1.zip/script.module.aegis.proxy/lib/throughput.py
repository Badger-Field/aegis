"""Thread-safe upstream-throughput estimator for the HLS proxy.

The proxy is the ONLY component that can see the real bottleneck. ffmpegdirect
fetches everything from 127.0.0.1 (this proxy), so from ffmpeg's point of view
the link is localhost — effectively infinite — and its built-in ABR always grabs
the top rendition. The proxy then can't pull that rendition from the real CDN
fast enough and the stream underruns.

This tracker accumulates an EWMA of the measured proxy->CDN segment-fetch
throughput so the manifest rewriter can cap the master playlist to the renditions
the connection actually sustains (see manifest.rewrite_manifest max_bandwidth).
The estimate is a property of the network path, not any one stream, so it's a
process-wide singleton that keeps learning across channel switches.

Measurement note (see server.py): only the time spent in the upstream `read()`
is folded in, NOT the time writing to ffmpeg. ffmpeg backpressure (a full demux
buffer) blocks the write, but timing the read alone keeps the sample a measure of
CDN delivery speed rather than playback consumption rate.
"""
from __future__ import annotations

import threading
from typing import Optional

# Ignore samples too small/short to be meaningful: sub-200 KB reads and
# sub-20 ms durations are dominated by TCP/connection setup and timer
# granularity, and would bias the estimate. Real HLS segments are ~0.5-3 MB.
_MIN_SAMPLE_BYTES = 200_000
_MIN_SAMPLE_SECONDS = 0.02

# Asymmetric EWMA weights. We only time the upstream read() (not ffmpeg
# backpressure), so a fetch usually arrives at link speed — but some CDNs *pace*
# delivery to roughly the segment bitrate. If we trusted those paced (slow)
# samples symmetrically, the estimate would ratchet down toward the current
# rendition's bitrate, drag the cap down, and spiral to the lowest variant.
# So rise FAST toward faster samples (a burst-fill / uncapped read reveals real
# link headroom) and fall SLOW, so a paced or momentarily-slow read can't
# collapse the estimate. Net: the EWMA locks onto sustained link capacity.
_EWMA_ALPHA_RISE = 0.5
_EWMA_ALPHA_FALL = 0.1


class ThroughputTracker:
    """EWMA of upstream throughput in BYTES per second. Thread-safe: the proxy
    serves each request on its own thread (ThreadingHTTPServer)."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._ewma_bytes_per_sec: Optional[float] = None

    def record(self, num_bytes: int, seconds: float) -> None:
        """Fold one upstream fetch into the estimate. No-ops on samples below the
        noise thresholds so a burst of tiny reads can't drag the estimate down."""
        if num_bytes < _MIN_SAMPLE_BYTES or seconds < _MIN_SAMPLE_SECONDS:
            return
        sample = num_bytes / seconds
        with self._lock:
            if self._ewma_bytes_per_sec is None:
                self._ewma_bytes_per_sec = sample
            else:
                alpha = _EWMA_ALPHA_RISE if sample > self._ewma_bytes_per_sec else _EWMA_ALPHA_FALL
                self._ewma_bytes_per_sec = (
                    alpha * sample + (1 - alpha) * self._ewma_bytes_per_sec
                )

    def estimate_bytes_per_sec(self) -> Optional[float]:
        """Current EWMA, or None if nothing measurable has been recorded yet
        (cold start — caller should fall back to a conservative default)."""
        with self._lock:
            return self._ewma_bytes_per_sec

    def reset(self) -> None:
        with self._lock:
            self._ewma_bytes_per_sec = None


# Process-wide singleton — the link speed belongs to the path, not a stream.
tracker = ThroughputTracker()
