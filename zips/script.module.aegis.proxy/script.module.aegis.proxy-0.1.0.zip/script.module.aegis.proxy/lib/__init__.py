"""Aegis HLS proxy — strip SCTE-35 discontinuity tags so live-TV
playback through inputstream.ffmpegdirect doesn't stutter at every
ad break.

See `lib/manifest.py` for the rewriting logic and `lib/server.py`
for the HTTP server.
"""
from .manifest import (  # noqa: F401
    is_m3u8_content_type,
    looks_like_m3u8_extension,
    rewrite_manifest,
)
from .server import (  # noqa: F401
    encode_proxy_target,
    start_server,
    stop_server,
)
