"""HLS manifest rewriting for the SCTE-35 discontinuity-strip proxy.

Pure functions over manifest text — no I/O — so this module is fully
testable in isolation. The proxy server (lib/server.py) wraps these in
the HTTP request loop.

The job is twofold:

  1. **Strip discontinuity markers.** Live-TV providers (Samsung TV+,
     Roku, Plex Live) insert `#EXT-X-DISCONTINUITY` at every SCTE-35
     ad break. ffmpegdirect's HLS demuxer responds by closing the
     current decoder, opening the next variant, and signalling
     `STREAMCHANGE` up to Kodi's VideoPlayer — a 1-15 second user-
     visible stutter every ad break. Removing the discontinuity tag
     before ffmpegdirect sees it makes the boundary transparent: the
     demuxer keeps reading segments without re-init.

     Also strip the SCTE-35 hint tags (`#EXT-X-CUE-OUT`,
     `#EXT-X-CUE-IN`, `#EXT-X-SCTE35`, `#EXT-X-DATERANGE` with
     SCTE35-* attrs) since some Kodi/ffmpeg versions react to those
     too even without the explicit `DISCONTINUITY` tag.

     Discontinuity sequence numbers (`#EXT-X-DISCONTINUITY-SEQUENCE`)
     are preserved — they describe the PRE-existing media offset and
     dropping them would break seek/timestamp math.

  2. **Rewrite resource URLs to point at the local proxy.** A master
     m3u8 lists variant playlist URLs; a variant lists segment URLs.
     Both must route through the proxy so:
       - master rewrites → ffmpegdirect fetches variants via proxy
         → variants ALSO get discontinuity-stripped before reaching
         the demuxer.
       - variant rewrites → ffmpegdirect fetches segments via proxy
         → headers (provider-specific UA + Origin + Referer) reach
         the upstream CDN on segment fetches even when the master
         was the only URL ffmpegdirect "knew" about.

     Relative URLs in the manifest are resolved against the upstream
     manifest URL (using `urllib.parse.urljoin`) before encoding, so
     the proxy fetch later resolves to the correct absolute upstream.

Defensive notes:
  - URL lines are detected as "non-comment, non-empty" — anything not
    starting with `#` and not blank, per the HLS spec.
  - Lines preserved verbatim include EXTINF, stream-info, key, init,
    target-duration, version, etc. The strip is narrow: only
    discontinuity + SCTE-35 hint family.
  - The proxy URL is a callable injected by the caller so this
    module stays Kodi-free and unit-testable.
"""
from __future__ import annotations

from typing import Callable, List
from urllib.parse import urljoin

# Tag prefixes we strip from manifests. Stored as a tuple of
# uppercase prefixes; matching is case-insensitive against the tag
# portion (chars after `#`).
_STRIP_TAG_PREFIXES = (
    "EXT-X-DISCONTINUITY",       # the primary culprit; matches
                                 # `#EXT-X-DISCONTINUITY` exactly AND
                                 # any future extension like
                                 # `#EXT-X-DISCONTINUITY-FOO` that we
                                 # haven't seen yet. Does NOT match
                                 # `EXT-X-DISCONTINUITY-SEQUENCE`,
                                 # handled by the exception below.
    "EXT-X-CUE-OUT",             # SCTE-35 ad-marker
    "EXT-X-CUE-IN",              # SCTE-35 ad-marker
    "EXT-X-CUE",                 # Some encoders emit bare CUE
    "EXT-X-SCTE35",              # Direct SCTE-35 cue
    "EXT-OATCLS-SCTE35",         # Some VAST tooling uses this prefix
    "EXT-X-ASSET",               # Apple HLS ad-asset marker
    "EXT-X-AD",                  # Bare ad marker some providers use
)

# Tags whose prefix matches `_STRIP_TAG_PREFIXES` but which we KEEP
# (whitelist exception). DISCONTINUITY-SEQUENCE carries the
# pre-existing-discontinuity offset and is needed for correct
# segment-number math.
_KEEP_TAG_EXACT = (
    "EXT-X-DISCONTINUITY-SEQUENCE",
)


def _tag_name(line: str) -> str:
    """Extract the tag name (uppercased, attribute portion dropped)
    from a `#EXT-...:value` line. Returns "" if the line isn't an
    HLS tag."""
    if not line.startswith("#"):
        return ""
    # Tag body starts after `#`. Split on `:` to drop the attribute
    # portion (some tags have attributes, some don't).
    body = line[1:].split(":", 1)[0]
    return body.upper().strip()


def _should_strip_line(line: str) -> bool:
    """True iff this line is a discontinuity / SCTE-35 marker we
    want removed. Whitelist exceptions (e.g. DISCONTINUITY-SEQUENCE)
    short-circuit to False."""
    tag = _tag_name(line)
    if not tag:
        return False
    if tag in _KEEP_TAG_EXACT:
        return False
    for prefix in _STRIP_TAG_PREFIXES:
        if tag == prefix or tag.startswith(prefix + "-") or tag.startswith(prefix + ":"):
            return True
    return False


def _is_uri_line(line: str) -> bool:
    """HLS spec: a URI line is any line that doesn't start with `#`
    and isn't blank. Whitespace-only lines count as blank for HLS."""
    stripped = line.strip()
    return bool(stripped) and not stripped.startswith("#")


def _resolve(base_url: str, url_line: str) -> str:
    """Resolve a (possibly relative) URI from a manifest against the
    manifest's own URL. Strips trailing whitespace from the URI but
    preserves the URI characters verbatim — no encoding changes."""
    return urljoin(base_url, url_line.strip())


def rewrite_manifest(
    manifest_text: str,
    upstream_url: str,
    proxy_url_for: Callable[[str], str],
) -> str:
    """Return a new manifest with discontinuity tags stripped and
    every URI line rewritten via `proxy_url_for`.

    `manifest_text` is the upstream manifest body (decoded text).
    `upstream_url` is the URL it was fetched from (used as the
    base for resolving relative URIs). `proxy_url_for(absolute_url)`
    must return the proxy URL that, when fetched, will retrieve and
    rewrite the target resource.

    Output line endings are normalised to `\\n`. Trailing whitespace
    on URI lines is dropped (cleaner output, matches the resolved
    form returned by `urljoin`). All other lines are passed through
    untouched apart from the strip filter.

    Per HLS spec, only `#EXT-X-KEY` and `#EXT-X-MAP` carry URIs
    *inside* a tag (via the `URI="..."` attribute). Those URIs aren't
    rewritten here because:
      - segment-level keys and inits are part of the segment stream
        and ffmpegdirect fetches them through the same HTTP path as
        segments
      - rewriting attribute URIs correctly would require quote-aware
        parsing of comma-separated attribute lists
      - for our providers (Samsung/Roku/Plex live), KEY / MAP URIs
        are typically same-origin signed URLs that work without
        re-applying our headers
    Revisit if a provider surfaces that needs in-tag URI rewriting.
    """
    out_lines: List[str] = []
    for raw in manifest_text.splitlines():
        if _should_strip_line(raw):
            continue
        if _is_uri_line(raw):
            absolute = _resolve(upstream_url, raw)
            out_lines.append(proxy_url_for(absolute))
        else:
            out_lines.append(raw)
    # Preserve a trailing newline if the upstream had one — some
    # parsers are forgiving but cheap correctness is cheap correctness.
    text = "\n".join(out_lines)
    if manifest_text.endswith("\n"):
        text += "\n"
    return text


def is_m3u8_content_type(content_type: str | None) -> bool:
    """True if a Content-Type header indicates an HLS manifest. The
    spec-blessed types are
      - application/vnd.apple.mpegurl
      - application/x-mpegurl
      - audio/mpegurl
    but plenty of upstreams ship `text/plain` or even drop the header.
    Callers that need to handle those use the file-extension fallback
    in `lib/server.py` rather than relying on this function alone.
    """
    if not content_type:
        return False
    ct = content_type.split(";", 1)[0].strip().lower()
    return ct in (
        "application/vnd.apple.mpegurl",
        "application/x-mpegurl",
        "audio/mpegurl",
        "audio/x-mpegurl",
        "vnd.apple.mpegurl",
    )


def looks_like_m3u8_extension(path: str) -> bool:
    """Fallback: True if the URL path's final segment ends in `.m3u8`
    or `.m3u` (after dropping any query string). Used when the
    upstream omits a usable Content-Type."""
    bare = path.split("?", 1)[0].split("#", 1)[0]
    lower = bare.rstrip("/").lower()
    return lower.endswith(".m3u8") or lower.endswith(".m3u")
