"""MPEG-TS PTS/DTS/PCR rebasing — the SSAI ad-break fix.

Server-side ad insertion (Samsung TV+ / Tubi / yospace) splices ad segments into
the live TS on a DISCONTINUOUS timeline: the ad's PTS/DTS (and PCR) jump away
from the show's clock. Kodi 21.3's CVideoPlayer can't rebase across that jump and
freezes (`CheckContinuity - resync forward` storm). Stripping or keeping the HLS
`#EXT-X-DISCONTINUITY` tag doesn't help — the jump is inside the TS bytes.

This module rewrites the timestamps in the TS stream so spliced content CONTINUES
the show's timeline. The discontinuity disappears before Kodi sees it.

Design:
  - `Remuxer` is a stateful, single-stream object. Feed it whole segments in
    playback order via `rebase(segment_bytes)`; it returns rewritten bytes and
    carries the running offset + last-output-PTS between calls (segments arrive as
    separate HTTP requests in the proxy).
  - Every PTS, DTS and PCR gets the SAME 90 kHz offset added (they share the
    program clock), so audio/video stay in lock-step.
  - A jump is detected when a segment's first timestamp, projected through the
    current offset, is not "just ahead" of the last emitted timestamp (backward,
    or a big forward gap). On a jump the offset is recomputed so the new segment
    starts one frame after the last emitted PTS — seamless to the player.
  - All arithmetic is modulo 2**33 (the 33-bit clock wraps ~26.5 h).

Pure byte-level rewriting, no external deps, unit-testable in isolation. Errors
are contained: `rebase` never raises on malformed input — it returns the segment
unchanged so a parse edge case degrades to "no rebase" rather than dropping the
stream.
"""
from __future__ import annotations

from typing import List, Optional, Tuple

TS_PACKET_SIZE = 188
TS_SYNC_BYTE = 0x47
PTS_MODULUS = 1 << 33  # 33-bit clock (90 kHz)

# A nominal inter-frame gap (90 kHz ticks) used to place a spliced segment right
# after the previous one. ~3003 = one frame at 29.97 fps; the exact value doesn't
# matter — the point is a small positive step so the player sees continuity.
_FRAME_GAP = 3003

# Forward gap (90 kHz ticks) beyond which we treat a new segment's start as a
# DISCONTINUITY rather than a normal advance. 10 s of slack absorbs legitimate
# segment boundaries + minor jitter while still catching real SSAI splices, whose
# jumps are typically minutes/hours or backward. Backward always counts as a jump.
_DISCONTINUITY_THRESHOLD = 10 * 90_000  # 900,000 ticks = 10 s


def _mod33(x: int) -> int:
    return x % PTS_MODULUS


def _decode_ts_timestamp(buf: bytes, pos: int) -> int:
    """Decode a 33-bit PTS/DTS from the 5 bytes at `buf[pos:pos+5]`."""
    b0, b1, b2, b3, b4 = buf[pos], buf[pos + 1], buf[pos + 2], buf[pos + 3], buf[pos + 4]
    return (
        ((b0 >> 1) & 0x07) << 30
        | b1 << 22
        | ((b2 >> 1) & 0x7F) << 15
        | b3 << 7
        | ((b4 >> 1) & 0x7F)
    )


def _encode_ts_timestamp(buf: bytearray, pos: int, value: int) -> None:
    """Re-encode a 33-bit PTS/DTS into `buf[pos:pos+5]`, preserving the 4-bit
    prefix (0010=PTS, 0011=PTS-of-pair, 0001=DTS) already in the top nibble and
    all the mandated marker bits."""
    value &= PTS_MODULUS - 1
    prefix = buf[pos] & 0xF0  # keep the 0010/0011/0001 guard nibble
    buf[pos] = prefix | ((value >> 30) & 0x07) << 1 | 0x01
    buf[pos + 1] = (value >> 22) & 0xFF
    buf[pos + 2] = ((value >> 15) & 0x7F) << 1 | 0x01
    buf[pos + 3] = (value >> 7) & 0xFF
    buf[pos + 4] = (value & 0x7F) << 1 | 0x01


def _valid_ts_field(buf: bytes, pos: int, expected_prefixes: Tuple[int, ...]) -> bool:
    """A real PTS/DTS field has its three mandatory marker bits set (bit 0 of
    bytes 0, 2, 4) and a known 4-bit guard prefix. Validating both before we
    rewrite means a mis-flagged / malformed PES can never get its payload
    corrupted — we just skip it and pass the bytes through untouched."""
    if pos + 5 > len(buf):
        return False
    if not (buf[pos] & 0x01 and buf[pos + 2] & 0x01 and buf[pos + 4] & 0x01):
        return False
    return (buf[pos] >> 4) in expected_prefixes


def _decode_pcr_base(buf: bytes, pos: int) -> int:
    """Decode the 33-bit PCR base from the 6 PCR bytes at `buf[pos:pos+6]`.
    (The 9-bit extension in those bytes is a 27 MHz remainder; we leave it be.)"""
    return (
        buf[pos] << 25
        | buf[pos + 1] << 17
        | buf[pos + 2] << 9
        | buf[pos + 3] << 1
        | buf[pos + 4] >> 7
    )


def _encode_pcr_base(buf: bytearray, pos: int, base: int) -> None:
    """Re-encode the 33-bit PCR base into `buf[pos:pos+6]`, preserving the 6
    reserved bits + the 9-bit extension in the low bytes."""
    base &= PTS_MODULUS - 1
    buf[pos] = (base >> 25) & 0xFF
    buf[pos + 1] = (base >> 17) & 0xFF
    buf[pos + 2] = (base >> 9) & 0xFF
    buf[pos + 3] = (base >> 1) & 0xFF
    # byte4: top bit = base LSB; keep the 6 reserved bits + ext MSB (low 7 bits).
    buf[pos + 4] = ((base & 0x01) << 7) | (buf[pos + 4] & 0x7F)


def _timestamp_field_positions(packet: bytes) -> Tuple[Optional[int], Optional[int], Optional[int]]:
    """Return `(pts_pos, dts_pos, pcr_pos)` byte offsets WITHIN a 188-byte TS
    packet, or None for each field absent. Only inspects packets that carry a PES
    header (payload_unit_start) for PTS/DTS, and adaptation fields for PCR."""
    if len(packet) != TS_PACKET_SIZE or packet[0] != TS_SYNC_BYTE:
        return None, None, None

    payload_unit_start = (packet[1] >> 6) & 0x01
    adaptation_field_control = (packet[3] >> 4) & 0x03

    pcr_pos: Optional[int] = None
    payload_start = 4
    if adaptation_field_control in (0b10, 0b11):
        af_len = packet[4]
        # PCR sits right after the adaptation flags byte when PCR_flag is set.
        # Require room for the flags byte (1) + the 6 PCR bytes: a malformed short
        # field that claims PCR would otherwise have us rewrite payload bytes at
        # [6:12] and corrupt the packet.
        if af_len >= 7:
            flags = packet[5]
            if flags & 0x10:  # PCR_flag
                pcr_pos = 6  # 6 PCR bytes at packet[6:12]
        payload_start = 5 + af_len
    if adaptation_field_control == 0b10:
        # Adaptation only, no payload → no PES here.
        return None, None, pcr_pos
    if adaptation_field_control == 0b00:
        return None, None, pcr_pos  # reserved / no payload

    pts_pos: Optional[int] = None
    dts_pos: Optional[int] = None
    if payload_unit_start and payload_start + 9 <= TS_PACKET_SIZE:
        p = payload_start
        # PES start code prefix 0x000001.
        if packet[p] == 0x00 and packet[p + 1] == 0x00 and packet[p + 2] == 0x01:
            pts_dts_flags = (packet[p + 7] >> 6) & 0x03
            optional_fields = p + 9  # after 00 00 01, stream_id, len(2), flags(2), hdr_len(1)
            # PTS guard nibble is 0b0010 (PTS only) or 0b0011 (PTS of a PTS+DTS
            # pair); DTS is 0b0001. Marker bits must be set. Validate before
            # trusting the flags so malformed padding can't be mistaken for a PTS.
            if pts_dts_flags & 0x02 and _valid_ts_field(packet, optional_fields, (0b0010, 0b0011)):
                pts_pos = optional_fields
                if pts_dts_flags == 0x03 and _valid_ts_field(packet, optional_fields + 5, (0b0001,)):
                    dts_pos = optional_fields + 5
    return pts_pos, dts_pos, pcr_pos


class Remuxer:
    """Single-stream, stateful PTS/DTS/PCR rebaser. Not thread-safe: the proxy
    keeps one per stream and feeds segments in order."""

    def __init__(self) -> None:
        self._offset = 0
        self._out_last_pts: Optional[int] = None  # last PTS emitted (output clock)

    def rebase(self, segment: bytes) -> bytes:
        """Return `segment` with PTS/DTS/PCR rewritten so it continues the prior
        segment's timeline. Malformed/non-TS input is returned unchanged."""
        if not segment or len(segment) < TS_PACKET_SIZE or segment[0] != TS_SYNC_BYTE:
            return segment
        try:
            return self._rebase(segment)
        except Exception:
            # Never take down a stream over a parse edge case — degrade to
            # passthrough (the pre-remux behaviour).
            return segment

    def _rebase(self, segment: bytes) -> bytes:
        n_packets = len(segment) // TS_PACKET_SIZE
        # First pass: find this segment's first input PTS to decide the offset.
        first_in_pts: Optional[int] = None
        for i in range(n_packets):
            off = i * TS_PACKET_SIZE
            pts_pos, _, _ = _timestamp_field_positions(segment[off:off + TS_PACKET_SIZE])
            if pts_pos is not None:
                first_in_pts = _decode_ts_timestamp(segment, off + pts_pos)
                break

        if first_in_pts is not None:
            if self._out_last_pts is None:
                # First segment ever: play as-is (offset 0), anchor the clock.
                self._offset = 0
            else:
                projected = _mod33(first_in_pts + self._offset)
                delta = _mod33(projected - self._out_last_pts)
                # Continuous iff `projected` is just AHEAD of the last output PTS.
                # A backward step (delta near the modulus) or a big forward gap is
                # a splice → recompute the offset to butt this segment against the
                # previous one.
                if delta == 0 or delta > _DISCONTINUITY_THRESHOLD:
                    self._offset = _mod33(self._out_last_pts + _FRAME_GAP - first_in_pts)

        # Second pass: apply the offset to every timestamp + track max output PTS.
        out = bytearray(segment)
        max_out_pts = self._out_last_pts
        for i in range(n_packets):
            off = i * TS_PACKET_SIZE
            pts_pos, dts_pos, pcr_pos = _timestamp_field_positions(out[off:off + TS_PACKET_SIZE])
            if pts_pos is not None:
                new_pts = _mod33(_decode_ts_timestamp(out, off + pts_pos) + self._offset)
                _encode_ts_timestamp(out, off + pts_pos, new_pts)
                if max_out_pts is None or _mod33(new_pts - max_out_pts) < _DISCONTINUITY_THRESHOLD:
                    max_out_pts = new_pts
            if dts_pos is not None:
                new_dts = _mod33(_decode_ts_timestamp(out, off + dts_pos) + self._offset)
                _encode_ts_timestamp(out, off + dts_pos, new_dts)
            if pcr_pos is not None:
                new_pcr = _mod33(_decode_pcr_base(out, off + pcr_pos) + self._offset)
                _encode_pcr_base(out, off + pcr_pos, new_pcr)

        if max_out_pts is not None:
            self._out_last_pts = max_out_pts
        return bytes(out)


def _iter_pts_values(segment: bytes) -> List[int]:
    """Test/diagnostic helper: every PTS value present in a TS blob, in order."""
    out: List[int] = []
    for i in range(len(segment) // TS_PACKET_SIZE):
        off = i * TS_PACKET_SIZE
        pts_pos, _, _ = _timestamp_field_positions(segment[off:off + TS_PACKET_SIZE])
        if pts_pos is not None:
            out.append(_decode_ts_timestamp(segment, off + pts_pos))
    return out
