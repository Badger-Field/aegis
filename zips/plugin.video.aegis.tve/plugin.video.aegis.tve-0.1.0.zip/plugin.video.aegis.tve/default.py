"""Aegis TVE — entry point.

Credentials are MSO-scoped, not provider-scoped: signing into Telus
once unlocks every provider in the catalog that accepts Telus auth.
So the flow looks up the provider's chosen MSO first, then asks the
vault for stored MSO creds, and only prompts when this is the first
time we've seen this MSO.

Route hierarchy:
  plugin://plugin.video.aegis.tve/                       → country / provider picker
  plugin://plugin.video.aegis.tve/?action=open&pid=X     → open provider X
  plugin://plugin.video.aegis.tve/?action=wipe_mso&mid=Y → sign out of MSO Y
  plugin://plugin.video.aegis.tve/?action=change_mso&pid=X → re-pick MSO for X
"""
from __future__ import annotations

import sys
from pathlib import Path
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_ADDON_DIR = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("path")))
sys.path.insert(0, str(_ADDON_DIR / "lib"))

import vault_creds  # noqa: E402
from adobe_pass import AdobePassClient, AdobePassError, MSOLoginError  # noqa: E402
from discovery import discover_provider  # noqa: E402
from mso_handlers import get_handler  # noqa: E402
from registry import all_discovery_urls, load_registry, providers_by_country  # noqa: E402

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1


# ---------- helpers ----------

def _log(msg: str, level: int = xbmc.LOGINFO) -> None:
    xbmc.log("plugin.video.aegis.tve: " + msg, level)


def _url(query: dict) -> str:
    return "{}?{}".format(sys.argv[0], urlencode(query))


def _add_dir_item(label: str, action: str, **extra) -> None:
    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    params = {"action": action, **extra}
    xbmcplugin.addDirectoryItem(HANDLE, _url(params), item, True)


def _add_play_item(label: str, action: str, **extra) -> None:
    item = xbmcgui.ListItem(label=label)
    item.setProperty("IsPlayable", "true")
    params = {"action": action, **extra}
    xbmcplugin.addDirectoryItem(HANDLE, _url(params), item, False)


def _notify(message: str, heading: str = "Aegis TVE") -> None:
    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_INFO, 4000)


def _read_clipboard() -> str:
    """Best-effort OS clipboard read. Returns "" if unavailable."""
    try:
        import ctypes
        CF_UNICODETEXT = 13
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        if not user32.OpenClipboard(0):
            return ""
        try:
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return ""
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                return ""
            try:
                return ctypes.wstring_at(ptr)
            finally:
                kernel32.GlobalUnlock(handle)
        finally:
            user32.CloseClipboard()
    except (OSError, AttributeError, ImportError):
        pass
    try:
        import tkinter  # type: ignore
        r = tkinter.Tk()
        r.withdraw()
        text = r.clipboard_get()
        r.destroy()
        return text
    except Exception:
        return ""


def _input_with_paste(heading: str, hidden: bool = False) -> str:
    """Prompt with a clipboard-paste shortcut so users don't have to type
    long passwords on Kodi's on-screen keyboard."""
    clip = _read_clipboard().strip()
    if clip and 1 <= len(clip) <= 200:
        body = (
            "Paste clipboard contents ({} chars, hidden)?".format(len(clip))
            if hidden else
            "Paste clipboard contents?\n\n{}".format(
                clip if len(clip) <= 60 else clip[:60] + "…"
            )
        )
        if xbmcgui.Dialog().yesno(heading, body, nolabel="Type instead", yeslabel="Paste"):
            return clip
    opts = xbmcgui.ALPHANUM_HIDE_INPUT if hidden else 0
    return xbmcgui.Dialog().input(heading, "", xbmcgui.INPUT_ALPHANUM, opts)


def _saved_country() -> str:
    return ADDON.getSetting("country") or ""


def _save_country(country: str) -> None:
    ADDON.setSetting("country", country)


# ---------- routes ----------


def route_root() -> None:
    """Top-level: country picker if not set, otherwise provider picker."""
    country = _saved_country()
    if not country:
        _pick_country()
        return

    registry = load_registry(_ADDON_DIR)
    providers = sorted(providers_by_country(registry, country), key=lambda p: p.label)
    if not providers:
        _notify("No TVE providers configured for country {}".format(country))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    xbmcplugin.setPluginCategory(HANDLE, "TVE — " + country)
    xbmcplugin.setContent(HANDLE, "addons")

    # "Change country" entry at the top so users aren't stuck.
    _add_dir_item("[I]Change country (current: {})[/I]".format(country), "pick_country")

    # Pull every vault sub-dict in ONE read so the picker is O(1) disk
    # touches no matter how many providers the country has — without this
    # bulk read, rendering a 37-provider country list would do ~74
    # individual vault reads per refresh.
    snapshot = vault_creds.read_snapshot()
    saved_providers = snapshot["providers"]
    msos_with_creds = {
        mid for mid, rec in snapshot["msos"].items()
        if (rec.get("username") and rec.get("password"))
    }
    for p in providers:
        label = p.label
        # Show a "(signed in)" hint when the provider's chosen MSO has
        # creds stashed in the vault — even if this is the first time
        # the user has opened this specific provider.
        mso = (saved_providers.get(p.id) or {}).get("mso_id")
        if mso and mso in msos_with_creds:
            label += "  [COLOR green](signed in via {})[/COLOR]".format(mso)
        _add_dir_item(label, "open", pid=p.id)

    xbmcplugin.endOfDirectory(HANDLE)


def _pick_country() -> None:
    """Country select dialog. Drives which providers show in the picker."""
    options = [
        ("CA", "Canada"),
        ("US", "United States"),
    ]
    pick = xbmcgui.Dialog().select(
        "Aegis TVE — choose your country",
        ["{}  ({})".format(label, code) for code, label in options],
    )
    if pick < 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    code = options[pick][0]
    _save_country(code)
    _log("country saved: {}".format(code))
    route_root()


def route_open(pid: str) -> None:
    """Open a specific provider — login if needed, else show signed-in menu.

    Five-step flow, each step bails out cleanly if the user cancels:
      1. Provider lookup.
      2. MSO: stored choice, or picker.
      3. MSO credentials: stored, or prompt (once per MSO across all providers).
      4. Adobe Pass discovery → requestor_id.
      5. Token: cached by (mso, requestor), or authenticate + cache.
    """
    registry = load_registry(_ADDON_DIR)
    provider = registry.get(pid)
    if provider is None:
        _notify("Unknown provider: {}".format(pid))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    stored_mso = vault_creds.get_provider_mso(pid)
    mso_id = stored_mso or _pick_mso(provider)
    if not mso_id:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    # Only write when the choice actually changed — every set_provider_mso
    # is a vault rewrite, and the steady-state path (returning user, same
    # MSO) was paying for that on every click.
    if mso_id != stored_mso and not vault_creds.set_provider_mso(pid, mso_id):
        _notify("Vault unavailable — couldn't remember your MSO choice. Continuing anyway.")

    creds = vault_creds.load_mso_creds(mso_id)
    if creds is None:
        creds = _prompt_for_mso_creds(mso_id)
        if creds is None:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

    progress = xbmcgui.DialogProgress()
    progress.create("Aegis TVE", "Signing in to {}…".format(provider.label))
    try:
        progress.update(10, "Discovering Adobe Pass configuration…")
        discovery = discover_provider(
            all_discovery_urls(provider),
            static_hints=provider.static_hints,
        )
        if not discovery.is_usable():
            err = discovery.extra.get("_discovery_error", "no requestor_id surfaced")
            raise AdobePassError("discovery failed: " + err)

        requestor_id = discovery.requestor_id
        _log("discovery for {}: requestor_id={} client_version={} matchers={}".format(
            pid, requestor_id, discovery.client_version, discovery.matchers_used,
        ))

        cached = vault_creds.load_cached_token(mso_id, requestor_id)
        if cached:
            _log("using cached aptoken for {} via {}".format(pid, mso_id))
            progress.close()
            _show_provider_menu(provider, mso_id, cached["aptoken"])
            return

        progress.update(40, "Authenticating with {}…".format(mso_id))
        # Plumb the registry's discovery URLs into the client so the 451
        # → Tier 2 retry path works even for Tier-1-only providers (where
        # the inline scrape found nothing and discovery.source_url is
        # empty because requestor_id came from static_hints).
        client = AdobePassClient(
            discovery=discovery,
            device_id=vault_creds.get_device_id(),
            logger=lambda m: _log(m, xbmc.LOGINFO),
            discovery_urls=all_discovery_urls(provider),
        )
        handler = get_handler(mso_id, registry_hints=provider.static_hints)
        token = client.authenticate(
            mso_id=mso_id,
            username=creds["username"],
            password=creds["password"],
            mso_handler=handler,
        )

        progress.update(90, "Caching token…")
        vault_creds.cache_token(mso_id, requestor_id, token.aptoken, token.expires_at)
        progress.close()
        _show_provider_menu(provider, mso_id, token.aptoken)
    except (AdobePassError, MSOLoginError) as exc:
        progress.close()
        _handle_auth_failure(provider, mso_id, exc)
    except Exception as exc:
        progress.close()
        _log("unexpected error: {}: {}".format(type(exc).__name__, exc), xbmc.LOGERROR)
        _notify("Unexpected error — see kodi.log")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def _pick_mso(provider) -> str | None:
    """Ask the user which MSO (cable provider) to authenticate against.

    Defaults the picker to the provider's `common_msos` list when present,
    otherwise falls back to free-text entry."""
    dialog = xbmcgui.Dialog()
    if not provider.common_msos:
        return dialog.input(
            "Aegis TVE — MSO ID for {} (e.g. 'spectrum', 'telus_auth-gateway_net')".format(
                provider.label
            ),
            "", xbmcgui.INPUT_ALPHANUM,
        ) or None
    pick = dialog.select(
        "Aegis TVE — {} — choose your TV provider (MSO)".format(provider.label),
        list(provider.common_msos),
    )
    if pick < 0:
        return None
    return provider.common_msos[pick]


def _prompt_for_mso_creds(mso_id: str) -> dict | None:
    """Capture username + password for one MSO. Stored once, reused by
    every provider that lists this MSO in `common_msos`."""
    username = _input_with_paste(
        "Aegis TVE — {} — username (email)".format(mso_id),
        hidden=False,
    )
    if not username:
        return None
    password = _input_with_paste(
        "Aegis TVE — {} — password".format(mso_id),
        hidden=True,
    )
    if not password:
        return None
    if not vault_creds.save_mso_creds(mso_id, username, password):
        _notify("Vault unavailable — credentials NOT saved. Cannot continue.")
        return None
    return {"username": username, "password": password}


def _handle_auth_failure(provider, mso_id: str, exc: Exception) -> None:
    msg = "{}: {}".format(type(exc).__name__, exc)
    _log("auth failure for {} via {}: {}".format(provider.id, mso_id, msg), xbmc.LOGWARNING)
    if xbmcgui.Dialog().yesno(
        "Aegis TVE — auth failed",
        "{}.\n\nWipe stored credentials for {} and retry?".format(msg, mso_id)[:240],
        nolabel="Cancel",
        yeslabel="Wipe & retry",
    ):
        vault_creds.clear_mso(mso_id)
        _notify("Credentials for {} cleared. Re-open to retry.".format(mso_id))
    xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


def _show_provider_menu(provider, mso_id: str, aptoken: str) -> None:
    """Placeholder until EPG / resource catalog integration lands.

    Once authenticated we have an Adobe Pass aptoken for the requestor.
    The next layer (resource authorize → manifest URL → inputstream.adaptive
    Widevine playback) is the Phase 2 chunk; for now we confirm the
    sign-in succeeded and offer wipe-MSO / change-MSO actions.
    """
    xbmcplugin.setPluginCategory(HANDLE, provider.label + " — signed in")
    item = xbmcgui.ListItem(label="Signed in via {} ✓  (channel catalog coming in Phase 2)".format(mso_id))
    item.setArt({"icon": "DefaultIconInfo.png"})
    xbmcplugin.addDirectoryItem(HANDLE, "", item, False)
    _add_dir_item("Change TV provider (MSO) for this channel", "change_mso", pid=provider.id)
    _add_dir_item("Sign out of {} (affects every channel)".format(mso_id), "wipe_mso", mid=mso_id)
    xbmcplugin.endOfDirectory(HANDLE)


def route_wipe_mso(mso_id: str) -> None:
    """Sign out of one MSO. Every provider that pointed at this MSO
    will re-prompt for credentials on next open — but they keep their
    MSO choice, so the user only re-enters the password."""
    if not mso_id:
        _notify("Missing MSO id — nothing to sign out of.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    vault_creds.clear_mso(mso_id)
    _notify("Signed out of {}.".format(mso_id))
    route_root()


def route_change_mso(pid: str) -> None:
    """Forget the provider's stored MSO so the next open re-runs the picker."""
    if not pid:
        _notify("Missing provider id — nothing to change.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    vault_creds.clear_provider_mso(pid)
    _notify("MSO cleared for {}. Re-open to choose a new one.".format(pid))
    route_root()


# ---------- dispatch ----------


def run() -> None:
    query = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = query.get("action", "root")
    if action == "root":
        route_root()
    elif action == "pick_country":
        _pick_country()
    elif action == "open":
        route_open(query.get("pid", ""))
    elif action == "wipe_mso":
        route_wipe_mso(query.get("mid", ""))
    elif action == "change_mso":
        route_change_mso(query.get("pid", ""))
    else:
        _notify("Unknown action: {}".format(action))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


if __name__ == "__main__":
    run()
