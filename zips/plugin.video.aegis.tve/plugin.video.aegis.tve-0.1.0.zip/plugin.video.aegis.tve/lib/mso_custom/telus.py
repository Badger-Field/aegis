"""Telus (Optik TV) custom MSO login handler.

Telus's auth-gateway.net flow has a quirk the legacy snnow addon documented:
the federated SAML cascade calls a "bookend" endpoint multiple times before
landing on the actual login.php form, incrementing a `history` counter on
each hop. A naive form-follower (which the generic FormLoginHandler is)
loops on the same form forever because Telus doesn't expose a `password`
field until after the SOS+bookend cascade completes.

The override below:
  1. Follows the SOS/bookend cascade (POSTing each form back with a
     bumped `history` value) until Telus serves a form with `login_type`,
     `remember_me`, `source`, `source_button` — that's the login.php page.
  2. Fills in `username` + `password`, POSTs.
  3. Parses the `location.href = "..."` redirect Telus serves (NOT a 30x;
     it's JavaScript-driven), follows it to discoveryAssociations.
  4. Walks the final lastBookend → SAML ACS handoff back to Adobe.

Self-registers via `mso_handlers.register_handler` at import time.
"""
from __future__ import annotations

import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Dict, Tuple

try:
    # MSOLoginHandler is used as a typing reference by FormLoginHandler and
    # by callers — keep it imported for downstream documentation tooling.
    from ..adobe_pass import MSOLoginError, MSOLoginHandler  # noqa: F401
    from ..mso_handlers import (
        _BROWSER_UA,
        is_adobe_saml_acs,
        parse_form,
        register_handler,
        resolve_url,
    )
except ImportError:  # standalone import path
    from adobe_pass import MSOLoginError, MSOLoginHandler  # noqa: F401
    from mso_handlers import (
        _BROWSER_UA,
        is_adobe_saml_acs,
        parse_form,
        register_handler,
        resolve_url,
    )


# Login page is the one with these telltale fields (none of which appear
# on the SOS/bookend intermediates).
TELUS_LOGIN_FIELDS = ("login_type", "remember_me", "source", "source_button")

# Telus uses JS location.href redirects on the post-login page. Capture.
LOCATION_HREF_RE = re.compile(
    r"location\.href\s*=\s*[\"']([^\"']+)[\"']",
    re.IGNORECASE,
)


@dataclass
class TelusHandler:
    max_hops: int = 8

    def login(
        self,
        opener: urllib.request.OpenerDirector,
        initial_html: str,
        initial_url: str,
        username: str,
        password: str,
    ) -> Tuple[str, Dict[str, str]]:
        current_html = initial_html
        current_url = initial_url

        creds_submitted = False
        for hop in range(self.max_hops):
            # Are we back at Adobe? Then we're done. Check the SAMLResponse-
            # bearing form *first* — Telus often serves a hidden Adobe-return
            # form alongside the visible login form, and we want the Adobe
            # one if it's present (the generic first-form fallback would
            # otherwise grab the visible login form and miss the handoff).
            adobe_form = parse_form(current_html, prefer_field="SAMLResponse")
            if adobe_form is not None:
                action, fields = adobe_form
                action_abs = resolve_url(current_url, action) if action else current_url
                if is_adobe_saml_acs(action_abs) and "SAMLResponse" in fields:
                    return action_abs, fields

            form = parse_form(current_html)
            if form is None:
                # Telus's intermediate page may have a JS redirect instead.
                m = LOCATION_HREF_RE.search(current_html)
                if not m:
                    raise MSOLoginError(
                        "Telus: hop {} produced no <form> and no JS redirect at {}".format(
                            hop, current_url
                        )
                    )
                target = resolve_url(current_url, m.group(1))
                resp = self._fetch(opener, target)
                current_html, current_url = resp
                continue

            action, fields = form
            action_abs = resolve_url(current_url, action) if action else current_url

            is_login_page = all(f in fields for f in TELUS_LOGIN_FIELDS)
            if is_login_page and not creds_submitted:
                if not action_abs.lower().startswith("https://"):
                    raise MSOLoginError(
                        "Telus: refusing to POST credentials to non-HTTPS action: "
                        + repr(action_abs)
                    )
                fields["username"] = username
                fields["password"] = password
                creds_submitted = True
            elif "history" in fields:
                # Telus's SOS/bookend cascade increments this counter; bumping
                # it tells their server "I've already been around this loop
                # N times, give me the next stage instead of looping me back".
                try:
                    fields["history"] = str(int(fields.get("history", "0")) + 1)
                except ValueError:
                    fields["history"] = "2"

            # POST this form on.
            try:
                resp = opener.open(
                    urllib.request.Request(
                        action_abs,
                        data=urllib.parse.urlencode(fields).encode("utf-8"),
                        headers={"User-Agent": _BROWSER_UA},
                    ),
                    timeout=15,
                )
                current_html = resp.read().decode("utf-8", errors="replace")
                current_url = resp.url
            except urllib.error.HTTPError as exc:
                raise MSOLoginError("Telus: HTTP {} at {}".format(exc.code, action_abs)) from exc
            except urllib.error.URLError as exc:
                raise MSOLoginError("Telus: network error: {}".format(exc)) from exc

            # After the credentials POST, Telus often returns an HTML page
            # whose only meaningful content is a JS `location.href = "..."`.
            # Follow it.
            if creds_submitted:
                m = LOCATION_HREF_RE.search(current_html)
                if m:
                    target = resolve_url(current_url, m.group(1))
                    current_html, current_url = self._fetch(opener, target)

        raise MSOLoginError(
            "Telus: exceeded max_hops={} without reaching Adobe SAML ACS".format(self.max_hops)
        )

    @staticmethod
    def _fetch(opener: urllib.request.OpenerDirector, url: str) -> Tuple[str, str]:
        resp = opener.open(
            urllib.request.Request(url, headers={"User-Agent": _BROWSER_UA}),
            timeout=15,
        )
        return resp.read().decode("utf-8", errors="replace"), resp.url


# Self-register against the MSO ID hint used in the registry.
register_handler("telus_auth-gateway_net", TelusHandler())
