"""Adobe Pass init-value discovery from a provider's own web player.

The TVE addons ecosystem has historically died on hardcoded `requestor_id`,
`client_version`, and partner-key values that providers rotate without
notice (HTTP 451 from Adobe when the version is stale). This module
sidesteps that maintenance burden by extracting the *current* values from
each provider's own web player HTML/JS — the same page their browser
clients load, which is by definition kept fresh by the provider.

Strategy:
  1. Fetch the provider's `discovery_url` with a real browser User-Agent.
  2. Run a sequence of pattern matchers over the response body. Each
     matcher knows one common Adobe Pass init shape:
        - inline JSON config: `window.__AP_CONFIG__ = {...}`
        - SDK init call:      `AdobePassSDK.config({...})`
        - field-by-field:     `requestor_id: "ESPN", client_version: "3.4.2"`
        - URL params:         `sp.auth.adobe.com/...?requestor_id=ESPN&...`
  3. Merge results, prefer earlier matchers, fall back to static_hints
     from the registry for fields nothing turned up.

Caller (adobe_pass.py) gets a `DiscoveryResult` it can plug straight into
the SAML flow. No more hardcoded `client_version=1.9.2` time bombs.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

# Browser UA — providers redirect old/unknown UAs to mobile-app store
# landing pages instead of serving the SDK init. Picked a current Chrome
# build common enough to blend into normal traffic.
DEFAULT_DISCOVERY_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

# Adobe Pass fields we care about. Order matters for "first-match wins"
# semantics across the matchers below.
KNOWN_FIELDS = (
    "requestor_id",
    "client_version",
    "client_id",
    "client_type",
    "redirect_url",
    "domain_name",
)


@dataclass
class DiscoveryResult:
    """Adobe Pass init values for one provider, derived at runtime."""

    requestor_id: Optional[str] = None
    client_version: Optional[str] = None
    client_id: Optional[str] = None
    client_type: Optional[str] = None
    redirect_url: Optional[str] = None
    domain_name: Optional[str] = None
    extra: Dict[str, str] = field(default_factory=dict)
    source_url: str = ""
    matchers_used: List[str] = field(default_factory=list)

    def is_usable(self) -> bool:
        """We minimally need a requestor_id to mint an Adobe Pass URL."""
        return bool(self.requestor_id)

    def merge_fill(self, other: "DiscoveryResult") -> None:
        """Fill any None fields from another result. Used to layer
        primary-URL discovery on top of fallback-URL discovery."""
        for f in KNOWN_FIELDS:
            if getattr(self, f) is None and getattr(other, f) is not None:
                setattr(self, f, getattr(other, f))
        for k, v in other.extra.items():
            self.extra.setdefault(k, v)


class DiscoveryError(RuntimeError):
    pass


# ---------- pattern matchers ----------

# Each matcher takes the HTML/JS body and returns a partial DiscoveryResult
# (or None). They're tried in order and the first non-None per-field wins.

_AP_CONFIG_BLOCK_RE = re.compile(
    r"(?:window\.)?__?AP_?CONFIG__?\s*=\s*(\{[^;]*\})\s*;",
    re.DOTALL,
)


def _match_ap_config_json(body: str) -> Optional[DiscoveryResult]:
    """`window.__AP_CONFIG__ = { ... };` or similar inline JSON config."""
    m = _AP_CONFIG_BLOCK_RE.search(body)
    if not m:
        return None
    blob = m.group(1)
    # The block may contain unquoted JS values; try parse_lenient first.
    parsed = _parse_lenient_json(blob)
    if not parsed:
        return None
    return _result_from_dict(parsed, matcher="ap_config_json")


_SDK_INIT_RE = re.compile(
    r"(?:AdobePassSDK|AdobePass|adobePass)\.(?:config|init|configure)\s*\(\s*(\{[^;]*?\})\s*\)",
    re.DOTALL,
)


def _match_sdk_init_call(body: str) -> Optional[DiscoveryResult]:
    """`AdobePassSDK.config({...})` style SDK initialization."""
    m = _SDK_INIT_RE.search(body)
    if not m:
        return None
    parsed = _parse_lenient_json(m.group(1))
    if not parsed:
        return None
    return _result_from_dict(parsed, matcher="sdk_init_call")


def _match_field_by_field(body: str) -> Optional[DiscoveryResult]:
    """Independent regex searches for each KNOWN_FIELDS key. Last-ditch
    matcher — picks up scattered references that aren't in a single config
    block."""
    found: Dict[str, str] = {}
    for name in KNOWN_FIELDS:
        # Match: name: "value" / name = "value" / "name": "value"
        # Allow single OR double quotes; reject obvious noise (whitespace-only).
        pat = re.compile(
            r"['\"]?" + re.escape(name) + r"['\"]?\s*[:=]\s*['\"]([^'\"<>\s]{1,256})['\"]",
            re.IGNORECASE,
        )
        m = pat.search(body)
        if m:
            found[name] = m.group(1)
    if not found:
        return None
    return _result_from_dict(found, matcher="field_by_field")


_ADOBE_URL_RE = re.compile(
    r"https?://sp\.auth\.adobe\.com/[^\s'\"<>]*"
)


def _match_adobe_url_params(body: str) -> Optional[DiscoveryResult]:
    """Many providers embed a literal `sp.auth.adobe.com/...?...` URL with
    the requestor_id + client_* as query parameters."""
    m = _ADOBE_URL_RE.search(body)
    if not m:
        return None
    url = m.group(0)
    qpos = url.find("?")
    if qpos < 0:
        return None
    query = url[qpos + 1:]
    found: Dict[str, str] = {}
    for part in query.split("&"):
        if "=" not in part:
            continue
        k, _, v = part.partition("=")
        k = k.lower()
        if k in KNOWN_FIELDS:
            # URL-decode percent-encoded values lazily.
            try:
                from urllib.parse import unquote
                found[k] = unquote(v)
            except Exception:
                found[k] = v
    if not found:
        return None
    return _result_from_dict(found, matcher="adobe_url_params")


# Ordered tuple: ap_config_json wins over sdk_init wins over field_by_field
# wins over adobe_url_params (most-structured to least-structured).
MATCHERS: tuple = (
    ("ap_config_json", _match_ap_config_json),
    ("sdk_init_call", _match_sdk_init_call),
    ("field_by_field", _match_field_by_field),
    ("adobe_url_params", _match_adobe_url_params),
)


# ---------- helpers ----------

def _parse_lenient_json(blob: str) -> Optional[Dict[str, str]]:
    """Parse a JSON-like blob that may have JS-style unquoted keys, trailing
    commas, or single quotes. Returns a flat dict[str,str] of the leaf
    string/number values we care about, ignoring nested structures."""
    # Try strict JSON first.
    try:
        parsed = json.loads(blob)
        if isinstance(parsed, dict):
            return {k: str(v) for k, v in parsed.items() if not isinstance(v, (list, dict))}
    except json.JSONDecodeError:
        pass

    # Lenient: extract `key: "value"` pairs via regex.
    out: Dict[str, str] = {}
    pair_re = re.compile(
        r"['\"]?([a-zA-Z_][a-zA-Z0-9_]*)['\"]?\s*:\s*['\"]([^'\"]{1,256})['\"]",
    )
    for m in pair_re.finditer(blob):
        out[m.group(1)] = m.group(2)
    return out or None


def _result_from_dict(values: Dict[str, str], matcher: str) -> DiscoveryResult:
    res = DiscoveryResult(matchers_used=[matcher])
    extra: Dict[str, str] = {}
    for k, v in values.items():
        k_lower = k.lower()
        if k_lower in KNOWN_FIELDS:
            setattr(res, k_lower, v)
        else:
            extra[k] = v
    res.extra = extra
    return res


# ---------- public API ----------

def discover_from_body(body: str, source_url: str = "") -> DiscoveryResult:
    """Run all matchers against the given HTML/JS body and merge results."""
    final = DiscoveryResult(source_url=source_url)
    for _name, matcher in MATCHERS:
        partial = matcher(body)
        if partial is None:
            continue
        final.merge_fill(partial)
        final.matchers_used.extend(partial.matchers_used)
    return final


def discover_provider(
    discovery_urls: List[str],
    static_hints: Optional[Dict[str, str]] = None,
    fetcher: Optional[Callable[[str, str], str]] = None,
) -> DiscoveryResult:
    """Walk the discovery URLs in priority order, run matchers on each,
    merge, and finally fill any still-empty fields from static_hints.

    Args:
        discovery_urls: primary URL first, fallbacks after.
        static_hints: per-provider known-stable fields from the registry.
            Used only when discovery can't surface the field at runtime.
        fetcher: injection point for tests. Defaults to a urllib-based
            fetcher that sends DEFAULT_DISCOVERY_UA.

    Returns a DiscoveryResult. Caller checks `.is_usable()` to decide
    whether to surface an error to the user.
    """
    static_hints = static_hints or {}
    if fetcher is None:
        fetcher = _urllib_fetcher

    merged = DiscoveryResult()
    last_error = ""
    for url in discovery_urls:
        try:
            body = fetcher(url, DEFAULT_DISCOVERY_UA)
        except Exception as exc:
            last_error = "{}: {}".format(type(exc).__name__, exc)
            continue
        result = discover_from_body(body, source_url=url)
        had_requestor_before = merged.requestor_id is not None
        merged.merge_fill(result)
        # Track the URL that actually surfaced the requestor_id (the
        # field that gates is_usable). A fetched-but-empty fallback URL
        # shouldn't be advertised as the source in logs/diagnostics.
        if not had_requestor_before and merged.requestor_id is not None:
            merged.source_url = url
        if merged.is_usable():
            # Got a requestor_id; we can stop early if all KNOWN_FIELDS are
            # filled, otherwise keep walking fallbacks for the remaining bits.
            if all(getattr(merged, f) is not None for f in KNOWN_FIELDS):
                break

    # Backfill from static hints last — discovery wins over hints.
    for k, v in static_hints.items():
        if k in KNOWN_FIELDS and getattr(merged, k) is None:
            setattr(merged, k, v)

    if not merged.is_usable() and last_error:
        # Surface the network error so callers can show the user something
        # actionable instead of a silent failure.
        merged.extra["_discovery_error"] = last_error
    return merged


# ---------- Tier 2: JS-bundle scrape (lazy, on 451 retry) ----------

# Match `<script src="...">` tags, capturing the URL. Both single and
# double quoted, optional attributes around src. The negative lookbehind
# `(?<![-:\w])` rejects `data-src`, `xlink:src`, `mysrc`, etc. — `\b`
# alone isn't enough because `-` is a non-word char, so `\bsrc` happily
# matches the "src" tail of `data-src`.
_SCRIPT_SRC_RE = re.compile(
    r'<script\b[^>]*(?<![-:\w])src\s*=\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)

# Bound the per-provider bandwidth: most modern players ship dozens of
# webpack chunks, but we only need the ones that carry the Adobe Pass
# init values. The bundles that DO carry them tend to be the larger
# entry-point chunks. Five samples is enough in practice — going beyond
# starts looking like a scrape rather than a polite refresh.
_MAX_BUNDLES_TO_FETCH = 5


def _absolute_url(base: str, maybe_relative: str) -> str:
    """Resolve a relative `<script src=...>` against the page URL."""
    from urllib.parse import urljoin
    return urljoin(base, maybe_relative)


_DEFAULT_PORTS = {"http": 80, "https": 443}


def _same_origin(a: str, b: str) -> bool:
    """Return True if the two URLs share scheme + hostname + effective port.

    Browser origin semantics: scheme, host, and port must all match. We
    normalize the default port for each scheme so `https://example.com`
    is considered same-origin as `https://example.com:443` but NOT
    `https://example.com:8443`. (Earlier round used bare `netloc` which
    failed on explicit-default-port collisions; the followup using
    `hostname` alone went too far and dropped port discrimination
    entirely.)
    """
    from urllib.parse import urlparse
    pa, pb = urlparse(a), urlparse(b)
    port_a = pa.port if pa.port is not None else _DEFAULT_PORTS.get(pa.scheme)
    port_b = pb.port if pb.port is not None else _DEFAULT_PORTS.get(pb.scheme)
    return (pa.scheme, pa.hostname, port_a) == (pb.scheme, pb.hostname, port_b)


def discover_from_bundles(
    page_url: str,
    page_body: str,
    fetcher: Optional[Callable[[str, str], str]] = None,
    max_bundles: int = _MAX_BUNDLES_TO_FETCH,
) -> DiscoveryResult:
    """Tier 2 fallback: when the page HTML doesn't carry Adobe Pass
    init inline (the common case for modern players), follow the
    same-origin `<script src="...">` tags one hop deep and run the
    matchers over each bundle body.

    Capped at `max_bundles` URLs to keep traffic bounded — modern
    pages can load ~20 chunks but the entry-point chunks (which carry
    the Adobe Pass init) come first in the HTML, so the cap is enough.

    Returns a DiscoveryResult merged across whichever bundles produced
    matches. Mismatch detection (versus the registry's static_hints)
    is the caller's job — we just return whatever we find.
    """
    if fetcher is None:
        fetcher = _urllib_fetcher

    merged = DiscoveryResult(source_url=page_url)
    # Count *attempted* same-origin fetches, not just successful ones —
    # otherwise a 404/timeout cluster could push us well past max_bundles
    # in actual network traffic.
    attempted = 0
    # Dedup: pages routinely repeat the same `<script src="...">` tag
    # (e.g. once in <head> for preload and once in <body> for execution).
    # Fetching the same URL twice burns a slot off `max_bundles` without
    # surfacing any new values.
    seen_urls: set = set()
    for m in _SCRIPT_SRC_RE.finditer(page_body):
        if attempted >= max_bundles:
            break
        # HTML-unescape the captured attribute value before urljoin —
        # provider pages routinely encode `&` in query strings as `&amp;`
        # (e.g. `src="/app.js?v=1&amp;lang=en"`). Without unescaping the
        # fetch would go to a literal `&amp;` URL and 404.
        import html as _html
        raw_src = _html.unescape(m.group(1))
        bundle_url = _absolute_url(page_url, raw_src)
        if bundle_url in seen_urls:
            continue
        seen_urls.add(bundle_url)
        if not _same_origin(page_url, bundle_url):
            continue
        attempted += 1
        try:
            bundle_body = fetcher(bundle_url, DEFAULT_DISCOVERY_UA)
        except Exception:
            continue
        partial = discover_from_body(bundle_body, source_url=bundle_url)
        if partial.is_usable() or any(
            getattr(partial, f) is not None for f in KNOWN_FIELDS
        ):
            had_requestor_before = merged.requestor_id is not None
            merged.merge_fill(partial)
            merged.matchers_used.extend(
                "bundle:{}".format(name) for name in partial.matchers_used
            )
            # Only attribute source_url to a bundle when this is the bundle
            # that introduced requestor_id (None → set). Without this check
            # we'd overwrite source_url for any later bundle that happens to
            # carry the same requestor_id, blaming the wrong chunk in logs.
            if not had_requestor_before and merged.requestor_id is not None:
                merged.source_url = bundle_url
            # Bail early once everything's filled — the caller's only
            # interested in the merged values, not in walking the rest
            # of the chunks for free.
            if all(getattr(merged, f) is not None for f in KNOWN_FIELDS):
                break
    return merged


def refresh_against_bundles(
    discovery_urls: List[str],
    static_hints: Optional[Dict[str, str]] = None,
    fetcher: Optional[Callable[[str, str], str]] = None,
) -> DiscoveryResult:
    """Tier 2 entry point: fetch each page and walk its same-origin JS
    bundles for Adobe Pass init values. Intended for the 451-retry
    path in adobe_pass.py — the inline HTML scraper (`discover_provider`)
    has already run and either returned `client_version=None` or
    surfaced values that Adobe rejected.

    Precedence (different from `discover_provider`, deliberately):
      bundle > inline > static_hints
    On the 451 path we *want* bundle values to override inline ones,
    because the inline ones are what just got rejected. `discover_provider`
    has the opposite precedence (discovery wins) because it runs on the
    happy path where freshness matters more than overriding.
    """
    static_hints = static_hints or {}
    if fetcher is None:
        fetcher = _urllib_fetcher

    merged = DiscoveryResult()
    for url in discovery_urls:
        try:
            page = fetcher(url, DEFAULT_DISCOVERY_UA)
        except Exception:
            continue
        # Walk the page's JS bundles first so bundle-sourced values land
        # as the highest-precedence inputs into `merged` (merge_fill keeps
        # the existing value, so whichever side fills a field first wins).
        bundle = discover_from_bundles(url, page, fetcher=fetcher)
        had_requestor_before = merged.requestor_id is not None
        merged.merge_fill(bundle)
        merged.matchers_used.extend(bundle.matchers_used)
        if not had_requestor_before and merged.requestor_id is not None and bundle.source_url:
            merged.source_url = bundle.source_url

        # Inline matchers fill anything the bundle didn't surface.
        inline = discover_from_body(page, source_url=url)
        had_requestor_before = merged.requestor_id is not None
        merged.merge_fill(inline)
        merged.matchers_used.extend(inline.matchers_used)
        if not had_requestor_before and merged.requestor_id is not None and inline.source_url:
            merged.source_url = inline.source_url

        # Fallback: if we walked this URL and still have no source_url,
        # at least record the page URL — better than empty for logs.
        if not merged.source_url:
            merged.source_url = url
        if all(getattr(merged, f) is not None for f in KNOWN_FIELDS):
            break

    # Static hints fill anything still empty.
    for k, v in static_hints.items():
        if k in KNOWN_FIELDS and getattr(merged, k) is None:
            setattr(merged, k, v)
    return merged


# Bound a single fetch: modern JS bundles can be multi-MB; on constrained
# Kodi targets (RPi / Shield) we don't want a 451-triggered Tier 2 walk
# to spike memory or stall on a slow chunk. 2 MiB is plenty to carry the
# entry-point chunks that ship Adobe Pass init values (the larger media
# bundles past that boundary aren't useful for discovery).
_MAX_FETCH_BYTES = 2 * 1024 * 1024


def _urllib_fetcher(url: str, user_agent: str) -> str:
    """Default fetcher: urllib.request with a browser UA, 10s timeout,
    bounded read so a giant bundle can't OOM the host.

    Logs a warning via the stdlib `logging` module when truncation
    happens — otherwise a "discovery returned empty" failure on a
    too-large bundle is opaque. Callers using Kodi's logger can route
    the `aegis_tve_discovery` namespace through xbmc.log if they want.
    """
    import logging
    import urllib.request
    req = urllib.request.Request(url, headers={
        "User-Agent": user_agent,
        # Common Accept header so providers serve the rich-client HTML
        # rather than a minimal SEO/bot response.
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    # Read at most _MAX_FETCH_BYTES + 1 so we can detect over-budget
    # responses without buffering the whole body.
    with urllib.request.urlopen(req, timeout=10) as resp:
        raw = resp.read(_MAX_FETCH_BYTES + 1)
    if len(raw) > _MAX_FETCH_BYTES:
        logging.getLogger("aegis_tve_discovery").warning(
            "fetch from %s exceeded %d bytes; truncated. If discovery "
            "comes back empty for this URL, the config block may live "
            "past the truncation point — consider raising _MAX_FETCH_BYTES.",
            url, _MAX_FETCH_BYTES,
        )
        raw = raw[:_MAX_FETCH_BYTES]
    # Most provider pages are UTF-8; replace errors so a stray byte doesn't
    # take down discovery for the whole provider.
    return raw.decode("utf-8", errors="replace")
