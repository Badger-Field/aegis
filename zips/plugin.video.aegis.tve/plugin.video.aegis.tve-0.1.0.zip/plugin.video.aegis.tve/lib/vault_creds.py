"""MSO-keyed credential storage in the Aegis Vault.

Adobe Pass entitlements are gated by the **MSO** (cable provider), not by
the individual channel: one Telus subscription unlocks Sportsnet, TSN,
CTV, Crave, Citytv… every provider that lists Telus in `common_msos`. So
this module stores credentials once per MSO and only remembers which MSO
a user picked for each provider — the password lives in one place.

Vault layout (nested under one master key so we never collide with other
Aegis modules):

  {
    "tve": {
      "device_id": "<uuid>",            // stable across providers
      "msos": {
        "telus_auth-gateway_net": {"username": "...", "password": "..."},
        "spectrum":               {"username": "...", "password": "..."}
      },
      "providers": {
        "sportsnet-now": {"mso_id": "telus_auth-gateway_net"},
        "ctv":           {"mso_id": "telus_auth-gateway_net"},
        "espn":          {"mso_id": "spectrum"}
      },
      "tokens": {
        // Nested by MSO then requestor. Adobe mints aptokens scoped per
        // (MSO entitlement, requestor) pair, and nesting keeps each
        // component an independent dict key — a flat "<mso>|<requestor>"
        // string would be ambiguous if either side ever contained a
        // literal "|" (e.g. a user-typed MSO from the free-text path).
        "telus_auth-gateway_net": {
          "SportsnetNowCA": {"aptoken": "...", "expires_at": 1716250000},
          "TSN":            {"aptoken": "...", "expires_at": 1716260000}
        }
      }
    },
    "rd": {...},   // other Aegis modules' data — preserved on save
    "ad": {...}
  }

A legacy per-provider layout from the platform MVP (#11) gets migrated
on first read: per-provider `{username, password}` records are lifted
into the MSO record keyed by the provider's saved `mso_id`, and the
credential fields are stripped from the provider record. Idempotent.
"""
from __future__ import annotations

import os
import time
import uuid
from typing import Dict, Optional

try:
    import xbmc
    import xbmcvfs
    _XBMC_AVAILABLE = True
except ImportError:
    _XBMC_AVAILABLE = False


_VaultStore = None
_vault_error: Optional[str] = None


def _resolve_vault() -> Optional[type]:
    global _VaultStore, _vault_error
    if _VaultStore is not None or _vault_error:
        return _VaultStore
    try:
        from aegis_vault import VaultStore  # type: ignore
        _VaultStore = VaultStore
        return _VaultStore
    except ImportError as exc:
        _vault_error = "aegis_vault unavailable: {}".format(exc)
        return None


def _vault_dir() -> str:
    if _XBMC_AVAILABLE:
        return xbmcvfs.translatePath("special://masterprofile/aegis")
    return os.environ.get("AEGIS_VAULT_DIR", "")


def _log(msg: str, level: int = 1) -> None:
    if _XBMC_AVAILABLE:
        xbmc.log("plugin.video.aegis.tve.creds: " + msg, level)


def _read(vault_dir: Optional[str] = None) -> dict:
    cls = _resolve_vault()
    if cls is None:
        return {}
    base = vault_dir or _vault_dir()
    if not base:
        return {}
    try:
        data = cls(base).read()
    except Exception as exc:
        _log("vault read failed: {}".format(exc), 3)
        return {}
    if _migrate_legacy(data):
        # Persist the migrated layout so subsequent reads are clean and
        # we never accidentally regress to the old shape.
        try:
            cls(base).write(data)
        except Exception as exc:
            _log("legacy migration write failed: {}".format(exc), 3)
    return data


def _write(data: dict, vault_dir: Optional[str] = None) -> bool:
    cls = _resolve_vault()
    if cls is None:
        return False
    base = vault_dir or _vault_dir()
    if not base:
        return False
    try:
        cls(base).write(data)
        return True
    except Exception as exc:
        _log("vault write failed: {}".format(exc), 3)
        return False


def _tve_block(data: dict) -> dict:
    """Return the TVE sub-block with all sub-dicts initialized.

    Idempotent — safe to call on every read/write path.
    """
    if "tve" not in data or not isinstance(data["tve"], dict):
        data["tve"] = {}
    tve = data["tve"]
    for key in ("msos", "providers", "tokens"):
        if key not in tve or not isinstance(tve[key], dict):
            tve[key] = {}
    return tve


def _migrate_legacy(data: dict) -> bool:
    """Convert pre-PR-#14 per-provider creds to MSO-keyed records.

    Old shape was `tve.providers[pid] = {username, password, mso_id,
    aptoken*}`. Lift the credential pair into `tve.msos[mso_id]` (first
    one wins if multiple providers share an MSO), strip creds from the
    provider record, and move the cached token under the new
    `tve.tokens[mso_id|requestor_id]` key.

    Returns True if any change was made so the caller can flush to disk.
    """
    if not isinstance(data, dict) or "tve" not in data:
        return False
    tve = _tve_block(data)
    changed = False
    for pid, entry in list(tve["providers"].items()):
        if not isinstance(entry, dict):
            continue
        u = entry.pop("username", None)
        p = entry.pop("password", None)
        mso = entry.get("mso_id") or ""
        if u and p and mso and mso not in tve["msos"]:
            tve["msos"][mso] = {"username": u, "password": p}
            changed = True
        elif u or p:
            # Drop orphaned creds (no mso_id to attach to or MSO already
            # has creds from another provider). We've already popped the
            # fields off `entry`, so just record the mutation.
            changed = True

        aptoken = entry.pop("aptoken", None)
        exp = entry.pop("aptoken_expires_at", None)
        req = entry.pop("aptoken_requestor_id", None)
        if aptoken and exp and mso and req:
            mso_tokens = tve["tokens"].setdefault(mso, {})
            mso_tokens.setdefault(req, {
                "aptoken": aptoken,
                "expires_at": int(exp),
            })
            changed = True
        elif aptoken or exp or req:
            changed = True

        # Keep the provider record (it still carries mso_id), or drop it
        # if it became empty.
        if not entry:
            del tve["providers"][pid]
            changed = True
        else:
            tve["providers"][pid] = entry
    return changed


# ---------- public API ----------


def get_device_id(vault_dir: Optional[str] = None) -> str:
    """Return a stable device UUID for Adobe Pass. Persisted on first call."""
    data = _read(vault_dir)
    tve = _tve_block(data)
    if not tve.get("device_id"):
        tve["device_id"] = str(uuid.uuid4())
        _write(data, vault_dir)
    return tve["device_id"]


# ---------- MSO credentials ----------


def load_mso_creds(mso_id: str, vault_dir: Optional[str] = None) -> Optional[Dict[str, str]]:
    """Return {"username","password"} for the MSO, or None.

    A single MSO entitlement covers every provider listing this MSO in
    its `common_msos`, so callers should look up by MSO and skip the
    per-provider prompt entirely.
    """
    data = _read(vault_dir)
    tve = _tve_block(data)
    entry = tve["msos"].get(mso_id)
    if not entry:
        return None
    u = entry.get("username") or ""
    p = entry.get("password") or ""
    if not (u and p):
        return None
    return {"username": u, "password": p}


def save_mso_creds(mso_id: str, username: str, password: str,
                   vault_dir: Optional[str] = None) -> bool:
    """Store credentials for one MSO. Wipes any cached aptokens minted
    against this MSO since they were generated with the old password."""
    data = _read(vault_dir)
    tve = _tve_block(data)
    tve["msos"][mso_id] = {"username": username, "password": password}
    _drop_tokens_for_mso(tve, mso_id)
    return _write(data, vault_dir)


def clear_mso(mso_id: str, vault_dir: Optional[str] = None) -> bool:
    """Wipe creds AND cached tokens for one MSO. Provider→MSO links
    survive so the user keeps their per-provider MSO choice; the next
    open just re-prompts for credentials."""
    data = _read(vault_dir)
    tve = _tve_block(data)
    tve["msos"].pop(mso_id, None)
    _drop_tokens_for_mso(tve, mso_id)
    return _write(data, vault_dir)


def _drop_tokens_for_mso(tve: dict, mso_id: str) -> None:
    tve["tokens"].pop(mso_id, None)


# ---------- provider → MSO mapping ----------


def get_provider_mso(provider_id: str, vault_dir: Optional[str] = None) -> Optional[str]:
    """Return the MSO this provider was last signed into, or None."""
    data = _read(vault_dir)
    tve = _tve_block(data)
    entry = tve["providers"].get(provider_id) or {}
    return entry.get("mso_id") or None


def set_provider_mso(provider_id: str, mso_id: str,
                     vault_dir: Optional[str] = None) -> bool:
    """Remember which MSO this provider should authenticate against."""
    data = _read(vault_dir)
    tve = _tve_block(data)
    entry = tve["providers"].get(provider_id, {}) or {}
    entry["mso_id"] = mso_id
    tve["providers"][provider_id] = entry
    return _write(data, vault_dir)


def clear_provider_mso(provider_id: str, vault_dir: Optional[str] = None) -> bool:
    """Forget the provider's MSO choice (reverts to the picker on next open)."""
    data = _read(vault_dir)
    tve = _tve_block(data)
    if provider_id in tve["providers"]:
        del tve["providers"][provider_id]
        return _write(data, vault_dir)
    return True


# ---------- token cache ----------


def cache_token(mso_id: str, requestor_id: str, aptoken: str, expires_at: int,
                vault_dir: Optional[str] = None) -> bool:
    """Cache an Adobe Pass aptoken under tokens[mso_id][requestor_id].

    Same MSO subscription + different requestor (e.g., Telus auth used
    for Sportsnet vs. CTV) produces different aptokens, so the cache is
    keyed on both. Nested dicts (rather than a "<mso>|<requestor>"
    string key) keep the components unambiguous when an MSO ID contains
    arbitrary characters from the free-text picker fallback.
    """
    data = _read(vault_dir)
    tve = _tve_block(data)
    mso_tokens = tve["tokens"].setdefault(mso_id, {})
    mso_tokens[requestor_id] = {
        "aptoken": aptoken,
        "expires_at": int(expires_at),
    }
    return _write(data, vault_dir)


def load_cached_token(mso_id: str, requestor_id: str,
                      vault_dir: Optional[str] = None) -> Optional[Dict[str, str]]:
    """Return cached aptoken if present and unexpired, else None."""
    data = _read(vault_dir)
    tve = _tve_block(data)
    mso_tokens = tve["tokens"].get(mso_id) or {}
    entry = mso_tokens.get(requestor_id) or {}
    if not entry.get("aptoken") or not entry.get("expires_at"):
        return None
    if int(time.time()) >= int(entry["expires_at"]):
        return None
    return {
        "aptoken": entry["aptoken"],
        "expires_at": int(entry["expires_at"]),
        "requestor_id": requestor_id,
    }


# ---------- bulk read for directory-render callers ----------


def read_snapshot(vault_dir: Optional[str] = None) -> Dict[str, Dict[str, dict]]:
    """Return all `tve.*` sub-dicts in one vault read.

    `route_root()` renders the provider list and for each entry it needs
    to know (a) which MSO the provider points at and (b) whether that
    MSO has stored credentials. Calling load_mso_creds + get_provider_mso
    per provider does 2×N disk reads on the same vault; this helper
    folds all of that into a single read so the picker stays snappy
    even when the registry grows.

    Returns a dict with `providers`, `msos`, `tokens` sub-dicts so
    callers can do in-memory lookups directly.
    """
    data = _read(vault_dir)
    tve = _tve_block(data)
    # Shallow copies are enough — callers only read; mutating them would
    # be a bug but wouldn't corrupt the on-disk vault since `_write` is
    # never called with these.
    return {
        "providers": dict(tve.get("providers") or {}),
        "msos": dict(tve.get("msos") or {}),
        "tokens": dict(tve.get("tokens") or {}),
    }
