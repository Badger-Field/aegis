"""TV-Everywhere provider registry loader.

Loads `resources/tve_registry.json` and exposes typed query helpers.

The registry holds provider metadata (ID, label, country, the URL we'll
scrape to discover Adobe Pass init values, the MSO list) **plus** a
`static_hints` block that can ship researched Adobe Pass values
(`requestor_id`, `client_version`, `client_type`, `redirect_url`).

Phase 2 (Adobe Pass Discovery v2) two-tier auth model:

1. On every sign-in, runtime discovery (`discovery.discover_provider`)
   scrapes the player URL; `static_hints` backfill any field discovery
   left empty (discovery > hints precedence, since live values are
   usually freshest).
2. If Adobe responds 451 with the merged values, a Tier 2 JS-bundle
   scrape fires against the same URL(s) and the request retries once.

`last_verified` (YYYY-MM-DD) on each provider records when its hints
were last confirmed against the provider's app — empty means the hints
are sparse and the 451-retry path carries the load.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional


@dataclass(frozen=True)
class Provider:
    """Provider metadata.

    static_hints can carry researched Adobe Pass init values
    (`requestor_id`, `client_version`, `client_type`, `redirect_url`)
    used as a fallback when runtime discovery comes back empty. Each
    entry that ships hints should also set `last_verified` to a
    `YYYY-MM-DD` string so future maintainers know when the values were
    last confirmed against the provider's app — values older than ~6
    months are candidates for a re-research pass.
    """

    id: str
    label: str
    country: str
    primary_category: str
    discovery_url: str
    fallback_discovery_urls: tuple = field(default_factory=tuple)
    static_hints: Dict[str, str] = field(default_factory=dict)
    common_msos: tuple = field(default_factory=tuple)
    notes: str = ""
    last_verified: str = ""  # YYYY-MM-DD, empty if hints are unverified


class RegistryError(RuntimeError):
    pass


def _registry_path(addon_dir: Optional[Path] = None) -> Path:
    if addon_dir is None:
        addon_dir = Path(__file__).resolve().parent.parent
    return addon_dir / "resources" / "tve_registry.json"


def load_registry(addon_dir: Optional[Path] = None) -> Dict[str, Provider]:
    """Read and parse the on-disk registry.

    Returns a dict keyed by provider.id so callers can do O(1) lookups.
    Raises RegistryError on schema/parse failures so callers can surface a
    useful error to the user instead of letting a corrupt JSON kill the
    whole plugin.
    """
    path = _registry_path(addon_dir)
    if not path.exists():
        raise RegistryError("registry file missing: {}".format(path))
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise RegistryError("registry JSON invalid: {}".format(exc)) from exc

    schema_version = raw.get("schema_version")
    if schema_version != 1:
        raise RegistryError("unsupported registry schema_version {!r}".format(schema_version))

    providers_raw = raw.get("providers")
    if not isinstance(providers_raw, list):
        raise RegistryError("registry missing 'providers' list")

    out: Dict[str, Provider] = {}
    for entry in providers_raw:
        try:
            provider = Provider(
                id=entry["id"],
                label=entry["label"],
                country=entry["country"],
                primary_category=entry.get("primary_category", "general"),
                discovery_url=entry["discovery_url"],
                fallback_discovery_urls=tuple(entry.get("fallback_discovery_urls", [])),
                static_hints=dict(entry.get("static_hints", {})),
                common_msos=tuple(entry.get("common_msos", [])),
                notes=entry.get("notes", ""),
                last_verified=entry.get("last_verified", ""),
            )
        except KeyError as exc:
            raise RegistryError("provider entry missing required key {}: {!r}".format(exc, entry)) from exc
        if provider.id in out:
            raise RegistryError("duplicate provider id {!r}".format(provider.id))
        out[provider.id] = provider
    return out


def providers_by_country(registry: Dict[str, Provider], country: str) -> List[Provider]:
    """Return providers whose declared country matches `country` (case-insensitive)."""
    country = country.upper()
    return [p for p in registry.values() if p.country.upper() == country]


def all_discovery_urls(provider: Provider) -> List[str]:
    """Return primary + fallback discovery URLs in priority order."""
    return [provider.discovery_url, *provider.fallback_discovery_urls]
