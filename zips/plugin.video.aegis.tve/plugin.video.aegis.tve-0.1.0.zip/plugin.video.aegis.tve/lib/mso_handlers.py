"""Per-MSO login handlers used by adobe_pass.AdobePassClient.

Two layers:
  - `FormLoginHandler`: declarative single-page form-submit. Covers ~80% of
    MSOs that present a simple "username + password + button" landing.
  - `mso_custom/<id>.py`: per-MSO override for multi-page dances (Telus's
    four-bookend SOS path, providers that gate via OAuth, etc.).

`get_handler(mso_id)` is the dispatch table: returns a custom handler if
one is registered, otherwise the form handler with sane defaults.
"""
from __future__ import annotations

import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

try:
    # MSOLoginHandler is used in type annotations on _CUSTOM_HANDLERS and
    # get_handler — ruff sees those as forward-refs, hence the noqa.
    from .adobe_pass import (  # noqa: F401
        ADOBE_SAML_ACS_URLS,
        MSOLoginError,
        MSOLoginHandler,
    )
except ImportError:
    from adobe_pass import (  # noqa: F401
        ADOBE_SAML_ACS_URLS,
        MSOLoginError,
        MSOLoginHandler,
    )


# Form parsing: capture the WHOLE form (open tag + inner content) so we
# can read the action attribute and the inputs from one regex pass.
# Group 1: the entire <form ...> open tag (for action= extraction).
# Group 2: the inner content (for input/button extraction).
_FORM_RE = re.compile(r"(<form\b[^>]*>)(.*?)</form>", re.DOTALL | re.IGNORECASE)
_FORM_ACTION_RE = re.compile(r'\baction\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
# Match the whole input/button tag so we can pull name + optional value
# independently. Many real login pages omit value= on username/password
# inputs — the previous single-regex approach silently dropped those fields.
_INPUT_TAG_RE = re.compile(r"<(?:input|button)\b[^>]*?/?>", re.IGNORECASE)
_NAME_ATTR_RE = re.compile(r'\bname\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
_VALUE_ATTR_RE = re.compile(r'\bvalue\s*=\s*["\']([^"\']*)["\']', re.IGNORECASE)


def _extract_fields(inner: str) -> Dict[str, str]:
    fields: Dict[str, str] = {}
    for tag_match in _INPUT_TAG_RE.finditer(inner):
        tag = tag_match.group(0)
        name_m = _NAME_ATTR_RE.search(tag)
        if not name_m:
            continue
        value_m = _VALUE_ATTR_RE.search(tag)
        fields[name_m.group(1)] = value_m.group(1) if value_m else ""
    return fields


def parse_form(html: str, prefer_field: Optional[str] = None) -> Optional[Tuple[str, Dict[str, str]]]:
    """Return (action, fields) for the first form matching `prefer_field`
    (if given) or the first form on the page.

    Caller is responsible for resolving relative URLs against the page base.
    """
    matches = list(_FORM_RE.finditer(html))
    if not matches:
        return None

    # If the caller is looking for a specific field, score forms by it first.
    candidates: List[re.Match] = []
    if prefer_field:
        for m in matches:
            if re.search(
                r"\bname\s*=\s*[\"']" + re.escape(prefer_field) + r"[\"']",
                m.group(2),
                re.IGNORECASE,
            ):
                candidates.append(m)
    if not candidates:
        candidates = matches

    for m in candidates:
        open_tag = m.group(1)
        inner = m.group(2)
        action_match = _FORM_ACTION_RE.search(open_tag)
        action = action_match.group(1) if action_match else ""
        fields = _extract_fields(inner)
        if fields:
            return action, fields
    return None


def resolve_url(base: str, maybe_relative: str) -> str:
    """Resolve a possibly-relative URL (form action) against a base."""
    return urllib.parse.urljoin(base, maybe_relative)


def is_adobe_saml_acs(url: str) -> bool:
    """Did the MSO point us back at Adobe's SAML Assertion Consumer? That's
    the signal we're done with the MSO side."""
    lowered = url.lower()
    return any(lowered.startswith(prefix.lower()) for prefix in ADOBE_SAML_ACS_URLS)


# ---------- generic handler ----------


@dataclass
class FormLoginHandler:
    """Single-page form-driven MSO login.

    For MSOs that show one login page with `username` and `password` fields,
    POST → either land directly on Adobe's SAML ACS (rare) or get a
    SAMLResponse-bearing form to forward (common).

    Fields default to "username" / "password" but can be overridden per-MSO
    in the registry's static_hints (handler_username_field, handler_password_field).
    """

    username_field: str = "username"
    password_field: str = "password"
    # Maximum redirects/bookends we'll follow before giving up. Telus needs ~5.
    max_hops: int = 6

    def login(
        self,
        opener: urllib.request.OpenerDirector,
        initial_html: str,
        initial_url: str,
        username: str,
        password: str,
    ) -> Tuple[str, Dict[str, str]]:
        """Walk MSO forms until we find one bound for Adobe's SAML ACS.

        Pre-fills `username`/`password` into the first form that has them;
        forwards subsequent hidden-only forms as-is (typical SAML continue).
        """
        current_html = initial_html
        current_url = initial_url

        creds_submitted = False
        for hop in range(self.max_hops):
            parsed = parse_form(current_html)
            if parsed is None:
                raise MSOLoginError(
                    "no <form> found on hop {} at {}".format(hop, current_url)
                )
            action, fields = parsed
            action_abs = resolve_url(current_url, action) if action else current_url

            if is_adobe_saml_acs(action_abs):
                # We're done. Return the SAMLResponse-bearing form to caller.
                return action_abs, fields

            # If this form has a password field, fill creds. Many MSO chains
            # have an intermediate "continue" page with hidden fields only;
            # those just get re-POSTed as-is.
            has_password_field = self.password_field in fields
            if has_password_field and not creds_submitted:
                fields[self.username_field] = username
                fields[self.password_field] = password
                creds_submitted = True

            # Refuse HTTP for password-bearing posts.
            if has_password_field and not action_abs.lower().startswith("https://"):
                raise MSOLoginError(
                    "refusing to POST credentials to non-HTTPS action: {!r}".format(action_abs)
                )

            try:
                resp = opener.open(
                    urllib.request.Request(
                        action_abs,
                        data=urllib.parse.urlencode(fields).encode("utf-8"),
                        headers={"User-Agent": _BROWSER_UA},
                    ),
                    timeout=15,
                )
                current_html = resp.read().decode("utf-8", errors="replace")
                current_url = resp.url
            except urllib.error.HTTPError as exc:
                raise MSOLoginError("HTTP {} from {}".format(exc.code, action_abs)) from exc
            except urllib.error.URLError as exc:
                raise MSOLoginError("network error at {}: {}".format(action_abs, exc)) from exc

        raise MSOLoginError(
            "MSO form chain exceeded max_hops={} without reaching Adobe SAML ACS".format(
                self.max_hops
            )
        )


_BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)


# ---------- dispatch ----------


# Registered custom handlers keyed by MSO ID (registry value, not display label).
_CUSTOM_HANDLERS: Dict[str, MSOLoginHandler] = {}


def register_handler(mso_id: str, handler: MSOLoginHandler) -> None:
    """mso_custom/*.py modules call this at import time to register."""
    _CUSTOM_HANDLERS[mso_id] = handler


def get_handler(mso_id: str, registry_hints: Optional[Dict[str, str]] = None) -> MSOLoginHandler:
    """Return the right handler for `mso_id`. Falls back to FormLoginHandler
    customized via registry hints (`handler_username_field` etc)."""
    if mso_id in _CUSTOM_HANDLERS:
        return _CUSTOM_HANDLERS[mso_id]
    hints = registry_hints or {}
    return FormLoginHandler(
        username_field=hints.get("handler_username_field", "username"),
        password_field=hints.get("handler_password_field", "password"),
        max_hops=int(hints.get("handler_max_hops", "6")),
    )


# Auto-import any per-MSO custom handlers so they self-register.
def _import_custom_handlers() -> None:
    from pathlib import Path
    custom_dir = Path(__file__).parent / "mso_custom"
    if not custom_dir.exists():
        return
    # Python 3 requires importing importlib.util explicitly — `import importlib`
    # alone does NOT bring in the submodule we need for spec_from_file_location.
    import importlib.util
    import sys
    for py_file in custom_dir.glob("*.py"):
        if py_file.name.startswith("_"):
            continue
        mod_name = "_aegis_tve_mso_" + py_file.stem
        if mod_name in sys.modules:
            continue
        spec = importlib.util.spec_from_file_location(mod_name, py_file)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[mod_name] = module
            try:
                spec.loader.exec_module(module)
            except Exception:
                # A broken custom handler shouldn't kill the whole dispatch.
                sys.modules.pop(mod_name, None)


# Avoid circular import issues by deferring import to first dispatch.
def _ensure_custom_loaded() -> None:
    if not getattr(_ensure_custom_loaded, "_done", False):
        _import_custom_handlers()
        _ensure_custom_loaded._done = True


# Wrap get_handler so custom handlers load lazily.
_orig_get_handler = get_handler


def get_handler(mso_id: str, registry_hints: Optional[Dict[str, str]] = None) -> MSOLoginHandler:  # noqa: F811
    _ensure_custom_loaded()
    return _orig_get_handler(mso_id, registry_hints)
