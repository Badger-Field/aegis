"""Generic Adobe Pass (Adobe Primetime) SAML authentication flow.

Replaces the per-MSO-handwritten flow that legacy TVE addons (snnow,
plugin.video.usa, etc.) used to implement. This module knows the Adobe
side of the dance; the MSO side is delegated to a pluggable handler so
adding a new provider/MSO doesn't require touching this file.

Flow overview (each step is HTTP via a shared cookie jar):

    ┌─ Client ─┐                ┌── Adobe ──┐               ┌── MSO ──┐
    │           │ GET /authenticate/saml ─▶│                          │
    │           │◀── 302 to MSO IDP ────────│                          │
    │           │ GET MSO login URL ────────────────────────▶│         │
    │           │◀── HTML login form ───────────────────────│          │
    │           │  (mso_handler.login runs the form dance,  │          │
    │           │   may be 1 POST or N-page like Telus)     │          │
    │           │ POST SAMLResponse back ──▶│                          │
    │           │◀── 200 with aptoken ──────│                          │
    └───────────┘                           └──────────────┘           ┘

We exchange the resulting aptoken for resource authorization tokens via
`authorize_resource()`. Callers (default.py) cache the aptoken in the
Aegis Vault and skip re-login until expiry.
"""
from __future__ import annotations

import http.cookiejar
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Protocol, Tuple

try:
    from .discovery import DiscoveryResult
except ImportError:  # pytest / standalone
    from discovery import DiscoveryResult


ADOBE_AUTHN_BASE = "https://sp.auth.adobe.com/adobe-services/authenticate/saml"
ADOBE_AUTHZ_BASE = "https://sp.auth.adobe.com/api/v1/authorize"
ADOBE_TOKEN_BASE = "https://sp.auth.adobe.com/api/v1/tokens"
ADOBE_SAML_ACS_URLS = (
    "https://sp.auth.adobe.com/sp/saml/SAMLAssertionConsumer",
    "https://sp.auth.adobe.com/saml/module.php/saml/sp/saml2-acs.php",
)


@dataclass
class AdobePassToken:
    """A successfully-minted Adobe Pass authn token + metadata."""

    requestor_id: str
    mso_id: str
    aptoken: str
    expires_at: int  # unix epoch seconds
    device_id: str
    # Adobe sometimes returns a separate short-authorize token used for
    # device-flow requests; we record it if present so the resource
    # authorize step can reuse it.
    aprid: Optional[str] = None

    def is_expired(self, now: Optional[int] = None) -> bool:
        now = now if now is not None else int(time.time())
        return now >= self.expires_at


class MSOLoginError(RuntimeError):
    """The MSO-side login failed (bad creds, page format changed, network)."""


class AdobePassError(RuntimeError):
    """Adobe Pass refused the request (451 client too old, 500, bad SAML)."""


class MSOLoginHandler(Protocol):
    """Pluggable per-MSO auth.

    The handler runs whatever multi-page form dance the MSO requires. It
    must use the supplied opener so cookies set by the MSO carry into the
    final POST back to Adobe.

    Returns a (action_url, form_data) tuple that the caller will POST to
    finish the SAML round-trip back to Adobe. The form_data must contain
    at least 'SAMLResponse' and 'RelayState' for Adobe to accept.
    """

    def login(
        self,
        opener: urllib.request.OpenerDirector,
        initial_html: str,
        initial_url: str,
        username: str,
        password: str,
    ) -> Tuple[str, Dict[str, str]]: ...


@dataclass
class AdobePassClient:
    """Stateful Adobe Pass client. Reuses one cookie jar across the SAML
    round-trip so the MSO and Adobe sides see consistent session state."""

    discovery: DiscoveryResult
    device_id: str = ""
    logger: Optional[Callable[[str], None]] = None
    # Provider's player URLs (registry discovery_url + fallback_discovery_urls)
    # — needed by the 451 retry path when `discovery.source_url` is empty
    # (which happens whenever requestor_id came from static_hints instead of
    # a successful inline scrape). Without this, Tier 1-only providers can't
    # ever recover via Tier 2.
    discovery_urls: List[str] = field(default_factory=list)
    _cookie_jar: http.cookiejar.CookieJar = field(default_factory=http.cookiejar.CookieJar)

    def __post_init__(self):
        if not self.device_id:
            # Adobe Pass requires a stable per-device UUID across requests.
            # Caller normally pulls one from the Aegis Vault; we generate a
            # fresh one here only as a last resort.
            self.device_id = str(uuid.uuid4())

    @property
    def opener(self) -> urllib.request.OpenerDirector:
        return urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(self._cookie_jar)
        )

    def _log(self, msg: str) -> None:
        if self.logger:
            self.logger(msg)

    def _required(self, field_name: str) -> str:
        """Pull a discovered field; raise AdobePassError if missing."""
        v = getattr(self.discovery, field_name, None)
        if not v:
            raise AdobePassError(
                "discovery did not surface required field {!r} for {!r}; "
                "static_hints in the registry may need a fallback".format(
                    field_name, self.discovery.requestor_id
                )
            )
        return v

    def authenticate(
        self,
        mso_id: str,
        username: str,
        password: str,
        mso_handler: MSOLoginHandler,
        *,
        _retried: bool = False,
    ) -> AdobePassToken:
        """Run the full SAML authentication flow. Returns an AdobePassToken
        on success; raises MSOLoginError or AdobePassError on failure.

        `_retried` is the per-call guard for the 451 → Tier 2 retry path,
        keyword-only so external callers can't accidentally pass it
        positionally: the initial call defaults to False; the recursive
        retry passes True so a permanent 451 can't loop. Per-call (rather
        than per-client) so callers can reuse a single AdobePassClient across
        multiple sign-ins without losing the recovery ability after the
        first 451.
        """
        requestor_id = self._required("requestor_id")

        params: Dict[str, str] = {
            "domain_name": "adobe.com",
            "noflash": "true",
            "no_iframe": "true",
            "mso_id": mso_id,
            "requestor_id": requestor_id,
        }
        for opt in ("client_type", "client_version", "redirect_url"):
            v = getattr(self.discovery, opt, None)
            if v:
                params[opt] = v
        params.setdefault("redirect_url", "https://example.com/oauth/callback")

        authn_url = "{}?{}".format(ADOBE_AUTHN_BASE, urllib.parse.urlencode(params))
        self._log("adobe_pass: GET {}".format(authn_url))

        opener = self.opener
        try:
            resp = opener.open(_browser_request(authn_url), timeout=15)
            body = resp.read().decode("utf-8", errors="replace")
            initial_url = resp.url
        except urllib.error.HTTPError as exc:
            # 451 = Adobe rejected the call as legally-unavailable, which
            # is also what they return for stale client_version / unknown
            # client_type. Per the Phase 2 plan: when that happens, run
            # the Tier 2 JS-bundle scraper against the provider's player
            # URL to pick up the current values, then retry once. Other
            # HTTP errors (5xx, 4xx that aren't 451) skip the retry —
            # discovery wouldn't help those.
            if exc.code == 451 and not _retried:
                self._log(
                    "adobe_pass: 451 with client_version={!r} — kicking Tier 2 "
                    "bundle scrape and retrying once".format(self.discovery.client_version)
                )
                refreshed = self._try_bundle_refresh()
                if refreshed is not None:
                    self.discovery = refreshed
                    return self.authenticate(
                        mso_id, username, password, mso_handler, _retried=True,
                    )
            raise AdobePassError(
                "Adobe Pass {} on initial authenticate (likely stale "
                "client_version={!r} or unregistered requestor_id={!r}; "
                "discovery may need a refresh)".format(
                    exc.code, self.discovery.client_version, requestor_id
                )
            ) from exc
        except urllib.error.URLError as exc:
            raise AdobePassError("Adobe Pass network failure: {}".format(exc)) from exc

        self._log("adobe_pass: MSO landing at {}".format(initial_url))

        # Hand off to the MSO handler for the login dance. The handler must
        # return (action_url, form_data) for the final POST back to Adobe.
        try:
            action_url, form_data = mso_handler.login(opener, body, initial_url, username, password)
        except MSOLoginError:
            raise
        except Exception as exc:
            raise MSOLoginError(
                "MSO handler raised {}: {}".format(type(exc).__name__, exc)
            ) from exc

        if not action_url or not action_url.lower().startswith("https://"):
            raise MSOLoginError(
                "MSO handler returned non-HTTPS action {!r} — refusing to "
                "POST SAMLResponse over plain HTTP".format(action_url)
            )
        if "SAMLResponse" not in form_data:
            raise MSOLoginError(
                "MSO handler returned form without SAMLResponse; got keys {}".format(
                    sorted(form_data.keys())
                )
            )

        self._log("adobe_pass: posting SAMLResponse to {}".format(action_url))
        try:
            resp = opener.open(
                _browser_request(action_url, data=urllib.parse.urlencode(form_data).encode("utf-8")),
                timeout=15,
            )
            body = resp.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as exc:
            raise AdobePassError(
                "Adobe Pass {} after MSO login; the SAMLResponse may be "
                "invalid or the requestor_id has lost MSO entitlement".format(exc.code)
            ) from exc
        except urllib.error.URLError as exc:
            raise AdobePassError(
                "Adobe Pass network failure during SAMLResponse POST: {}".format(exc)
            ) from exc

        token = self._parse_token_response(body, requestor_id, mso_id)
        if token is None:
            raise AdobePassError(
                "Adobe Pass response after SAMLResponse did not contain an "
                "aptoken; first 200 bytes: {!r}".format(body[:200])
            )
        return token

    # ---- helpers ----

    def _try_bundle_refresh(self) -> Optional[DiscoveryResult]:
        """Run Tier 2 (JS-bundle) discovery against the provider's
        player URL and return the refreshed values, or None if the
        scrape couldn't surface anything usable.

        Mismatches between the scraped values and what's currently on
        `self.discovery` are logged as warnings so a future telemetry /
        opt-in error-report path can surface stale-hint drift before
        more users hit the 451.
        """
        try:
            from .discovery import KNOWN_FIELDS, refresh_against_bundles
        except ImportError:  # pytest / standalone
            from discovery import KNOWN_FIELDS, refresh_against_bundles

        # Build the URL list to scrape. Always put the registry's
        # discovery URLs first — those are HTML player pages that the
        # bundle walker can extract `<script src>` tags from. Only fall
        # through to `self.discovery.source_url` (which can point at a
        # specific JS chunk after a prior Tier 2 refresh) as a last
        # resort; a stale bundle URL alone has no further `<script src>`
        # tags to follow and could anchor a stale-value scrape that the
        # player page would override.
        urls = list(self.discovery_urls or [])
        source = self.discovery.source_url
        if source and source not in urls:
            if _looks_like_html_page(source):
                urls.insert(0, source)
            else:
                urls.append(source)  # last-resort
        if not urls:
            self._log(
                "adobe_pass: bundle refresh skipped — no source_url and no "
                "discovery_urls plumbed in (caller must pass registry URLs)"
            )
            return None

        # Run Tier 2 with NO carry-forward — we want it to return only
        # what it actually scraped (bundle + inline). Mixing in
        # `self.discovery` here would make the "did anything change?"
        # check below trivially false in the worst case (and trivially
        # true in the best). We compose carry-forward ourselves after
        # the change-detection gate.
        refreshed = refresh_against_bundles(urls, static_hints={})

        # Did Tier 2 actually surface anything useful? Compare only the
        # fields authenticate() actually sends to Adobe — requestor_id +
        # the three SAML params. KNOWN_FIELDS is broader (includes
        # client_id / domain_name which we never serialize into the
        # authn URL), so a bundle that only changes those would
        # otherwise trigger a guaranteed-identical retry.
        _AUTHN_FIELDS = ("requestor_id", "client_version", "client_type", "redirect_url")
        changed = [
            f for f in _AUTHN_FIELDS
            if getattr(refreshed, f, None) is not None
            and getattr(refreshed, f) != getattr(self.discovery, f, None)
        ]
        if not changed:
            self._log(
                "adobe_pass: bundle refresh surfaced no new values "
                "(authn-affecting fields unchanged vs current discovery) — "
                "skipping retry to avoid a guaranteed second 451"
            )
            return None
        self._log("adobe_pass: bundle refresh changed fields: {}".format(changed))

        # Build the final discovery for the retry: refresh wins where it
        # surfaced a value; current discovery (which carries Tier 1 hints
        # + any earlier inline scrape) fills the rest. This prevents a
        # partial bundle scrape (new client_version but no client_type)
        # from regressing previously-known fields.
        final = DiscoveryResult(
            matchers_used=list(refreshed.matchers_used),
            source_url=refreshed.source_url or self.discovery.source_url,
            extra=dict(refreshed.extra),
        )
        for f in KNOWN_FIELDS:
            v = getattr(refreshed, f, None)
            if v is None:
                v = getattr(self.discovery, f, None)
            if v is not None:
                setattr(final, f, v)

        # Log drift on the SAML params so stale registry hints surface
        # in user logs (telemetry / opt-in error reports later can use
        # this to flag entries that need a re-research pass).
        for f in ("client_version", "client_type", "redirect_url"):
            old = getattr(self.discovery, f, None)
            new = getattr(refreshed, f, None)
            if old and new and old != new:
                self._log(
                    "adobe_pass: bundle scrape says {}={!r} but discovery had "
                    "{!r} — registry static_hints may be stale".format(f, new, old)
                )

        return final


    _APTOKEN_RE = re.compile(r"<simpleToken>(.+?)</simpleToken>", re.DOTALL)
    _EXPIRES_RE = re.compile(r"<expires>(\d+)</expires>")

    def _parse_token_response(
        self, body: str, requestor_id: str, mso_id: str
    ) -> Optional[AdobePassToken]:
        """Adobe returns XML or JSON depending on Accept headers; try both."""
        # XML path.
        try:
            root = ET.fromstring(body)
            simple_token = root.findtext("simpleToken") or root.findtext(".//simpleToken")
            expires = root.findtext("expires") or root.findtext(".//expires")
            if simple_token and expires:
                return AdobePassToken(
                    requestor_id=requestor_id,
                    mso_id=mso_id,
                    aptoken=simple_token,
                    expires_at=int(expires) // 1000 if int(expires) > 10**11 else int(expires),
                    device_id=self.device_id,
                )
        except ET.ParseError:
            pass

        # Regex fallback if Adobe returns mixed HTML+XML.
        m_tok = self._APTOKEN_RE.search(body)
        m_exp = self._EXPIRES_RE.search(body)
        if m_tok and m_exp:
            exp = int(m_exp.group(1))
            return AdobePassToken(
                requestor_id=requestor_id,
                mso_id=mso_id,
                aptoken=m_tok.group(1).strip(),
                expires_at=exp // 1000 if exp > 10**11 else exp,
                device_id=self.device_id,
            )
        return None


# Path extensions a Tier 2 bundle walk can produce as source_url. Anything
# in this set looks like a JS chunk rather than the player HTML page, so
# we demote it below registry discovery URLs on a 451 retry.
_BUNDLE_EXTENSIONS = frozenset({".js", ".mjs", ".cjs", ".css", ".map"})


def _looks_like_html_page(url: str) -> bool:
    """True if `url`'s path looks like a player HTML page rather than a
    JS chunk. Trailing-slash and bare-path URLs (no extension) match;
    explicit .html/.htm match; anything ending in a bundle extension
    (.js/.mjs/etc.) does not. Strips ?query / #fragment before checking."""
    if not url:
        return False
    path = url.split("?", 1)[0].split("#", 1)[0]
    if path.endswith("/") or path.endswith((".html", ".htm")):
        return True
    last_dot = path.rfind(".")
    last_slash = path.rfind("/")
    if last_dot <= last_slash:
        # No file extension after the last path segment — looks like /watch,
        # /player/foo, etc. Treat as page.
        return True
    ext = path[last_dot:].lower()
    return ext not in _BUNDLE_EXTENSIONS


def _browser_request(url: str, data: Optional[bytes] = None) -> urllib.request.Request:
    """Build a Request with a browser User-Agent so Adobe/MSOs don't 451 us."""
    return urllib.request.Request(
        url,
        data=data,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )
