from __future__ import annotations

import hashlib
import hmac
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from _chacha20poly1305 import InvalidTag, decrypt as _aead_decrypt, encrypt as _aead_encrypt


class VaultTamperError(RuntimeError):
    pass


class VaultBackupError(RuntimeError):
    """Raised when a portable backup can't be produced or restored (wrong
    passphrase, corrupt/foreign file, unsupported version)."""


# Portable backup format. UNLIKE the on-disk vault (whose key is machine-bound
# via DPAPI/Keychain and therefore un-restorable on another device), a backup is
# encrypted with a key derived from a USER passphrase so it can be carried to a
# new install or survive a vault wipe. Layout:
#   AEGIS-BACKUP-V1\n | 16B salt | 12B nonce | 16B tag | ChaCha20-Poly1305(ct)
# KDF is PBKDF2-HMAC-SHA256 (stdlib-only, no OpenSSL-scrypt/maxmem quirks on
# Android) over the UTF-8 passphrase.
_BACKUP_MAGIC = b"AEGIS-BACKUP-V1\n"
_BACKUP_SALT_LEN = 16
_BACKUP_PBKDF2_ITERS = 200_000


class VaultStore:
    _KEY_MAGIC = b"AEGIS-KEY-V1\n"
    # Vault payload format header. Distinguishes V2 (ChaCha20-Poly1305 via
    # pycryptodome) from V1 (pynacl XChaCha20-Poly1305 — Windows-only and
    # ripped out in 0.1.2). On read, a missing/mismatched header forces a
    # wipe + re-OAuth; V1 ciphertext is unreadable without pynacl anyway.
    _PAYLOAD_MAGIC = b"AEGIS-V2-CC20P\n"
    _NONCE_LEN = 12
    _TAG_LEN = 16

    def __init__(self, base_dir: str | Path):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.key_path = self.base_dir / "vault.key"
        self.bin_path = self.base_dir / "vault.bin"
        self.mac_path = self.base_dir / "vault.mac"

    def _wrap_method(self) -> str:
        if os.name == "nt":
            return "dpapi"
        if sys.platform == "darwin":
            return "keychain"
        return "raw"

    def _write_private_file(self, path: Path, data: bytes) -> None:
        path.write_bytes(data)
        try:
            os.chmod(path, 0o600)
        except OSError:
            # Best effort only. Some filesystems/platforms may not support chmod.
            pass

    def _dpapi_protect(self, data: bytes) -> bytes:
        import ctypes
        from ctypes import wintypes

        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

        in_blob = DATA_BLOB()
        in_blob.cbData = len(data)
        in_blob.pbData = ctypes.cast(ctypes.create_string_buffer(data), ctypes.POINTER(ctypes.c_byte))

        out_blob = DATA_BLOB()
        CRYPTPROTECT_UI_FORBIDDEN = 0x1
        if not crypt32.CryptProtectData(
            ctypes.byref(in_blob),
            None,
            None,
            None,
            None,
            CRYPTPROTECT_UI_FORBIDDEN,
            ctypes.byref(out_blob),
        ):
            raise RuntimeError("DPAPI key protection failed")

        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            kernel32.LocalFree(out_blob.pbData)

    def _dpapi_unprotect(self, data: bytes) -> bytes:
        import ctypes
        from ctypes import wintypes

        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

        in_blob = DATA_BLOB()
        in_blob.cbData = len(data)
        in_blob.pbData = ctypes.cast(ctypes.create_string_buffer(data), ctypes.POINTER(ctypes.c_byte))

        out_blob = DATA_BLOB()
        CRYPTPROTECT_UI_FORBIDDEN = 0x1
        if not crypt32.CryptUnprotectData(
            ctypes.byref(in_blob),
            None,
            None,
            None,
            None,
            CRYPTPROTECT_UI_FORBIDDEN,
            ctypes.byref(out_blob),
        ):
            raise RuntimeError("DPAPI key unprotection failed")

        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            kernel32.LocalFree(out_blob.pbData)

    def _keychain_service(self) -> str:
        return "aegis.vault"

    def _keychain_account(self) -> str:
        return str(self.base_dir.resolve())

    def _keychain_store(self, key: bytes) -> None:
        key_hex = key.hex()
        subprocess.run(
            [
                "security",
                "add-generic-password",
                "-U",
                "-s",
                self._keychain_service(),
                "-a",
                self._keychain_account(),
                "-w",
                key_hex,
            ],
            check=True,
            capture_output=True,
            text=True,
        )

    def _keychain_load(self) -> bytes:
        completed = subprocess.run(
            [
                "security",
                "find-generic-password",
                "-s",
                self._keychain_service(),
                "-a",
                self._keychain_account(),
                "-w",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        return bytes.fromhex(completed.stdout.strip())

    def _encode_wrapped_key(self, method: str, payload: bytes) -> bytes:
        return self._KEY_MAGIC + method.encode("ascii") + b"\n" + payload

    def _decode_wrapped_key(self, data: bytes) -> tuple[str, bytes]:
        if not data.startswith(self._KEY_MAGIC):
            return "legacy", data
        rest = data[len(self._KEY_MAGIC) :]
        split_at = rest.find(b"\n")
        if split_at <= 0:
            raise ValueError("Invalid wrapped key format")
        method = rest[:split_at].decode("ascii")
        payload = rest[split_at + 1 :]
        return method, payload

    def _create_and_persist_key(self) -> bytes:
        key = os.urandom(32)
        method = self._wrap_method()

        if method == "dpapi":
            payload = self._dpapi_protect(key)
            self._write_private_file(self.key_path, self._encode_wrapped_key("dpapi", payload))
            return key

        if method == "keychain":
            # Keep only a marker on disk; key bytes are persisted in Keychain.
            self._keychain_store(key)
            self._write_private_file(self.key_path, self._encode_wrapped_key("keychain", b"stored"))
            return key

        self._write_private_file(self.key_path, key)
        return key

    def _load_or_create_key(self) -> bytes:
        if not self.key_path.exists():
            return self._create_and_persist_key()

        raw = self.key_path.read_bytes()
        method, payload = self._decode_wrapped_key(raw)

        if method == "legacy":
            key = payload
        elif method == "dpapi":
            key = self._dpapi_unprotect(payload)
        elif method == "keychain":
            key = self._keychain_load()
        else:
            raise ValueError("Unsupported key wrapping method: {}".format(method))

        if len(key) != 32:
            raise ValueError("Vault key must be exactly 32 bytes")
        return key

    def _compute_hmac(self, data: bytes, key: bytes) -> bytes:
        return hmac.new(key, data, hashlib.sha256).digest()

    def _verify_integrity(self, encrypted: bytes, key: bytes) -> None:
        if not self.mac_path.exists():
            return
        expected = self.mac_path.read_bytes()
        actual = self._compute_hmac(encrypted, key)
        if not hmac.compare_digest(expected, actual):
            self.wipe()
            raise VaultTamperError("Vault integrity check failed; vault has been wiped")

    def _encrypt(self, key: bytes, plaintext: bytes) -> bytes:
        nonce = os.urandom(self._NONCE_LEN)
        ciphertext, tag = _aead_encrypt(key, nonce, plaintext)
        return self._PAYLOAD_MAGIC + nonce + tag + ciphertext

    def _decrypt(self, key: bytes, payload: bytes) -> bytes:
        if not payload.startswith(self._PAYLOAD_MAGIC):
            # Unrecognised header — either a V1 pynacl vault from a pre-0.1.2
            # build (unreadable without pynacl) or a corrupted file. Either way
            # wipe and force re-OAuth on next launch.
            self.wipe()
            raise VaultTamperError(
                "Vault payload format not recognised; vault has been wiped (re-run setup)"
            )
        body = payload[len(self._PAYLOAD_MAGIC) :]
        nonce = body[: self._NONCE_LEN]
        tag = body[self._NONCE_LEN : self._NONCE_LEN + self._TAG_LEN]
        ciphertext = body[self._NONCE_LEN + self._TAG_LEN :]
        try:
            return _aead_decrypt(key, nonce, ciphertext, tag)
        except InvalidTag as exc:
            self.wipe()
            raise VaultTamperError(
                "Vault authentication failed; vault has been wiped (re-run setup)"
            ) from exc

    def read(self) -> dict[str, Any]:
        key = self._load_or_create_key()
        if not self.bin_path.exists():
            return {}

        payload = self.bin_path.read_bytes()
        self._verify_integrity(payload, key)
        clear = self._decrypt(key, payload)
        return json.loads(clear.decode("utf-8"))

    def write(self, values: dict[str, Any]) -> None:
        key = self._load_or_create_key()
        payload = json.dumps(values, separators=(",", ":"), sort_keys=True).encode("utf-8")
        encrypted = self._encrypt(key, payload)
        self.bin_path.write_bytes(encrypted)
        self.mac_path.write_bytes(self._compute_hmac(encrypted, key))

    def upsert(self, key_name: str, value: Any) -> dict[str, Any]:
        current = self.read()
        current[key_name] = value
        self.write(current)
        return current

    def wipe(self) -> None:
        for path in (self.bin_path, self.mac_path):
            if path.exists():
                size = path.stat().st_size
                path.write_bytes(b" " * size)
                path.unlink()

    # --- Portable, passphrase-encrypted backup/restore -----------------------

    @staticmethod
    def _derive_backup_key(passphrase: str, salt: bytes) -> bytes:
        if not passphrase:
            raise VaultBackupError("A passphrase is required for vault backups")
        return hashlib.pbkdf2_hmac(
            "sha256", passphrase.encode("utf-8"), salt, _BACKUP_PBKDF2_ITERS, dklen=32
        )

    def export_backup(self, passphrase: str) -> bytes:
        """Return a portable, passphrase-encrypted snapshot of the vault.

        The snapshot decrypts the local (machine-key-wrapped) vault, then
        re-encrypts the plaintext under a passphrase-derived key so it can be
        restored on ANY device — unlike the raw vault.bin, whose DPAPI/Keychain
        key never leaves the machine that created it.
        """
        data = self.read()
        plaintext = json.dumps(data, separators=(",", ":"), sort_keys=True).encode("utf-8")
        salt = os.urandom(_BACKUP_SALT_LEN)
        key = self._derive_backup_key(passphrase, salt)
        nonce = os.urandom(self._NONCE_LEN)
        ciphertext, tag = _aead_encrypt(key, nonce, plaintext)
        return _BACKUP_MAGIC + salt + nonce + tag + ciphertext

    def import_backup(self, blob: bytes, passphrase: str, *, merge: bool = False) -> dict[str, Any]:
        """Restore a backup produced by `export_backup` into THIS vault.

        Decrypts `blob` with the passphrase and writes the result into the local
        vault (re-wrapping under this machine's key). With merge=False (default)
        the vault is replaced wholesale; with merge=True the backup's top-level
        keys are merged over the current vault (backup wins on conflict).

        Raises VaultBackupError on a foreign/corrupt file or wrong passphrase.
        """
        if not blob.startswith(_BACKUP_MAGIC):
            raise VaultBackupError("Not an Aegis vault backup (bad header)")
        body = blob[len(_BACKUP_MAGIC):]
        min_len = _BACKUP_SALT_LEN + self._NONCE_LEN + self._TAG_LEN
        if len(body) < min_len:
            raise VaultBackupError("Backup file is truncated")
        salt = body[:_BACKUP_SALT_LEN]
        nonce = body[_BACKUP_SALT_LEN:_BACKUP_SALT_LEN + self._NONCE_LEN]
        tag = body[_BACKUP_SALT_LEN + self._NONCE_LEN:_BACKUP_SALT_LEN + self._NONCE_LEN + self._TAG_LEN]
        ciphertext = body[_BACKUP_SALT_LEN + self._NONCE_LEN + self._TAG_LEN:]
        key = self._derive_backup_key(passphrase, salt)
        try:
            plaintext = _aead_decrypt(key, nonce, ciphertext, tag)
        except InvalidTag as exc:
            raise VaultBackupError(
                "Could not decrypt backup — wrong passphrase or corrupt file"
            ) from exc
        try:
            restored = json.loads(plaintext.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise VaultBackupError("Backup decrypted but its contents are not valid") from exc
        if not isinstance(restored, dict):
            raise VaultBackupError("Backup does not contain a vault object")

        if merge:
            current = self.read()
            current.update(restored)
            restored = current
        self.write(restored)
        return restored
