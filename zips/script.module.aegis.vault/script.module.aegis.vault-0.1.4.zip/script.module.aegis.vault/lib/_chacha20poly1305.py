"""Pure-Python ChaCha20-Poly1305 AEAD per RFC 8439.

Zero native dependencies — works wherever CPython does. Used by VaultStore
to encrypt the on-disk vault payload on platforms where bundling native
AEAD binaries isn't viable (Kodi 21 Android being the immediate driver).

Correctness is validated by the RFC 8439 test vectors in
tests/test_chacha20poly1305_rfc8439.py. Performance is irrelevant for the
vault's read/write volume (~few hundred bytes a handful of times per
session); a ~5 ms encrypt is invisible next to a Kodi addon load.
"""
from __future__ import annotations

import hmac
import struct

_CHACHA20_CONSTANTS = b"expand 32-byte k"
_POLY1305_PRIME = (1 << 130) - 5
_POLY1305_CLAMP = 0x0FFFFFFC0FFFFFFC0FFFFFFC0FFFFFFF


def _rotl32(value: int, shift: int) -> int:
    value &= 0xFFFFFFFF
    return ((value << shift) | (value >> (32 - shift))) & 0xFFFFFFFF


def _quarter_round(state: list[int], a: int, b: int, c: int, d: int) -> None:
    state[a] = (state[a] + state[b]) & 0xFFFFFFFF
    state[d] = _rotl32(state[d] ^ state[a], 16)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] = _rotl32(state[b] ^ state[c], 12)
    state[a] = (state[a] + state[b]) & 0xFFFFFFFF
    state[d] = _rotl32(state[d] ^ state[a], 8)
    state[c] = (state[c] + state[d]) & 0xFFFFFFFF
    state[b] = _rotl32(state[b] ^ state[c], 7)


def _chacha20_block(key: bytes, counter: int, nonce: bytes) -> bytes:
    state = list(struct.unpack("<4I", _CHACHA20_CONSTANTS))
    state.extend(struct.unpack("<8I", key))
    state.append(counter & 0xFFFFFFFF)
    state.extend(struct.unpack("<3I", nonce))
    working = state[:]
    for _ in range(10):
        # column rounds
        _quarter_round(working, 0, 4, 8, 12)
        _quarter_round(working, 1, 5, 9, 13)
        _quarter_round(working, 2, 6, 10, 14)
        _quarter_round(working, 3, 7, 11, 15)
        # diagonal rounds
        _quarter_round(working, 0, 5, 10, 15)
        _quarter_round(working, 1, 6, 11, 12)
        _quarter_round(working, 2, 7, 8, 13)
        _quarter_round(working, 3, 4, 9, 14)
    out = [(working[i] + state[i]) & 0xFFFFFFFF for i in range(16)]
    return struct.pack("<16I", *out)


def _chacha20_xor(key: bytes, counter: int, nonce: bytes, data: bytes) -> bytes:
    out = bytearray(len(data))
    pos = 0
    block_counter = counter
    while pos < len(data):
        ks = _chacha20_block(key, block_counter, nonce)
        chunk = data[pos : pos + 64]
        for i, byte in enumerate(chunk):
            out[pos + i] = byte ^ ks[i]
        pos += 64
        block_counter += 1
    return bytes(out)


def _poly1305_key_gen(key: bytes, nonce: bytes) -> bytes:
    return _chacha20_block(key, 0, nonce)[:32]


def _poly1305_mac(key: bytes, message: bytes) -> bytes:
    r = int.from_bytes(key[:16], "little") & _POLY1305_CLAMP
    s = int.from_bytes(key[16:32], "little")
    acc = 0
    for offset in range(0, len(message), 16):
        block = message[offset : offset + 16]
        n = int.from_bytes(block + b"\x01", "little")
        acc = ((acc + n) * r) % _POLY1305_PRIME
    tag = (acc + s) & ((1 << 128) - 1)
    return tag.to_bytes(16, "little")


def _pad16(data: bytes) -> bytes:
    rem = len(data) % 16
    if rem == 0:
        return b""
    return b"\x00" * (16 - rem)


def encrypt(key: bytes, nonce: bytes, plaintext: bytes, aad: bytes = b"") -> tuple[bytes, bytes]:
    """Encrypt and authenticate per RFC 8439 §2.8.

    Returns (ciphertext, 16-byte tag). `nonce` must be 12 bytes and unique
    per (key, nonce) pair; reuse breaks confidentiality and authenticity.
    """
    if len(key) != 32:
        raise ValueError("ChaCha20-Poly1305 key must be 32 bytes")
    if len(nonce) != 12:
        raise ValueError("ChaCha20-Poly1305 nonce must be 12 bytes (IETF variant)")

    otk = _poly1305_key_gen(key, nonce)
    ciphertext = _chacha20_xor(key, 1, nonce, plaintext)
    mac_data = (
        aad
        + _pad16(aad)
        + ciphertext
        + _pad16(ciphertext)
        + struct.pack("<Q", len(aad))
        + struct.pack("<Q", len(ciphertext))
    )
    tag = _poly1305_mac(otk, mac_data)
    return ciphertext, tag


def decrypt(
    key: bytes, nonce: bytes, ciphertext: bytes, tag: bytes, aad: bytes = b""
) -> bytes:
    """Authenticate and decrypt per RFC 8439 §2.8.

    Raises InvalidTag if the tag doesn't match — callers must NOT use the
    decrypted output in that case (and indeed there is none returned).
    """
    if len(key) != 32:
        raise ValueError("ChaCha20-Poly1305 key must be 32 bytes")
    if len(nonce) != 12:
        raise ValueError("ChaCha20-Poly1305 nonce must be 12 bytes (IETF variant)")
    if len(tag) != 16:
        raise ValueError("ChaCha20-Poly1305 tag must be 16 bytes")

    otk = _poly1305_key_gen(key, nonce)
    mac_data = (
        aad
        + _pad16(aad)
        + ciphertext
        + _pad16(ciphertext)
        + struct.pack("<Q", len(aad))
        + struct.pack("<Q", len(ciphertext))
    )
    expected = _poly1305_mac(otk, mac_data)
    if not hmac.compare_digest(expected, tag):
        raise InvalidTag("ChaCha20-Poly1305 authentication failed")
    return _chacha20_xor(key, 1, nonce, ciphertext)


class InvalidTag(ValueError):
    """Raised when ChaCha20-Poly1305 authentication fails."""
