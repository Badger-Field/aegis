"""Aegis Health report assembly.

Extracted from default.py (behaviour-preserving). Produces the skin-agnostic
diagnostics report — vault + token state, scraper count, live-TV proxy/refresh,
security posture, addon versions — so users never need an ADB/log dive.

Decoupled from the plugin entry point: the vault directory is injected
(gather_health_lines(vault_dir)) rather than reached back through default.py, and
the vault module is imported here with a None fallback so a headless profile
without the vault addon still renders a report.
"""
from __future__ import annotations

import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

HEALTH_ADDON_IDS = (
    "plugin.video.aegis",
    "script.module.aegis.vault",
    "script.module.aegis.tvhub",
    "script.module.aegis.netguard",
    "script.module.aegis.proxy",
    "service.aegis.firstrun",
    "script.module.testneto",
    "plugin.video.umbrella",
    "plugin.video.aegis.tve",
)


def addon_version(addon_id: str) -> str:
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version") or "?"
    except Exception:
        return "not installed"


def testneto_provider_count() -> Optional[int]:
    """Count enabled provider.* toggles in testneto's user settings, or None if
    testneto isn't installed / readable."""
    try:
        if not xbmc.getCondVisibility("System.HasAddon(script.module.testneto)"):
            return None
        p = Path(xbmcvfs.translatePath(
            "special://profile/addon_data/script.module.testneto/settings.xml"))
        if not p.exists():
            return 0
        root = ET.parse(str(p)).getroot()
        n = 0
        for s in root.iter("setting"):
            sid = s.get("id", "")
            if sid.startswith("provider.") and (s.text or "").strip().lower() == "true":
                n += 1
        return n
    except Exception:
        return None


def gather_health_lines(vault_dir: str) -> List[str]:
    """Assemble the Aegis Health report — everything that otherwise needs an
    ADB/log dive: vault + token state, proxy, live-TV refresh, scraper count,
    addon versions."""
    lines: List[str] = []

    # --- Vault + tokens ---
    lines.append("[B]Vault & providers[/B]")
    vault_data: Dict[str, Any] = {}
    # Imported lazily (not at module load) so this resolves the vault module from
    # sys.modules at call time -- avoids freezing to a stale/faked binding when
    # this module is import-cached across a mixed test run.
    try:
        from aegis_vault import VaultStore
    except Exception:  # pragma: no cover - vault addon absent (headless profile)
        VaultStore = None
    if VaultStore is None:
        lines.append("  Vault module: [COLOR red]unavailable[/COLOR]")
    else:
        try:
            vault_data = VaultStore(vault_dir).read()
            lines.append("  Vault: [COLOR lightgreen]readable[/COLOR]")
        except Exception as exc:
            lines.append("  Vault: [COLOR red]unreadable ({})[/COLOR]".format(exc))

    rd = vault_data.get("rd", {}) if isinstance(vault_data, dict) else {}
    if rd.get("refresh_token") or rd.get("access_token"):
        # A restored/foreign/hand-edited vault could carry a non-numeric
        # expires_at (e.g. an ISO string). Never let that fail the whole
        # report — the health screen's contract is "always renders".
        try:
            exp = int(rd.get("expires_at", 0) or 0)
        except (TypeError, ValueError):
            exp = 0
        if exp:
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(exp))
            remaining = exp - int(time.time())
            status = "expires {}".format(when) if remaining > 0 else "[COLOR red]expired {}[/COLOR]".format(when)
            lines.append("  Real-Debrid: linked (access token {})".format(status))
        else:
            lines.append("  Real-Debrid: linked")
    else:
        lines.append("  Real-Debrid: [COLOR yellow]not linked[/COLOR]")
    lines.append("  AllDebrid: {}".format(
        "linked" if (vault_data.get("ad", {}) or {}).get("apikey") else "not linked"))
    lines.append("  Trakt: {}".format(
        "linked" if (vault_data.get("trakt", {}) or {}).get("access_token") else "not linked"))

    # --- Scraper ---
    count = testneto_provider_count()
    if count is None:
        lines.append("  Scraper (testneto): [COLOR yellow]not installed[/COLOR]")
    else:
        colour = "lightgreen" if count > 0 else "red"
        lines.append("  Scraper (testneto): [COLOR {}]{} providers enabled[/COLOR]".format(colour, count))

    # --- Live TV proxy + refresh ---
    lines.append("")
    lines.append("[B]Live TV[/B]")
    port = xbmcgui.Window(10000).getProperty("aegis_proxy_port")
    if port:
        lines.append("  HLS proxy: [COLOR lightgreen]running on 127.0.0.1:{}[/COLOR]".format(port))
    else:
        lines.append("  HLS proxy: [COLOR yellow]not running[/COLOR] (routing direct to ffmpegdirect)")
    live = vault_data.get("live_tv", {}) if isinstance(vault_data, dict) else {}
    # A restored/hand-edited vault could store a non-numeric last_refresh_at;
    # never let that abort the report (contract: always renders), same as the
    # expires_at guard above.
    try:
        ts = int(live.get("last_refresh_at", 0) or 0)
    except (TypeError, ValueError):
        ts = 0
    if ts > 0:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))
        res = live.get("last_refresh_result", {}) or {}
        lines.append("  Last refresh: {} ({} channels, dedup {}, {} errors)".format(
            when, res.get("total_channels", "?"), res.get("dedup_count", "?"),
            res.get("error_count", "?")))
    else:
        lines.append("  Last refresh: never")

    # --- Security ---
    lines.append("")
    lines.append("[B]Security[/B]")
    lines.append("  Network: HTTPS-only (netguard) ✓")
    lines.append("  Telemetry: none")

    # --- Versions ---
    lines.append("")
    lines.append("[B]Addon versions[/B]")
    for aid in HEALTH_ADDON_IDS:
        lines.append("  {}: {}".format(aid, addon_version(aid)))

    return lines
