"""HLS probe cascade: does a candidate live-TV URL serve REAL segments?

Extracted from default.py (behaviour-preserving). Guards against Pluto's
"barker"/takedown-filler manifests (populated but junk) and known-flaky
providers by deep-probing master -> child -> segment count before the plugin
commits to a stream. Network is stdlib urllib.request (patched globally in
tests), so nothing is injected. Provider classification + per-provider headers
come from the sibling streamrouting module.

default.py keeps thin delegators (_is_hls_candidate / _probe_url_has_real_segments
/ _reorder_cascade_for_known_flaky_providers / _probe_cascade) so _route_tv_play
and the tests that call plugin._probe_cascade etc. are unaffected.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import streamrouting
import xbmc

# Minimum segment count for a child HLS manifest to be considered "real"
# rather than the barker / We'll-be-right-back filler that Pluto's stitcher
# serves to clients it doesn't recognize. Pluto's filler manifests usually
# come back with zero EXTINF lines (Kodi logs "No segments in the manifest"
# and limps along on cached buffer for ~10 seconds before exiting). A real
# live HLS feed reliably has 3+ segments in its rolling window — using 2 as
# the floor keeps headroom for the edge case where a brand-new live event
# just started and only has 2 segments queued.
_PROBE_MIN_CHILD_SEGMENTS = 2

# How much of the master m3u8 we'll read while looking for child URLs.
# 64 KB is far larger than any realistic master playlist (typically <2 KB)
# but defends against an attacker-controlled mirror trying to stream us an
# unbounded body.
_PROBE_MAX_MANIFEST_BYTES = 64 * 1024

# Substrings that, when present in a child HLS manifest, indicate Pluto's
# stitcher served us a filler/takedown loop instead of the real channel
# content. The takedown form has a populated child manifest (so the
# segment-count check passes) but every #EXTINF points at a specific
# rotating "channel removed" / "we'll be right back" clip in Pluto's
# CDN, so the user sees the same 30s filler on repeat instead of the
# channel they asked for.
#
# Observed segment URL pattern:
#   siloh-ns1.plutotv.net/.../clip/<id>_ptv_takedownslates_all_1500/...
#
# Treat any of these substrings in the child manifest body as the same
# class of failure as an empty manifest — the cascade should fall through
# to the next candidate (usually Samsung TV+ or Plex Live).
_PLUTO_FILLER_CLIP_MARKERS = (
    "_ptv_takedownslates_",
    "pluto_help_we_will_be_right_back",
)


def is_hls_candidate(url: str) -> bool:
    """Decide whether a cascade candidate URL needs the HLS deep-probe.

    `.m3u8` suffix is the obvious signal, but several providers serve
    HLS from URLs without that suffix:

    - `jmp2.uk` is the FAST aggregator redirector — serves URLs like
      `https://jmp2.uk/stvp-US12345` (no suffix) that redirect to
      real HLS masters.
    - `epg.provider.plex.tv/library/parts/{id}/?X-Plex-Token=...` is
      Plex Live's URL form: trailing slash, no extension, and the
      X-Plex-Token query param is required auth (so we can't strip
      query strings as a signal). The endpoint serves HLS m3u8
      content but the URL doesn't look like HLS at the suffix level.
      Live capture 2026-06-08 22:20:04 showed Plex playing without
      inputstream.adaptive (native demux), stuttering every ~5-6s
      at segment boundaries — exactly because this gap let Plex
      fall through to the non-HLS branch in `_route_tv_play`.

    The plugin's playback path forces inputstream.adaptive for any
    URL this returns True for — keep the probe path consistent so
    candidates don't sneak past the barker check.

    Query strings are stripped before the suffix check; many CDNs
    sign m3u8 URLs as `master.m3u8?token=...`, and an endswith()
    against the raw URL would miss those. `_route_tv_play` shares
    this helper so the probe-time and playback-time HLS decisions
    can't drift.
    """
    lower = url.split("?")[0].lower()
    if lower.endswith(".m3u8"):
        return True
    if "jmp2.uk" in lower:
        return True
    # Plex Live's `library/parts/{id}/` form is HLS but has no
    # `.m3u8` extension. Match the hostname structurally rather than
    # substring so an attacker URL like
    # `https://attacker.example/.provider.plex.tv/...` can't sneak
    # past — `urlparse` extracts the actual hostname.
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
    except (ValueError, TypeError):
        return False
    if parsed.scheme not in ("http", "https"):
        return False
    host = (parsed.hostname or "").lower()
    return host == "provider.plex.tv" or host.endswith(".provider.plex.tv")


# Allow-listed URL schemes for any URL the plugin opens with
# urllib.request.urlopen. A hostile or compromised playlist could
# include `file://...`, `ftp://...`, `data:`, etc. as a candidate URL
# or as a variant URI inside a master playlist — passing those to
# urlopen would let the user's Kodi host read local files or hit
# unexpected protocol handlers. urlparse() returns scheme="" for
# malformed input (e.g. "javascript:alert(1)") which the allow-list
# also rejects.
_ALLOWED_PROBE_SCHEMES = ("http", "https")


def is_probe_url_safe(url: str) -> bool:
    """True iff `url` parses to an http(s) scheme. Used at both
    cascade-candidate and HLS-child URL entry points before urlopen."""
    import urllib.parse
    return urllib.parse.urlparse(url).scheme in _ALLOWED_PROBE_SCHEMES


# Exception families urllib.request can legitimately raise on the wire.
# Listed explicitly (not as bare `Exception`) so unrelated programming
# errors (TypeError, AttributeError, ...) propagate to the log instead
# of looking like a probe failure. Ruff B014 flags
# `except (URLError, Exception):` because Exception is URLError's
# superclass; this tuple is the narrow alternative.
def build_probe_network_errors():
    import http.client
    # OSError covers urllib.error.URLError (which is itself a subclass of
    # OSError), socket.timeout, and ConnectionError. Listing URLError
    # separately would be redundant and misleading — it suggests URLError
    # gets special handling here when it doesn't.
    return (
        OSError,                # URLError, socket.timeout, ConnectionError, etc.
        http.client.HTTPException,  # malformed HTTP response
        ValueError,             # urlopen rejects a few bad URL shapes synchronously
    )


_PROBE_NETWORK_ERRORS = build_probe_network_errors()


def hls_master_has_real_segments(master_url: str, master_body: str, headers: Dict[str, str], timeout: float = 5.0) -> bool:
    """Continuation of the deep-probe from an already-fetched master body.

    `probe_cascade` reads the master playlist as part of its initial
    200-check, so re-fetching it inside `probe_url_has_real_segments`
    would be a wasted network round-trip per candidate. This helper
    takes the body the caller already has and only fetches the child
    (one extra request) — net 2 requests per HLS candidate instead of
    3, which matters when the cascade has multiple alternates and the
    user hits "Play" on a channel they tune to a lot.

    `master_url` should be the URL the body was fetched from (post-
    redirect when applicable, so urljoin resolves relative child paths
    against the actual CDN location, not the jmp2.uk redirector input).
    """
    import urllib.parse
    import urllib.request

    if "#EXTM3U" not in master_body:
        # Not an HLS document — caller's 200-check already accepted it.
        # We return False here because this function is strictly about
        # HLS depth; the caller's tier-2 path covers the non-HLS case.
        return False

    # Case 2: media playlist — segments inline. Easy count.
    if "#EXT-X-STREAM-INF" not in master_body:
        # Same takedown-filler check as the master→child path: even with
        # enough EXTINF lines, if the segment URLs are Pluto's filler
        # clips it's still a barker.
        lowered_inline = master_body.lower()
        for marker in _PLUTO_FILLER_CLIP_MARKERS:
            if marker in lowered_inline:
                return False
        segs = sum(1 for line in master_body.splitlines() if line.startswith("#EXTINF:"))
        return segs >= _PROBE_MIN_CHILD_SEGMENTS

    # Case 1: master playlist — find first child URL line. Per HLS spec
    # the URL is the first non-tag, non-blank line after a
    # #EXT-X-STREAM-INF tag. Spec doesn't bound how many blank or
    # EXT-X-MEDIA / EXT-X-I-FRAME-STREAM-INF / comment lines may appear
    # between the STREAM-INF and its variant URI — the previous
    # 4-line cap could miss a perfectly valid playlist and report
    # False (treated as barker). Scan forward until we either find the
    # URI or hit the next STREAM-INF (i.e. moved past this variant).
    child_url = None
    lines = master_body.splitlines()
    for i, line in enumerate(lines):
        if not line.startswith("#EXT-X-STREAM-INF"):
            continue
        for j in range(i + 1, len(lines)):
            candidate = lines[j].strip()
            if not candidate:
                continue
            if candidate.startswith("#EXT-X-STREAM-INF"):
                # Next variant entry — current STREAM-INF had no URI
                # (malformed playlist). Bail rather than wrongly
                # adopting a later variant's URI.
                break
            if candidate.startswith("#"):
                continue
            child_url = urllib.parse.urljoin(master_url, candidate)
            break
        if child_url:
            break
    if not child_url:
        return False

    # Scheme allow-list: a hostile / compromised playlist could point
    # its variant URL at `file://...`, `ftp://...`, `data:`, etc. See
    # `is_probe_url_safe` for the full rationale.
    if not is_probe_url_safe(child_url):
        return False

    try:
        req = urllib.request.Request(child_url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.getcode() != 200:
                return False
            child_body = resp.read(_PROBE_MAX_MANIFEST_BYTES).decode("utf-8", errors="ignore")
    except _PROBE_NETWORK_ERRORS:
        return False

    # Takedown-filler detection: even when the child has plenty of
    # segments, if every segment URL points at one of Pluto's well-known
    # filler clip slugs ("takedownslates", "we_will_be_right_back"),
    # treat this as a barker so the cascade falls through to the next
    # candidate. Substring scan over the full body covers both the
    # #EXT-X-KEY URI lines and the segment URIs themselves.
    lowered = child_body.lower()
    for marker in _PLUTO_FILLER_CLIP_MARKERS:
        if marker in lowered:
            return False

    segs = sum(1 for line in child_body.splitlines() if line.startswith("#EXTINF:"))
    return segs >= _PROBE_MIN_CHILD_SEGMENTS


def probe_url_has_real_segments(master_url: str, headers: Dict[str, str], timeout: float = 5.0) -> bool:
    """Deep-probe: master → child → count segments. Returns True only when
    the manifest hierarchy ends in a child with at least _PROBE_MIN_CHILD_SEGMENTS
    EXTINF lines. Returns False on any HTTP error, malformed manifest, or
    a child manifest with zero/insufficient segments — the latter is the
    Pluto barker pattern we're guarding against.

    Convenience wrapper around `hls_master_has_real_segments` that
    fetches the master itself; `probe_cascade` prefers the inner
    helper because it has the master body in hand from its own
    200-check. Kept here for the existing test interface and any
    direct callers.

    Same `headers` are sent on BOTH fetches because we've seen Pluto's
    stitcher gate based on Referer/Origin not just on the master but on
    every child fetch too.
    """
    import urllib.request

    try:
        req = urllib.request.Request(master_url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.getcode() != 200:
                return False
            body = resp.read(_PROBE_MAX_MANIFEST_BYTES).decode("utf-8", errors="ignore")
            # Use the post-redirect URL for child URL resolution — when
            # the input was a jmp2.uk redirector, child paths are
            # relative to the CDN's master URL, not the redirector.
            final_url = resp.geturl() if hasattr(resp, "geturl") else master_url
    except _PROBE_NETWORK_ERRORS:
        return False

    return hls_master_has_real_segments(final_url, body, headers, timeout=timeout)


def reorder_cascade_for_known_flaky_providers(urls: List[str]) -> List[str]:
    """Move Plex Live URLs to the end of the cascade.

    Plex Live's HLS doesn't keep continuous PTS across
    EXT-X-DISCONTINUITY boundaries — at every SCTE-35 ad break the
    new period starts at an absolute timestamp far from where the
    old period ended. ffmpegdirect forwards the packets and Kodi's
    player computes wall-clock-vs-PTS delta as nonsense, then the
    audio thread spirals into "large audio sync error" / stall
    (live capture 2026-06-09 00:23:08 saw -4906s drift accumulate
    in 4 seconds at the first discontinuity).

    Until we have a localhost m3u8 proxy that strips
    EXT-X-DISCONTINUITY (deferred follow-up), Plex Live is
    "playable only when nothing else is available." When the
    cascade has any non-Plex alternate, prefer those — Tubi direct
    HLS and Samsung-via-ffmpegdirect both have far more predictable
    PTS behaviour through ad breaks.

    Cascades with ONLY Plex candidates are NOT reordered — we still
    need Plex as the last-resort for channels with no alternates,
    and the existing barker-fallback tier in `probe_cascade` will
    still pick the best Plex URL among them.

    Order within the non-Plex set is preserved (the upstream tvhub
    dedup logic already ranks them by quality). Same for the Plex
    set among itself.
    """
    plex_urls: List[str] = []
    non_plex_urls: List[str] = []
    for url in urls:
        # Strip any pipe-tail before classifying — same defence as
        # `_route_tv_play.base_url` and `probe_cascade`.
        base = url.partition("|")[0]
        if streamrouting.classify_stream(base) == "plex":
            plex_urls.append(url)
        else:
            non_plex_urls.append(url)
    if not non_plex_urls:
        # Plex-only cascade: keep original order, fall through to the
        # existing two-tier probe ranking unchanged.
        return urls
    return non_plex_urls + plex_urls


def probe_cascade(urls: List[str]) -> Tuple[Optional[str], int, bool]:
    """Probe URLs in order; return the URL most likely to actually play.

    Returns `(url, idx, was_barker_fallback)`. `was_barker_fallback=True`
    means we resolved to a Tier-2 URL (every candidate failed deep-probe)
    — the caller can surface that as a "channel is currently serving
    filler" notification instead of silently playing the barker.

    Two-tier ranking applied in a single pass:
      Tier 1: URL returns 200 AND (if HLS) deep-probe finds real segments
              in the child manifest. This is the Pluto-barker guard — the
              barker case is a master that parses fine but whose child
              manifest has no EXTINF lines, so inputstream.adaptive logs
              "No segments in the manifest" and Kodi limps along on
              cached buffer for ~10s before stalling.
      Tier 2: URL returns 200 but deep-probe couldn't confirm segments.
              Used as fallback ONLY if every candidate fails Tier 1 —
              keeps us no-worse-than-before for the all-barker case.

    Non-HLS URLs (direct .ts, MPEG-DASH, etc.) skip the deep-probe and
    take Tier 1 on any 200 — we have no equivalent segment check there
    and inputstream.adaptive handles them via different code paths.
    HLS is detected by `.m3u8` suffix OR `jmp2.uk` substring (the FAST
    aggregators serve HLS through the jmp2.uk redirector even when the
    URL doesn't end in .m3u8).

    Per HLS candidate, the initial probe reads the full master playlist
    (instead of just 512 bytes) and reuses it for the deep-probe — net 2
    network requests per HLS candidate (master + child) instead of 3
    (master 200-check + master refetch + child).

    Before the probe loop, the URL list is run through
    `reorder_cascade_for_known_flaky_providers` to push Plex Live URLs
    to the end. Plex Live's HLS has a PTS-jump problem at SCTE-35
    discontinuities that no inputstream addon recovers from cleanly;
    cascades with non-Plex alternates should land on those first.

    On total failure returns (None, -1, False).
    """
    import urllib.error
    import urllib.request

    urls = reorder_cascade_for_known_flaky_providers(urls)

    tier2_url: Optional[str] = None
    tier2_idx: int = -1

    for idx, url in enumerate(urls):
        # Scheme allow-list: defend the cascade entry point too. The
        # deep-probe already filters child URLs inside HLS masters, but
        # an attacker can also feed `file://` / `ftp://` straight into
        # a cascade URL via a compromised m3u (or via a malicious
        # alternates upgrade). Same allow-list either way.
        if not is_probe_url_safe(url):
            xbmc.log(
                "Aegis tv_play: candidate[{}/{}] probe FAIL "
                "(scheme not allowed): {}".format(
                    idx + 1, len(urls), url.split("?")[0]
                ),
                xbmc.LOGWARNING,
            )
            continue

        # Send the SAME header set the playback path will use for this URL —
        # Samsung-Tizen UA for stvp-, default Chrome UA for everything else.
        # Without this, probes succeed with Chrome UA but Samsung's cloudfront
        # edge 403s the .ts segments at playback time.
        probe_headers = streamrouting.headers_for_url(url)
        is_hls = is_hls_candidate(url)
        reason = ""
        ok_200 = False
        master_body = ""
        master_final_url = url
        try:
            req = urllib.request.Request(url, headers=probe_headers)
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.getcode() == 200:
                    if is_hls:
                        # Read the full master so the deep-probe can reuse
                        # it without a second round-trip. Bounded by
                        # _PROBE_MAX_MANIFEST_BYTES so a hostile mirror
                        # can't stream us an unbounded body.
                        master_body = resp.read(_PROBE_MAX_MANIFEST_BYTES).decode("utf-8", errors="ignore")
                        if hasattr(resp, "geturl"):
                            master_final_url = resp.geturl()
                    else:
                        # Non-HLS: just confirm the body is actually
                        # deliverable (some CDNs return 200 headers then
                        # 403/empty body on data read).
                        resp.read(512)
                    ok_200 = True
                else:
                    reason = "code=" + str(resp.getcode())
        except urllib.error.HTTPError as exc:
            reason = "http=" + str(exc.code)
        except _PROBE_NETWORK_ERRORS as exc:
            # Use the same narrow exception tuple as the helpers so a
            # programming error (TypeError, AttributeError, ...) in the
            # probe path surfaces in the log instead of being silently
            # categorized as a probe failure and demoting the candidate.
            reason = type(exc).__name__ + ":" + str(exc)[:60]

        if not ok_200:
            xbmc.log(
                "Aegis tv_play: candidate[{}/{}] probe FAIL ({}): {}".format(
                    idx + 1, len(urls), reason, url.split("?")[0]
                ),
                xbmc.LOGINFO,
            )
            continue

        # Decide tier. HLS gets the deep-probe (reusing the master body
        # already read above); non-HLS passes Tier 1 on any 200.
        if not is_hls or hls_master_has_real_segments(
            master_final_url, master_body, probe_headers
        ):
            xbmc.log(
                "Aegis tv_play: candidate[{}/{}] probe OK: {}".format(
                    idx + 1, len(urls), url.split("?")[0]
                ),
                xbmc.LOGINFO,
            )
            return url, idx, False

        # 200 OK on the master but deep-probe didn't confirm playable
        # segments. The dominant cause is Pluto's barker (master parses,
        # child manifest comes back empty), but the same `False` return
        # also covers child-fetch timeouts, HTTP errors, malformed
        # manifests, and non-HLS bodies — so the log line stays neutral
        # to keep triage honest. Remember as Tier-2 fallback in case
        # nothing else passes Tier 1.
        xbmc.log(
            "Aegis tv_play: candidate[{}/{}] 200 but deep-probe failed "
            "(barker, transient child-fetch error, malformed manifest, or "
            "non-HLS body); trying next: {}".format(
                idx + 1, len(urls), url.split("?")[0]
            ),
            xbmc.LOGINFO,
        )
        if tier2_url is None:
            tier2_url = url
            tier2_idx = idx

    if tier2_url is not None:
        xbmc.log(
            "Aegis tv_play: no candidate passed deep-probe; falling back to "
            "first 200 (barker-tolerant): {}".format(tier2_url.split("?")[0]),
            xbmc.LOGWARNING,
        )
        return tier2_url, tier2_idx, True
    return None, -1, False
