"""Live-TV stream classification + header/proxy routing.

Extracted from default.py (behaviour-preserving). Self-contained: talks only to
stdlib + xbmcgui (one Window-property read for the proxy port), no plugin
entry-point helpers. default.py keeps thin delegators so existing call sites
(_route_tv_play, the probe cascade) and tests (which call plugin._classify_stream
etc.) are unaffected.

Several helpers here are deliberate MIRRORS of
script.module.aegis.tvhub.lib.stream_headers and must stay in lock-step with it
(verified by tests/test_stream_headers.py mirror-sync checks).
"""
from __future__ import annotations

from typing import Dict, Optional
from urllib.parse import urlparse

import xbmcgui

PROVIDER_UA = {
    "samsung": (
        "Mozilla/5.0 (SMART-TV; LINUX; Tizen 5.0) AppleWebKit/537.36 "
        "(KHTML, like Gecko) 73.0.3683.103 SamsungBrowser/9.1 LFD Safari/537.36"
    ),
    # Default desktop Chrome — used by Pluto, Tubi, Plex, Roku, and unknown
    # providers (only Samsung overrides the UA; the rest differ only in headers).
    "default": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
}

PROVIDER_EXTRA_HEADERS: Dict[str, Dict[str, str]] = {
    # Mirror of script.module.aegis.tvhub.lib.stream_headers — see that
    # module for why each provider needs specific Origin/Referer.
    "pluto": {
        "Origin": "https://pluto.tv",
        "Referer": "https://pluto.tv/",
    },
    "samsung": {
        "Origin": "https://www.samsungtvplus.com",
        "Referer": "https://www.samsungtvplus.com/",
    },
    "plex": {
        "Origin": "https://app.plex.tv",
        "Referer": "https://app.plex.tv/",
    },
    "tubi": {
        "Origin": "https://tubitv.com",
        "Referer": "https://tubitv.com/",
    },
    # Roku Channel FAST — mirrors the canonical tvhub copy; see
    # stream_headers.py for the live-capture reasoning.
    "roku": {
        "Origin": "https://therokuchannel.roku.com",
        "Referer": "https://therokuchannel.roku.com/",
    },
}

# Mirror of script.module.aegis.tvhub.lib.stream_headers._FFMPEG_RECONNECT_OPTS
# — ffmpeg AVDictionary options (not HTTP headers) that ride along the
# pipe-tail for ffmpegdirect-routed URLs. See the tvhub copy for the
# full reasoning. Must stay in lock-step (verified by
# tests/test_stream_headers.py mirror-sync checks).
FFMPEG_RECONNECT_OPTS: Dict[str, str] = {
    "reconnect": "1",
    "reconnect_streamed": "1",
    "reconnect_delay_max": "1",
}

# Window property the proxy service publishes when it's running.
# Empty string means proxy isn't available — routing falls back to
# passing the upstream URL straight to ffmpegdirect.
AEGIS_PROXY_PORT_WINDOW_PROP = "aegis_proxy_port"


def is_pluto_stitcher_url(url: str) -> bool:
    """Mirror of script.module.aegis.tvhub.lib.stream_headers._is_pluto_stitcher_url.

    Uses `urlparse` so the hostname is extracted structurally and
    can't be spoofed by an attacker putting `pluto.tv/v1/stitch/`
    somewhere in the URL path. Must stay in lock-step with the
    tvhub copy (verified by tests/test_stream_headers.py mirror-sync
    checks).
    """
    # Strict type gate: `urlparse` raises `TypeError`/`AttributeError`
    # on non-str inputs (None, bytes, int, etc.) — defensive allow-list
    # gates must reject anything non-str upfront so a bad input can't
    # crash the cascade resolver. Mirrors the tvhub copy.
    if not isinstance(url, str) or not url:
        return False
    try:
        parsed = urlparse(url)
    except (ValueError, TypeError):
        return False
    if parsed.scheme not in ("http", "https"):
        return False
    host = (parsed.hostname or "").lower()
    if not (host == "pluto.tv" or host.endswith(".pluto.tv")):
        return False
    return parsed.path.lower().startswith("/v1/stitch/")


def classify_stream(url: str) -> str:
    """Classify a stream URL into a provider key for header selection.

    Used to choose Samsung-Tizen UA vs. desktop Chrome UA and to pick the
    right Origin / Referer header set. Returns one of:
    "pluto", "samsung", "plex", "tubi", "roku", "unknown".

    Both jmp2.uk/plex- (the redirector form used by FAST aggregation and our
    tvhub dedup output) and the direct provider.plex.tv host get classified
    as "plex". Must stay in lock-step with
    script.module.aegis.tvhub.lib.stream_headers.classify_stream (verified
    by tests/test_stream_headers.py mirror-sync checks).
    """
    # Defensive: caller may pass non-str (None from missing settings,
    # bytes from a decode-forgot, etc.). Treat anything non-str as
    # unclassifiable so `.lower()` / `in` don't raise.
    if not isinstance(url, str) or not url:
        return "unknown"
    lowered = url.lower()
    # Match the jmp2.uk `plu-` redirector form AND the direct stitcher
    # URL (`stitcher-ipv4.pluto.tv/v1/stitch/...`) the tvhub adapter
    # rewrites to once jmp2.uk's plu- route started returning 404.
    # Pluto stitcher uses real `urlparse` host+path checks (see
    # `is_pluto_stitcher_url`) so attacker-controlled URLs that embed
    # `pluto.tv/v1/stitch/` in the path (e.g.
    # `https://attacker.example/.pluto.tv/v1/stitch/...`) can't sneak
    # past — substring checks alone could be evaded.
    if "jmp2.uk/plu-" in lowered or is_pluto_stitcher_url(url):
        return "pluto"
    if "jmp2.uk/stvp-" in lowered:
        return "samsung"
    if "jmp2.uk/plex-" in lowered or "provider.plex.tv" in lowered:
        return "plex"
    # tubi.io / tubitv.com are the VOD + app domains; Tubi's LIVE channels are
    # served from the CSM stitcher on *.tubi.video (master on
    # csm-*.csm.tubi.video, segments on *.tubi.video). Without matching
    # tubi.video, live Tubi classified as "unknown" and fell through to
    # inputstream.adaptive, which crashed on Tubi's yospace SCTE-35
    # #EXT-X-DISCONTINUITY ad-splices (CVideoPlayerVideo::OutputPicture timeout
    # after a resync-backward storm — kodi.exe crash 2026-08-01 19:59).
    if "tubi.io" in lowered or "tubitv.com" in lowered or "tubi.video" in lowered:
        return "tubi"
    # Roku Channel FAST via the jmp2.uk `rok-` redirector form. Mirror
    # of tvhub.lib.stream_headers.classify_stream.
    if "jmp2.uk/rok-" in lowered:
        return "roku"
    return "unknown"


def headers_for_url(url: str) -> Dict[str, str]:
    """Return the {header_name: header_value} dict to send for `url`.

    Pure Python dict (NOT URL-encoded). kodi_header_string() handles the
    inputstream.adaptive on-the-wire format separately.
    """
    provider = classify_stream(url)
    ua = PROVIDER_UA.get(provider, PROVIDER_UA["default"])
    headers: Dict[str, str] = {"User-Agent": ua}
    headers.update(PROVIDER_EXTRA_HEADERS.get(provider, {}))
    return headers


def ffmpegdirect_pipe_options(url: str) -> Dict[str, str]:
    """Mirror of script.module.aegis.tvhub.lib.stream_headers.ffmpegdirect_pipe_options.

    Returns ffmpeg AVDictionary options to merge into the pipe-tail when
    `url` is routed through inputstream.ffmpegdirect. Provider-agnostic
    today (Samsung is the only ffmpegdirect-routed provider) but per-URL
    so future providers can override.
    """
    return dict(FFMPEG_RECONNECT_OPTS)


def aegis_proxy_url(upstream_url: str, headers: Dict[str, str]) -> Optional[str]:
    """Return a `http://127.0.0.1:PORT/p?u=...&h=...` URL that routes
    `upstream_url` through the local Aegis HLS proxy with `headers`
    applied on the upstream fetch. Returns None when the proxy isn't
    running (Window property unset / unreadable) so the caller can
    fall back to the direct URL.

    The proxy strips `EXT-X-DISCONTINUITY` and SCTE-35 hint tags from
    HLS manifests before ffmpegdirect sees them, eliminating the
    per-discontinuity decoder re-init stutter on Samsung TV+ / Roku /
    Plex Live.

    Headers are JSON-then-base64-encoded into the `h` query param —
    same scheme `lib/server.py::encode_proxy_target` uses on the
    proxy side. Kept inline here (rather than importing the proxy
    addon's helper) because the plugin doesn't have the proxy module
    on its sys.path and a runtime cross-addon import would add a
    failure mode for a small helper.
    """
    try:
        port_str = xbmcgui.Window(10000).getProperty(AEGIS_PROXY_PORT_WINDOW_PROP)
    except Exception:
        return None
    if not port_str or not port_str.isdigit():
        return None
    import base64
    import json
    def _b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")
    parts = ["u=" + _b64url(upstream_url.encode("utf-8"))]
    if headers:
        parts.append("h=" + _b64url(json.dumps(headers, separators=(",", ":")).encode("utf-8")))
    return "http://127.0.0.1:{}/p?{}".format(port_str, "&".join(parts))


def kodi_header_string(headers: Dict[str, str]) -> str:
    """Format header dict for inputstream.adaptive.{manifest,stream}_headers.

    inputstream.adaptive expects `Key=Value&Key2=Value2` with URL-encoded
    values. Keys are not encoded (header names never contain reserved chars).
    """
    from urllib.parse import quote
    return "&".join("{}={}".format(k, quote(v, safe="")) for k, v in headers.items())


def kodi_pipe_header_url(url: str, headers: Dict[str, str]) -> str:
    """Mirror of script.module.aegis.tvhub.lib.stream_headers.kodi_pipe_header_url.

    Append HTTP headers to a URL using Kodi's pipe-separator syntax —
    ffmpegdirect picks them up via Kodi's CurlFile on both manifest
    and segment fetches. If the URL already carries a pipe tail
    (decorated by an upstream layer), merge new headers into the
    existing tail rather than appending a second `|` — CurlFile only
    parses the first segment, so a `url|...|...` shape silently drops
    the second header set.

    New keys win on conflict: the explicit `headers` argument is the
    caller's "current intent" and overrides whatever was baked in.
    Values in the existing tail are URL-decoded before re-encoding so
    a repeated apply doesn't double-encode.

    Returns `url` unchanged when `headers` is empty so callers can
    stay single-path. Must stay in lock-step with the tvhub copy
    (mirror sync coverage: tests/test_stream_headers.py).
    """
    if not headers:
        return url
    from urllib.parse import unquote
    base, sep, existing_tail = url.partition("|")
    if not sep:
        return "{}|{}".format(base, kodi_header_string(headers))
    merged: Dict[str, str] = {}
    for chunk in existing_tail.split("&"):
        if not chunk or "=" not in chunk:
            continue
        k, _, v = chunk.partition("=")
        merged[k] = unquote(v)
    merged.update(headers)
    return "{}|{}".format(base, kodi_header_string(merged))
