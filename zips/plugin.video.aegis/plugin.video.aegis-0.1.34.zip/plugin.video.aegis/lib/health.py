"""Aegis Health report assembly.

Extracted from default.py (behaviour-preserving). Produces the skin-agnostic
diagnostics report — vault + token state, scraper count, live-TV proxy/refresh,
security posture, addon versions — so users never need an ADB/log dive.

Decoupled from the plugin entry point: the vault directory is injected
(gather_health_lines(vault_dir)) rather than reached back through default.py, and
the vault module is imported here with a None fallback so a headless profile
without the vault addon still renders a report.
"""
from __future__ import annotations

import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

HEALTH_ADDON_IDS = (
    "plugin.video.aegis",
    "script.module.aegis.vault",
    "script.module.aegis.tvhub",
    "script.module.aegis.netguard",
    "script.module.aegis.proxy",
    "service.aegis.firstrun",
    "script.module.testneto",
    "plugin.video.umbrella",
    "plugin.video.aegis.tve",
)


def addon_version(addon_id: str) -> str:
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version") or "?"
    except Exception:
        return "not installed"


def testneto_enabled_providers() -> Optional[List[str]]:
    """Names of the enabled provider.* toggles in testneto's user settings, or
    None if testneto isn't installed / readable."""
    try:
        if not xbmc.getCondVisibility("System.HasAddon(script.module.testneto)"):
            return None
        p = Path(xbmcvfs.translatePath(
            "special://profile/addon_data/script.module.testneto/settings.xml"))
        if not p.exists():
            return []
        root = ET.parse(str(p)).getroot()
        names = []
        for s in root.iter("setting"):
            sid = s.get("id", "")
            if sid.startswith("provider.") and (s.text or "").strip().lower() == "true":
                names.append(sid[len("provider."):])
        return names
    except Exception:
        return None


TESTNETO_PROVIDERS_DIR = "special://home/addons/script.module.testneto/lib/testneto/providers"


def testneto_scraper_modules() -> Optional[set]:
    """Names of the scraper modules testneto actually ships (providers/*/x.py),
    or None when the directory can't be read (then nothing is filtered).

    Not every provider.* toggle is a scraper Umbrella queries. provider.aiostreams
    defaults to on but belongs to testneto's own player and needs a separate
    login; counted as a scraper it showed up as "enabled, returned nothing" on
    every install, which is a false alarm that teaches people to ignore the line.
    """
    try:
        root = Path(xbmcvfs.translatePath(TESTNETO_PROVIDERS_DIR))
        if not root.is_dir():
            return None
        names = {p.stem for p in root.glob("*/*.py") if p.stem != "__init__"}
        return names or None
    except Exception:
        return None


def trakt_line(vault_data: Any) -> str:
    """Trakt link state. Trakt is linked in Umbrella, not in Aegis: nothing in
    Aegis writes a Trakt token to the vault, so reading only the vault made this
    line say "not linked" for everyone, including users whose Trakt works."""
    vault_token = False
    if isinstance(vault_data, dict):
        vault_token = bool((vault_data.get("trakt", {}) or {}).get("access_token"))
    if vault_token:
        return "linked"
    try:
        umbrella = xbmcaddon.Addon("plugin.video.umbrella")
        if (umbrella.getSetting("trakt.user.token") or "").strip():
            return "linked (in Umbrella)"
    except Exception:
        return "[COLOR yellow]not checked (Umbrella settings unreadable)[/COLOR]"
    return "not linked (link it in Umbrella settings)"


def testneto_provider_count() -> Optional[int]:
    """Count of enabled providers (see testneto_enabled_providers)."""
    names = testneto_enabled_providers()
    return None if names is None else len(names)


# How many recent titles to judge a scraper on. One title is not enough: a
# provider legitimately has nothing for an obscure film. Ten in a row is a
# provider that is switched on and contributing nothing.
SCRAPER_WINDOW = 10
UMBRELLA_PROVIDER_CACHE = "special://profile/addon_data/plugin.video.umbrella/providers.db"


def scraper_activity(db_path: str, window: int = SCRAPER_WINDOW) -> Dict[str, Any]:
    """What the scrapers actually returned for the last ``window`` titles
    searched, read from Umbrella's provider cache (it stores one row per
    provider per title, and only when the provider returned something).

    Returns {"searches": n, "latest": "YYYY-MM-DD HH:MM", "hits": {provider: n}}
    or {"error": reason}. A missing cache file is reported as zero searches,
    which the caller renders as "not checked" -- never as a pass.

    Read-only by construction (mode=ro URI): this runs while Umbrella may be
    writing, and a health screen must never be able to corrupt or lock the
    cache it is inspecting.
    """
    import sqlite3

    path = Path(db_path)
    if not path.is_file():
        return {"searches": 0, "latest": "", "hits": {}}
    try:
        con = sqlite3.connect("file:{}?mode=ro".format(path.as_posix()), uri=True, timeout=2)
    except Exception as exc:
        return {"error": type(exc).__name__}
    try:
        # A "search" is a title (imdb_id): episode, season-pack and show-pack
        # rows of one lookup collapse together, so a provider with no packs is
        # not counted as missing. Empty result lists are excluded -- a stored
        # "[]" is the provider answering with nothing.
        rows = con.execute(
            "SELECT source, imdb_id, MAX(added) FROM rel_src "
            "WHERE imdb_id != '' AND hosts NOT IN ('', '[]') "
            "GROUP BY source, imdb_id").fetchall()
    except Exception as exc:
        return {"error": type(exc).__name__}
    finally:
        con.close()

    by_title: Dict[str, Dict[str, str]] = {}
    for source, imdb_id, added in rows:
        by_title.setdefault(str(imdb_id), {})[str(source)] = str(added or "")
    recent = sorted(by_title.values(), key=lambda provs: max(provs.values()), reverse=True)[:window]
    hits: Dict[str, int] = {}
    for provs in recent:
        for source in provs:
            hits[source] = hits.get(source, 0) + 1
    latest = max(recent[0].values())[:16] if recent else ""
    return {"searches": len(recent), "latest": latest, "hits": hits}


def scraper_lines(enabled: List[str], activity: Dict[str, Any]) -> List[str]:
    """Render scraper_activity against the enabled toggles.

    "N providers enabled" counts switches, and a switch says nothing about
    whether the provider still answers (2026-11-11: aiostreams was enabled and
    absent from the last 30 searches while the screen showed a green count).
    """
    if "error" in activity:
        return ["    Results: [COLOR yellow]not checked (search history unreadable: {})[/COLOR]".format(
            activity["error"])]
    searches = int(activity.get("searches", 0) or 0)
    if not searches:
        return ["    Results: [COLOR yellow]not checked (no searches recorded yet)[/COLOR]"]
    hits = activity.get("hits", {}) or {}
    working = [name for name in enabled if hits.get(name)]
    silent = sorted(name for name in enabled if not hits.get(name))
    colour = "lightgreen" if working and not silent else ("yellow" if working else "red")
    lines = ["    Results: [COLOR {}]{} of {} returned sources[/COLOR] in the last {} title{} searched (latest {})".format(
        colour, len(working), len(enabled), searches, "" if searches == 1 else "s",
        activity.get("latest") or "?")]
    if silent:
        lines.append("    [COLOR {}]Nothing from: {}[/COLOR]".format(
            "yellow" if working else "red", ", ".join(silent)))
    return lines


def release_lines(record: Any, now: Optional[int] = None) -> List[str]:
    """Is this install behind the published release? (Record written by
    service.aegis.firstrun's release_check.)

    The version list below only says what is installed. On 2026-11-11 a Fire TV
    stick showed a tidy list of versions that were three months old, and
    nothing said so. Kodi installs published updates by itself within about a
    day, so "behind" is worded by how long it has lasted: a day is normal, a
    week means the updater is not working.
    """
    now = int(time.time()) if now is None else now
    if not isinstance(record, dict):
        return ["  Published release: [COLOR yellow]not checked yet[/COLOR]"]

    def _int(value: Any) -> int:
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    checked_at = _int(record.get("checked_at"))
    if not checked_at:
        return ["  Published release: [COLOR yellow]not checked ({})[/COLOR]".format(
            record.get("last_error") or "unknown")]
    age_h = max(0, now - checked_at) // 3600
    age = "checked {}h ago".format(age_h) if age_h else "checked just now"
    if _int(record.get("last_attempt_at")) > checked_at:
        age += ", latest check failed: {}".format(record.get("last_error") or "unknown")

    behind = [b for b in (record.get("behind") or []) if isinstance(b, (list, tuple)) and len(b) >= 3]
    if not behind:
        return ["  Published release: [COLOR lightgreen]up to date[/COLOR] ({} addons compared, {})".format(
            _int(record.get("compared")), age)]
    since = record.get("behind_since") if isinstance(record.get("behind_since"), dict) else {}
    oldest = min([_int(since.get(b[0])) or checked_at for b in behind])
    days = max(0, now - oldest) // 86400
    if days >= 2:
        head = "  Published release: [COLOR red]{} addon{} behind for {} days - updates are not installing[/COLOR] ({})".format(
            len(behind), "" if len(behind) == 1 else "s", days, age)
    else:
        head = "  Published release: [COLOR yellow]{} addon{} behind[/COLOR] - Kodi normally installs these within a day ({})".format(
            len(behind), "" if len(behind) == 1 else "s", age)
    return [head] + ["    {}: {} installed, {} published".format(b[0], b[1], b[2]) for b in behind]


KODI_DATABASE_DIR = "special://database"
AEGIS_REPOSITORY_ID = "repository.aegis"


def install_origins(database_dir: str) -> Dict[str, Any]:
    """Where Kodi recorded each installed addon as coming from, read from its
    addon database: {"origins": {addon_id: origin}} or {"error": reason}.

    Kodi exposes this to skins (ListItem.AddonOrigin) but not to Python, hence
    the database. Read-only by construction (mode=ro URI), like
    scraper_activity: this is Kodi's own live database.
    """
    import sqlite3

    try:
        # Addons33.db on Kodi 21; the number changes with the schema, and an
        # upgraded profile keeps the old files, so take the newest.
        candidates = sorted(Path(database_dir).glob("Addons*.db"),
                            key=lambda p: int("".join(c for c in p.stem if c.isdigit()) or 0))
    except Exception as exc:
        return {"error": type(exc).__name__}
    if not candidates:
        return {"error": "addon database not found"}
    try:
        con = sqlite3.connect("file:{}?mode=ro".format(candidates[-1].as_posix()), uri=True, timeout=2)
    except Exception as exc:
        return {"error": type(exc).__name__}
    try:
        rows = con.execute("SELECT addonID, origin FROM installed").fetchall()
    except Exception as exc:
        return {"error": type(exc).__name__}
    finally:
        con.close()
    return {"origins": {str(addon_id): str(origin or "") for addon_id, origin in rows}}


def origin_lines(addon_ids: Any, result: Dict[str, Any]) -> tuple:
    """(summary lines, {addon_id: note to append to its version line}).

    2026-11-12: a Fire TV stick took every Aegis update by itself except
    Umbrella, which stayed two releases behind. Umbrella had once been
    sideloaded from a zip, Kodi records that as a manual install, and with its
    default "official repositories only" update mode Kodi never updates a
    manually installed addon from a repository. Nothing on the device said so;
    the version list looked the same for both kinds.
    """
    if "error" in result:
        return (["  Install source: [COLOR yellow]not checked ({})[/COLOR]".format(result["error"])], {})
    origins = result.get("origins") or {}
    notes: Dict[str, str] = {}
    checked = 0
    for addon_id in addon_ids:
        if addon_id not in origins:
            continue  # not installed: nothing to update
        checked += 1
        origin = origins[addon_id]
        if origin == AEGIS_REPOSITORY_ID:
            continue
        # Empty = files copied in; own id = installed from a zip. Kodi treats
        # both as manual.
        if origin in ("", addon_id):
            notes[addon_id] = "[COLOR yellow]installed manually - Kodi will not update it[/COLOR]"
        else:
            notes[addon_id] = "[COLOR yellow]installed from {} - Aegis updates will not reach it[/COLOR]".format(origin)
    if not checked:
        return (["  Install source: [COLOR yellow]not checked (no Aegis addons in Kodi's database)[/COLOR]"], {})
    if not notes:
        return (["  Install source: [COLOR lightgreen]all {} from the Aegis repository[/COLOR] "
                 "(updates install automatically)".format(checked)], {})
    return (["  Install source: [COLOR yellow]{} of {} will not update automatically[/COLOR] - "
             "reinstall {} from Add-ons > Install from repository > Aegis Repository".format(
                 len(notes), checked, "it" if len(notes) == 1 else "them")], notes)


def vault_key_line(vault_cls: Any, vault_dir: str) -> str:
    """How well the vault key itself is protected on this device.

    "Vault: readable" says the tokens decrypt; it does not say whether the key
    sits in the OS key store or in a plain file next to the ciphertext. On
    platforms without a key store (Fire OS, Linux) it is the latter, and the
    only notice was a RuntimeWarning nobody sees inside Kodi.
    """
    try:
        state = vault_cls(vault_dir).key_protection()
    except Exception:
        # Older vault addon without key_protection(), or the call failed:
        # not looked at, so not reported as protected.
        return "[COLOR yellow]not checked[/COLOR]"
    if state in ("dpapi", "keychain"):
        return "[COLOR lightgreen]protected by the OS key store ({})[/COLOR]".format(state)
    if state == "unwrapped":
        return ("[COLOR yellow]stored unwrapped beside the vault - this device has no OS key "
                "store, so anyone who can copy both files can read the tokens[/COLOR]")
    if state == "none":
        return "not created yet"
    return "[COLOR yellow]not checked (unrecognised key file: {})[/COLOR]".format(state)


def security_lines() -> List[str]:
    """The Security section. Every line is either a result measured just now or
    a plainly worded statement of what is NOT covered.

    This used to be two fixed strings ("HTTPS-only (netguard) ✓",
    "Telemetry: none") printed without checking anything, and the first was
    not true of the whole build: live-TV probing allows http, and the vendored
    Umbrella addon disables certificate checks on some calls.
    """
    lines: List[str] = []
    try:
        from aegis_netguard import self_test
    except Exception:
        # Covers both "netguard not installed" and "netguard too old to test
        # itself": either way nothing was verified, so nothing gets a tick.
        lines.append("  Aegis account calls (debrid, Trakt): [COLOR red]NOT VERIFIED - netguard unavailable[/COLOR]")
    else:
        try:
            ok, detail = self_test()
        except Exception as exc:
            ok, detail = False, "self-test raised {}".format(type(exc).__name__)
        if ok:
            lines.append("  Aegis account calls (debrid, Trakt): [COLOR lightgreen]HTTPS only, certificates "
                         "verified[/COLOR] (guard tested just now)")
        else:
            lines.append("  Aegis account calls (debrid, Trakt): [COLOR red]GUARD FAILED - {}[/COLOR]".format(detail))
    lines.append("  Live TV streams: not covered - channel URLs come from playlists and may be plain HTTP")
    lines.append("  Umbrella + scrapers: not covered - third-party code, some calls skip certificate checks")
    lines.append("  Telemetry: none sent by Aegis code (third-party addons are reviewed at build time, not here)")
    return lines


def account_line(record: Any, now: Optional[int] = None) -> str:
    """Render the provider's own verdict on the account (written to the vault by
    service.aegis.firstrun's debrid_account probe).

    "linked" above only means a token is stored. On 2026-11-11 a lapsed (free)
    Real-Debrid account showed "linked" here while nothing would play, so the
    account state gets its own line and "not checked" is spelled out rather
    than left looking like a pass. Tolerates any junk shape: the report's
    contract is "always renders".
    """
    now = int(time.time()) if now is None else now
    if not isinstance(record, dict):
        return "[COLOR yellow]not checked yet[/COLOR]"

    def _int(key: str) -> int:
        try:
            return int(record.get(key, 0) or 0)
        except (TypeError, ValueError):
            return 0

    checked_at = _int("checked_at")
    if not checked_at:
        return "[COLOR yellow]not checked (last attempt failed: {})[/COLOR]".format(
            record.get("last_error") or "unknown")
    age_h = max(0, now - checked_at) // 3600
    age = "checked {}h ago".format(age_h) if age_h else "checked just now"
    # A newer failed attempt means the verdict shown is the last one we could
    # get, not the current one -- say so instead of presenting it as live.
    if _int("last_attempt_at") > checked_at:
        age += ", latest check failed: {}".format(record.get("last_error") or "unknown")

    state = record.get("state")
    if state == "premium":
        exp = _int("expires_at")
        if exp <= now:
            return "[COLOR red]premium has run out[/COLOR] ({})".format(age)
        days = (exp - now) // 86400
        colour = "lightgreen" if days > 7 else "yellow"
        return "[COLOR {}]premium, {} days left (until {})[/COLOR] ({})".format(
            colour, days, time.strftime("%Y-%m-%d", time.localtime(exp)), age)
    if state == "free":
        return "[COLOR red]NOT PREMIUM - playback will fail until renewed[/COLOR] ({})".format(age)
    if state == "auth_failed":
        return "[COLOR red]login rejected by provider - re-authorize[/COLOR] ({})".format(age)
    return "[COLOR yellow]unknown state {!r}[/COLOR] ({})".format(state, age)


def gather_health_lines(vault_dir: str) -> List[str]:
    """Assemble the Aegis Health report — everything that otherwise needs an
    ADB/log dive: vault + token state, proxy, live-TV refresh, scraper count,
    addon versions."""
    lines: List[str] = []

    # --- Vault + tokens ---
    lines.append("[B]Vault & providers[/B]")
    vault_data: Dict[str, Any] = {}
    # Imported lazily (not at module load) so this resolves the vault module from
    # sys.modules at call time -- avoids freezing to a stale/faked binding when
    # this module is import-cached across a mixed test run.
    try:
        from aegis_vault import VaultStore
    except Exception:  # pragma: no cover - vault addon absent (headless profile)
        VaultStore = None
    if VaultStore is None:
        lines.append("  Vault module: [COLOR red]unavailable[/COLOR]")
    else:
        try:
            vault_data = VaultStore(vault_dir).read()
            lines.append("  Vault: [COLOR lightgreen]readable[/COLOR]")
        except Exception as exc:
            lines.append("  Vault: [COLOR red]unreadable ({})[/COLOR]".format(exc))
        lines.append("  Vault key: {}".format(vault_key_line(VaultStore, vault_dir)))

    rd = vault_data.get("rd", {}) if isinstance(vault_data, dict) else {}
    accounts = vault_data.get("account_status", {}) if isinstance(vault_data, dict) else {}
    if not isinstance(accounts, dict):
        accounts = {}
    if rd.get("refresh_token") or rd.get("access_token"):
        # A restored/foreign/hand-edited vault could carry a non-numeric
        # expires_at (e.g. an ISO string). Never let that fail the whole
        # report — the health screen's contract is "always renders".
        try:
            exp = int(rd.get("expires_at", 0) or 0)
        except (TypeError, ValueError):
            exp = 0
        if exp:
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(exp))
            remaining = exp - int(time.time())
            status = "expires {}".format(when) if remaining > 0 else "[COLOR red]expired {}[/COLOR]".format(when)
            lines.append("  Real-Debrid: linked (access token {})".format(status))
        else:
            lines.append("  Real-Debrid: linked")
        lines.append("    Account: {}".format(account_line(accounts.get("rd"))))
    else:
        lines.append("  Real-Debrid: [COLOR yellow]not linked[/COLOR]")
    if (vault_data.get("ad", {}) or {}).get("apikey"):
        lines.append("  AllDebrid: linked")
        lines.append("    Account: {}".format(account_line(accounts.get("ad"))))
    else:
        lines.append("  AllDebrid: not linked")
    lines.append("  Trakt: {}".format(trakt_line(vault_data)))

    # --- Scraper ---
    enabled = testneto_enabled_providers()
    if enabled is None:
        lines.append("  Scraper (testneto): [COLOR yellow]not installed[/COLOR]")
    else:
        # The count is no longer coloured green on its own: enabled is a
        # setting, not a result. The Results line below carries the verdict.
        modules = testneto_scraper_modules()
        if modules is not None:
            not_scrapers = sorted(name for name in enabled if name not in modules)
            enabled = [name for name in enabled if name in modules]
        else:
            not_scrapers = []
        if enabled:
            lines.append("  Scraper (testneto): {} providers enabled".format(len(enabled)))
            if not_scrapers:
                lines.append("    (not counted, not a scraper Umbrella queries: {})".format(
                    ", ".join(not_scrapers)))
            try:
                activity = scraper_activity(xbmcvfs.translatePath(UMBRELLA_PROVIDER_CACHE))
            except Exception as exc:
                activity = {"error": type(exc).__name__}
            lines.extend(scraper_lines(enabled, activity))
        else:
            lines.append("  Scraper (testneto): [COLOR red]0 providers enabled[/COLOR]")

    # --- Live TV proxy + refresh ---
    lines.append("")
    lines.append("[B]Live TV[/B]")
    port = xbmcgui.Window(10000).getProperty("aegis_proxy_port")
    if port:
        lines.append("  HLS proxy: [COLOR lightgreen]running on 127.0.0.1:{}[/COLOR]".format(port))
    else:
        lines.append("  HLS proxy: [COLOR yellow]not running[/COLOR] (routing direct to ffmpegdirect)")
    live = vault_data.get("live_tv", {}) if isinstance(vault_data, dict) else {}
    # A restored/hand-edited vault could store a non-numeric last_refresh_at;
    # never let that abort the report (contract: always renders), same as the
    # expires_at guard above.
    try:
        ts = int(live.get("last_refresh_at", 0) or 0)
    except (TypeError, ValueError):
        ts = 0
    if ts > 0:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))
        res = live.get("last_refresh_result", {}) or {}
        lines.append("  Last refresh: {} ({} channels, dedup {}, {} errors)".format(
            when, res.get("total_channels", "?"), res.get("dedup_count", "?"),
            res.get("error_count", "?")))
    else:
        lines.append("  Last refresh: never")

    # --- Security ---
    lines.append("")
    lines.append("[B]Security[/B]")
    lines.extend(security_lines())

    # --- Versions ---
    lines.append("")
    lines.append("[B]Addon versions[/B]")
    lines.extend(release_lines(vault_data.get("release_status") if isinstance(vault_data, dict) else None))
    try:
        origin_summary, origin_notes = origin_lines(
            HEALTH_ADDON_IDS, install_origins(xbmcvfs.translatePath(KODI_DATABASE_DIR)))
    except Exception as exc:  # contract: the report always renders
        origin_summary, origin_notes = (
            ["  Install source: [COLOR yellow]not checked ({})[/COLOR]".format(type(exc).__name__)], {})
    lines.extend(origin_summary)
    for aid in HEALTH_ADDON_IDS:
        note = origin_notes.get(aid)
        lines.append("  {}: {}{}".format(aid, addon_version(aid), " - {}".format(note) if note else ""))

    return lines
