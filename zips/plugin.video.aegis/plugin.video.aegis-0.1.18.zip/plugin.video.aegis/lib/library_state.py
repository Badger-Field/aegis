"""Continue-watching + favorites state, stored in the Aegis Vault.

Pure functions over a vault payload dict — no Kodi/xbmc imports — so this
module is fully testable in isolation. Callers handle the surrounding
VaultStore I/O.

Vault schema (top-level keys added by this module):

    resume_state = {
        "movies":   { <prefixed_id>: <ResumeRecord> },
        "episodes": { <prefixed_id>: <ResumeRecord> },
    }
    favorites = {
        "movies": [ <FavoriteRecord>, ... ],
        "shows":  [ <FavoriteRecord>, ... ],
    }

`<prefixed_id>` is `"<source>:<id>"`. Recognized sources are `imdb`,
`tmdb`, `trakt`, and `tvdb` — no per-bucket restriction; both movies
and episodes may use any of them (callers generally prefer imdb when
available since it's the broadest cross-source identifier; tmdb when
imdb is missing). Unknown prefixes round-trip unchanged.

ResumeRecord and FavoriteRecord are JSON-serializable dicts; see the
helper builders below for canonical shapes. Unknown keys on either
record are preserved on round-trip so a newer addon writing an extra
field won't lose it when an older addon reads and rewrites the vault.
"""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Tuple


def _safe_int(value: Any, default: int = 0) -> int:
    """Coerce a vault value to int, falling back to `default` on
    None / non-numeric / unexpected type. Used everywhere we read
    int-ish vault fields (watched_at, added_at, season, etc.) so a
    corrupted or hand-edited record can't take down the UI path."""
    if value is None:
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default

# Watched-percentage band that counts as "still watching" — outside this
# band we drop the resume entry (too-early scrubs are likely accidental
# previews; too-late ones effectively finished and shouldn't pollute
# Continue Watching).
RESUME_MIN_PERCENT = 0.05
RESUME_MAX_PERCENT = 0.90

# Anything older than this falls off Continue Watching even if the user
# never finished it — Netflix-style "stale partials disappear" rule so
# the row doesn't accumulate forever.
RESUME_TTL_SECONDS = 90 * 86400  # 90 days


# ---------- ResumeRecord helpers ----------


def make_resume_record(
    *,
    item_type: str,
    item_id: str,
    title: str,
    position_sec: float,
    duration_sec: float,
    poster: str = "",
    year: Optional[int] = None,
    show: Optional[str] = None,
    season: Optional[int] = None,
    episode: Optional[int] = None,
    watched_at: Optional[int] = None,
) -> Dict[str, Any]:
    """Build a canonical resume record. `item_type` is 'movie' or 'episode';
    show/season/episode are only meaningful for episodes."""
    rec: Dict[str, Any] = {
        "type": item_type,
        "id": item_id,
        "title": title,
        "position_sec": float(position_sec),
        "duration_sec": float(duration_sec),
        "poster": poster,
        "watched_at": int(watched_at if watched_at is not None else time.time()),
    }
    if year is not None:
        rec["year"] = int(year)
    if item_type == "episode":
        if show:
            rec["show"] = show
        if season is not None:
            rec["season"] = int(season)
        if episode is not None:
            rec["episode"] = int(episode)
    return rec


def progress_fraction(rec: Dict[str, Any]) -> float:
    """0.0..1.0 — how far through the item. Returns 0 on bad input —
    including non-numeric vault values (corrupted payload, hand-edited
    JSON), so the home-screen render path can't be taken down by a
    single malformed record."""
    try:
        pos = float(rec.get("position_sec", 0) or 0)
        dur = float(rec.get("duration_sec", 0) or 0)
    except (TypeError, ValueError):
        return 0.0
    if dur <= 0:
        return 0.0
    f = pos / dur
    if f < 0:
        return 0.0
    if f > 1:
        return 1.0
    return f


def should_record_resume(position_sec: float, duration_sec: float) -> bool:
    """Caller-side gate: is this playback worth recording?

    Below RESUME_MIN_PERCENT the user probably scrubbed in by accident or
    aborted before getting into the content. Above RESUME_MAX_PERCENT
    they've effectively finished and putting it on Continue Watching is
    noise (and worse, a Netflix-style "scoreboard error"). A duration of
    0 means we never got reliable length info — skip.
    """
    if duration_sec <= 0:
        return False
    f = position_sec / duration_sec
    return RESUME_MIN_PERCENT <= f <= RESUME_MAX_PERCENT


# ---------- vault-level resume operations ----------


def _resume_root(vault: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Return (and lazily create) the resume_state sub-dict."""
    root = vault.setdefault("resume_state", {})
    root.setdefault("movies", {})
    root.setdefault("episodes", {})
    return root


def upsert_resume(vault: Dict[str, Any], rec: Dict[str, Any]) -> None:
    """Insert or update a resume record. Bucketed by item_type → id.

    Mutates `vault` in place. Caller is responsible for VaultStore.write.
    """
    root = _resume_root(vault)
    bucket = "movies" if rec["type"] == "movie" else "episodes"
    root[bucket][rec["id"]] = rec


def drop_resume(vault: Dict[str, Any], item_type: str, item_id: str) -> bool:
    """Remove a resume record (e.g., when playback completes). Returns True
    if anything was removed."""
    root = _resume_root(vault)
    bucket = "movies" if item_type == "movie" else "episodes"
    return root[bucket].pop(item_id, None) is not None


def prune_stale_resume(vault: Dict[str, Any], now: Optional[int] = None) -> int:
    """Drop resume records older than RESUME_TTL_SECONDS. Returns count
    pruned. Callers should run this opportunistically (e.g. on each
    Continue Watching render) — it's cheap."""
    now = int(now if now is not None else time.time())
    cutoff = now - RESUME_TTL_SECONDS
    pruned = 0
    root = _resume_root(vault)
    for bucket in ("movies", "episodes"):
        stale = [
            k for k, v in root[bucket].items()
            if _safe_int(v.get("watched_at"), 0) < cutoff
        ]
        for k in stale:
            del root[bucket][k]
            pruned += 1
    return pruned


def list_resume(vault: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Flat list of all resume records, newest watched_at first.

    Returns a shallow copy of each record so the caller can safely mutate
    fields like `poster` / `progress` for UI without writing back to the
    vault.
    """
    root = _resume_root(vault)
    out = list(root["movies"].values()) + list(root["episodes"].values())
    out.sort(key=lambda r: _safe_int(r.get("watched_at"), 0), reverse=True)
    return [dict(r) for r in out]


# ---------- FavoriteRecord helpers ----------


def make_favorite_record(
    *,
    item_type: str,
    item_id: str,
    title: str,
    year: Optional[int] = None,
    poster: str = "",
    added_at: Optional[int] = None,
) -> Dict[str, Any]:
    """Build a canonical favorite record. item_type is 'movie' or 'show'."""
    rec: Dict[str, Any] = {
        "type": item_type,
        "id": item_id,
        "title": title,
        "poster": poster,
        "added_at": int(added_at if added_at is not None else time.time()),
    }
    if year is not None:
        rec["year"] = int(year)
    return rec


# ---------- vault-level favorites operations ----------


def _favorites_root(vault: Dict[str, Any]) -> Dict[str, List[Dict[str, Any]]]:
    root = vault.setdefault("favorites", {})
    root.setdefault("movies", [])
    root.setdefault("shows", [])
    return root


def is_favorite(vault: Dict[str, Any], item_type: str, item_id: str) -> bool:
    root = _favorites_root(vault)
    bucket = "movies" if item_type == "movie" else "shows"
    return any(r.get("id") == item_id for r in root[bucket])


def add_favorite(vault: Dict[str, Any], rec: Dict[str, Any]) -> bool:
    """Add a favorite if not already present. Returns True if added (False
    if it was already there — caller can use that to short-circuit a
    Trakt sync push for duplicates)."""
    root = _favorites_root(vault)
    bucket = "movies" if rec["type"] == "movie" else "shows"
    if any(r.get("id") == rec["id"] for r in root[bucket]):
        return False
    root[bucket].append(rec)
    return True


def remove_favorite(vault: Dict[str, Any], item_type: str, item_id: str) -> bool:
    root = _favorites_root(vault)
    bucket = "movies" if item_type == "movie" else "shows"
    before = len(root[bucket])
    root[bucket] = [r for r in root[bucket] if r.get("id") != item_id]
    return len(root[bucket]) < before


def list_favorites(vault: Dict[str, Any], item_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return favorites, optionally filtered to one type. Newest first."""
    root = _favorites_root(vault)
    if item_type == "movie":
        out = list(root["movies"])
    elif item_type == "show":
        out = list(root["shows"])
    else:
        out = list(root["movies"]) + list(root["shows"])
    out.sort(key=lambda r: _safe_int(r.get("added_at"), 0), reverse=True)
    return [dict(r) for r in out]


# ---------- merge with Trakt-sourced records ----------


def merge_resume_with_trakt(
    local: List[Dict[str, Any]],
    trakt_movies: List[Dict[str, Any]],
    trakt_episodes: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Merge local resume records with Trakt's playback sync output.

    Dedup key: (type, id). When both sides have a record for the same
    item, the one with the newer `watched_at` wins so a recently-played
    item on one device shows the correct progress when surfaced on
    another.

    The Trakt-side records must already be normalized to the same shape
    as `make_resume_record` output (caller's job). Returns a new list
    sorted by watched_at desc.
    """
    by_key: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for rec in local + trakt_movies + trakt_episodes:
        key = (rec.get("type", ""), rec.get("id", ""))
        if not key[0] or not key[1]:
            continue
        existing = by_key.get(key)
        if existing is None or _safe_int(rec.get("watched_at"), 0) > _safe_int(existing.get("watched_at"), 0):
            by_key[key] = dict(rec)
    out = list(by_key.values())
    out.sort(key=lambda r: _safe_int(r.get("watched_at"), 0), reverse=True)
    return out


# ---------- race-safe vault merge ----------


def apply_resume_to_vault(
    fresh_vault: Dict[str, Any],
    upsert: Optional[Dict[str, Any]] = None,
    drop: Optional[Tuple[str, str]] = None,
) -> None:
    """Apply a single resume mutation to a freshly-read vault dict.

    Designed for the player monitor's capture loop: read the vault,
    apply the in-flight mutation, write it back. By only touching the
    resume_state subtree (not the entire vault dict the caller may have
    been holding before), we avoid stomping concurrent writes to other
    subtrees like `favorites` or `trakt` that another addon path may
    have updated between the player monitor's read and its write.

    Pass either:
        upsert=<ResumeRecord>            insert or replace
        drop=(item_type, item_id)        remove (returns silently if absent)

    Both can be passed in the same call only if they don't conflict;
    callers normally use one or the other based on whether the play
    finished or paused mid-stream.
    """
    if upsert is not None:
        upsert_resume(fresh_vault, upsert)
    if drop is not None:
        drop_resume(fresh_vault, drop[0], drop[1])
