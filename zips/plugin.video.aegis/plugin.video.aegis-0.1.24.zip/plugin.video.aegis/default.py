import importlib.util
import json
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import parse_qsl, urlencode, urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    from aegis_vault import VaultStore as _VaultStore
except Exception:
    _VaultStore = None

try:
    from aegis_vault import VaultBackupError as _VaultBackupError
except Exception:
    _VaultBackupError = None

try:
    from aegis_netguard import GuardedSession as _GuardedSession
except Exception:
    _GuardedSession = None

VaultStore = _VaultStore
VaultBackupError = _VaultBackupError
GuardedSession = _GuardedSession

# Add lib/ to sys.path so we can import the in-addon helper modules
# (library_state etc.) without making them top-level imports that would
# require the script.module.* dance.
_PLUGIN_LIB = Path(__file__).resolve().parent / "lib"
if str(_PLUGIN_LIB) not in sys.path:
    sys.path.insert(0, str(_PLUGIN_LIB))

try:
    import library_state  # type: ignore[import-not-found]
except Exception:
    library_state = None  # type: ignore[assignment]


DIRECTORY_ACTIONS = {
    "home",
    "movies",
    "shows",
    "search",
    "settings_panel",
    "search_movies",
    "search_tv",
    "rd_cloud",
    "games",
    "sports",
    "widget_continue",
    "widget_recent_games",
    "widget_live_tv",
    "tv_refresh_apply",
    "favorites",
    "favorites_movies",
    "favorites_shows",
    # Intentionally absent from DIRECTORY_ACTIONS: "toggle_favorite" — it's
    # an action that mutates state and refreshes the container, not a
    # directory render. Same for "tv_play". `continue_watching` is also
    # absent: there's no separate route — _show_home() and the
    # widget_continue endpoint handle the surface together.
}


def _resolve_handle() -> int:
    try:
        return int(sys.argv[1])
    except Exception:
        return -1


HANDLE = _resolve_handle()
ADDON = xbmcaddon.Addon()
UMBRELLA_PLUGIN_URL = "plugin://plugin.video.umbrella/"
UMBRELLA_DIRECTORY_ACTIONS = {
    "movieNavigator",
    "tvNavigator",
    "rd_ServiceNavigator",
}


def _is_harness_runtime() -> bool:
    try:
        return bool(
            xbmc.getCondVisibility("System.HasAddon(service.aegis.harness)")
            or xbmc.getCondVisibility("System.HasAddon(service.aegis.click_through_harness)")
            or xbmc.getCondVisibility("System.HasAddon(service.aegis.live_tv_harness)")
        )
    except Exception:
        return False


def _vault_dir():
    return xbmcvfs.translatePath("special://masterprofile/aegis")


def _url(query):
    return "{}?{}".format(sys.argv[0], urlencode(query))


def _add_item(label, action):
    if HANDLE < 0:
        return
    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, _url({"action": action}), item, True)


def _add_external_item(label: str, url: str, is_folder: bool = True) -> None:
    if HANDLE < 0:
        return
    item = xbmcgui.ListItem(label=label)
    item.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url, item, is_folder)


def _add_header_item(label):
    if HANDLE < 0:
        return
    item = xbmcgui.ListItem(label=label)
    if hasattr(item, "setSelectable"):
        item.setSelectable(False)
    xbmcplugin.addDirectoryItem(HANDLE, "", item, False)


def _get_enabled_providers() -> List[str]:
    """Get list of enabled debrid providers from settings."""
    providers = []
    if _setting_bool("provider_rd_enabled"):
        providers.append("Real-Debrid")
    if _setting_bool("provider_pm_enabled"):
        providers.append("Premiumize")
    if _setting_bool("ad_enabled", _setting_bool("provider_ad_enabled")):
        providers.append("AllDebrid")
    return providers


def _setting_bool(setting_id: str, default: bool = False) -> bool:
    # Prefer string read to avoid Kodi type-mismatch logs; bool getter is fallback.
    raw = None
    try:
        raw = ADDON.getSetting(setting_id)
    except Exception:
        pass

    normalized = str(raw).strip().lower() if raw is not None else ""
    if normalized in {"true", "1", "yes", "on"}:
        return True
    if normalized in {"false", "0", "no", "off"}:
        return False

    if not _is_harness_runtime() and hasattr(ADDON, "getSettingBool"):
        try:
            return bool(ADDON.getSettingBool(setting_id))
        except Exception:
            pass
    return default


def _home_library_counts() -> tuple:
    """Single vault read for the home page's Continue Watching + Favorites
    row decisions. The home page must not block on Trakt, so this only
    looks at the local vault — users with Trakt-only state see the row
    appear once they've played one thing locally; clicking the route
    directly still fetches Trakt.

    Prunes stale resume entries in-memory (no write-back); the widget
    render path does the persistent prune-and-write.
    """
    if library_state is None or VaultStore is None:
        return (0, 0)
    try:
        payload = VaultStore(_vault_dir()).read()
        library_state.prune_stale_resume(payload)
        return (
            len(library_state.list_resume(payload)),
            len(library_state.list_favorites(payload)),
        )
    except Exception:
        return (0, 0)


def _show_home():
    if HANDLE < 0:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Aegis")
    xbmcplugin.setContent(HANDLE, "addons")

    providers = _get_enabled_providers()
    if providers:
        provider_text = "Providers: {}".format(", ".join(providers))
    else:
        provider_text = "No providers enabled - configure in Settings"
    _add_header_item(provider_text)

    # Continue Watching + Favorites surface first when there's anything
    # in either — Netflix-style. Skip entries that are empty so the home
    # screen doesn't gain a permanent dead row for users who never play
    # anything through Aegis. One vault read for both checks.
    cw_count, fav_count = _home_library_counts()
    if cw_count:
        _add_item("Continue Watching", "widget_continue")
    if fav_count:
        _add_item("Favorites", "favorites")

    _add_item("Movies", "movies")
    _add_item("Shows", "shows")
    _add_item("Search", "search")
    _add_item("Live TV", "live_tv")
    _add_item("Sports", "sports")
    _add_item("Games", "games")
    _add_item("RD Cloud", "rd_cloud")
    _add_item("Remote Control", "remote")
    # Route in-plugin Settings to the panel (Authorize RD/AD/etc) so users get
    # actionable entries here instead of a stub that tries to open the Kodi
    # native settings dialog from a directory context (which leaves a blank tab).
    _add_item("Settings", "settings_panel")
    xbmcplugin.endOfDirectory(HANDLE)


def _show_search_menu():
    if HANDLE < 0:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Aegis Search")
    xbmcplugin.setContent(HANDLE, "addons")
    _add_item("Movies", "search_movies")
    _add_item("TV Shows", "search_tv")
    xbmcplugin.endOfDirectory(HANDLE)


def _show_settings_panel():
    if HANDLE < 0:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Aegis Settings")
    xbmcplugin.setContent(HANDLE, "addons")
    _add_item("Aegis Settings", "settings")
    _add_item("Authorize Real-Debrid", "rd_setup")
    _add_item("Authorize AllDebrid", "ad_setup")
    _add_item("Run First-Run Setup", "firstrun")
    _add_item("Remote Control", "remote")
    _add_item("Live TV Refresh", "live_tv_refresh")
    xbmcplugin.endOfDirectory(HANDLE)


def _notify(message):
    xbmcgui.Dialog().notification("Aegis", message, xbmcgui.NOTIFICATION_INFO, 3000)
    _show_home()


def rpc(method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    except Exception as exc:
        return {"error": {"message": str(exc)}}


def _has_rd_credentials() -> bool:
    if VaultStore is None:
        return False
    try:
        payload = VaultStore(_vault_dir()).read()
    except Exception:
        return False
    rd = payload.get("rd", {})
    return bool(rd.get("access_token") and rd.get("refresh_token"))


def _is_firstrun_complete() -> bool:
    try:
        firstrun = xbmcaddon.Addon("service.aegis.firstrun")
    except Exception:
        return False

    try:
        raw = firstrun.getSetting("firstrun_complete")
        normalized = str(raw).strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off"}:
            return False
    except Exception:
        pass

    if not _is_harness_runtime() and hasattr(firstrun, "getSettingBool"):
        try:
            return bool(firstrun.getSettingBool("firstrun_complete"))
        except Exception:
            pass
    return False


def _dispatch_to_umbrella(action: str, folder_name: Optional[str] = None) -> None:
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.umbrella)"):
        _notify("Umbrella addon is not installed yet.")
        return

    # Some Kodi profiles keep installed addons disabled until they are explicitly
    # re-enabled. Click-through routes need the addon active before RunPlugin.
    try:
        rpc("Addons.SetAddonEnabled", {"addonid": "plugin.video.umbrella", "enabled": True})
    except Exception:
        pass
    for _attempt in range(5):
        if xbmc.getCondVisibility("System.HasAddon(plugin.video.umbrella)"):
            break
        time.sleep(1)

    # Umbrella imports requests in runtime paths; without it, clicks look like no-ops.
    requests_addon_xml = xbmcvfs.translatePath("special://home/addons/script.module.requests/addon.xml")
    if not xbmcvfs.exists(requests_addon_xml):
        _notify("Umbrella dependency missing: script.module.requests")
        return

    if _setting_bool("provider_rd_enabled") and not _has_rd_credentials():
        if not _is_firstrun_complete():
            _notify("Real-Debrid is enabled but not authorized yet. First-run setup is incomplete.")
        else:
            _notify("Real-Debrid is enabled but not authorized yet. Run first setup.")
        return

    query = {"action": action}
    if folder_name:
        query["folderName"] = folder_name
    encoded = urlencode(query)
    url = "{}?{}".format(UMBRELLA_PLUGIN_URL, encoded)

    if action in UMBRELLA_DIRECTORY_ACTIONS:
        xbmc.executebuiltin("ActivateWindow(Videos,{},return)".format(url))
    else:
        xbmc.executebuiltin("RunPlugin({})".format(url))
    _close_directory_if_needed()


def _route_movies():
    if HANDLE < 0:
        _dispatch_to_umbrella("movieNavigator", "Discover Movies")
        return
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.umbrella)"):
        _notify("Umbrella addon is not installed yet.")
        _close_directory_if_needed()
        return
    xbmcplugin.setPluginCategory(HANDLE, "Aegis Movies")
    xbmcplugin.setContent(HANDLE, "addons")
    _add_external_item("Discover Movies", "plugin://plugin.video.umbrella/?action=movieNavigator&folderName=Discover%20Movies")
    _add_external_item("Search Movies", "plugin://plugin.video.umbrella/?action=movieSearchnew", False)
    xbmcplugin.endOfDirectory(HANDLE)


def _route_shows():
    if HANDLE < 0:
        _dispatch_to_umbrella("tvNavigator", "Discover TV Shows")
        return
    if not xbmc.getCondVisibility("System.HasAddon(plugin.video.umbrella)"):
        _notify("Umbrella addon is not installed yet.")
        _close_directory_if_needed()
        return
    xbmcplugin.setPluginCategory(HANDLE, "Aegis Shows")
    xbmcplugin.setContent(HANDLE, "addons")
    _add_external_item("Discover TV Shows", "plugin://plugin.video.umbrella/?action=tvNavigator&folderName=Discover%20TV%20Shows")
    _add_external_item("Search TV Shows", "plugin://plugin.video.umbrella/?action=tvSearchnew", False)
    xbmcplugin.endOfDirectory(HANDLE)


def _route_search_movies():
    _dispatch_to_umbrella("movieSearchnew")


def _route_search_tv():
    _dispatch_to_umbrella("tvSearchnew")


def _route_rd_cloud():
    _dispatch_to_umbrella("rd_ServiceNavigator", "Real-Debrid")


def _route_firstrun(query: Optional[Dict[str, str]] = None) -> None:
    query = query or {}
    force = query.get("force", "0") == "1"
    try:
        firstrun = xbmcaddon.Addon("service.aegis.firstrun")
    except Exception:
        _notify("First-run addon is not installed.")
        return

    complete = _is_firstrun_complete()

    if complete and not force:
        rerun = xbmcgui.Dialog().yesno(
            "Aegis",
            "First-run setup is already complete.\nRun it again for testing?",
        )
        if not rerun:
            _show_home()
            return

    # Let user pick which debrid providers to configure in this run.
    provider_labels = ["Real-Debrid", "Premiumize", "AllDebrid"]
    preselect = []
    if _setting_bool("provider_rd_enabled"):
        preselect.append(0)
    if _setting_bool("provider_pm_enabled"):
        preselect.append(1)
    if _setting_bool("ad_enabled", _setting_bool("provider_ad_enabled")):
        preselect.append(2)

    selected = xbmcgui.Dialog().multiselect(
        "Aegis — Debrid Providers",
        provider_labels,
        preselect=preselect,
    )
    if selected is None:
        _show_home()
        return

    ADDON.setSetting("provider_rd_enabled", "true" if 0 in selected else "false")
    ADDON.setSetting("provider_pm_enabled", "true" if 1 in selected else "false")
    ad_selected = 2 in selected
    ADDON.setSetting("provider_ad_enabled", "true" if ad_selected else "false")
    ADDON.setSetting("ad_enabled", "true" if ad_selected else "false")

    try:
        # Use string write first because some Kodi builds persist legacy bool schemas.
        firstrun.setSetting("firstrun_complete", "false")
    except Exception:
        try:
            if hasattr(firstrun, "setSettingBool"):
                firstrun.setSettingBool("firstrun_complete", False)
        except Exception:
            pass

    # In harness click-through, avoid launching the service script directly because
    # it is not a plugin/script addon entry point and causes route-level failures.
    if xbmc.getCondVisibility("System.HasAddon(service.aegis.click_through_harness)"):
        xbmcgui.Dialog().notification("Aegis", "First-run setup queued (harness mode).", xbmcgui.NOTIFICATION_INFO, 2000)
        _show_home()
        return

    service_path = xbmcvfs.translatePath("special://home/addons/service.aegis.firstrun/service.py")
    if not xbmcvfs.exists(service_path):
        _notify("First-run service script is missing.")
        return

    # Invoke the service module inline so Kodi keeps a valid addon context and
    # does not log CPythonInvoker "No valid addon id" errors.
    try:
        spec = importlib.util.spec_from_file_location("aegis_firstrun_service", service_path)
        if spec is None or spec.loader is None:
            raise RuntimeError("Unable to load first-run service module spec")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if not hasattr(module, "main"):
            raise RuntimeError("First-run service module has no main()")
        module.main()
    except Exception as exc:
        xbmc.log("Aegis: failed to start first-run setup inline: {}".format(exc), xbmc.LOGERROR)
        _notify("Failed to start first-run setup.")
        return

    xbmcgui.Dialog().notification("Aegis", "First-run setup started.", xbmcgui.NOTIFICATION_INFO, 3000)
    _show_home()


def _route_rd_setup(query: Optional[Dict[str, str]] = None) -> None:
    query = query or {}
    headless = query.get("headless", "0") == "1"
    try:
        service_path = xbmcvfs.translatePath("special://home/addons/service.aegis.firstrun/service.py")
        if not xbmcvfs.exists(service_path):
            _notify("First-run service script is missing.")
            return

        spec = importlib.util.spec_from_file_location("aegis_firstrun_service_rd", service_path)
        if spec is None or spec.loader is None:
            raise RuntimeError("Unable to load first-run service module spec")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        vault = module.VaultStore(module._vault_dir())
        module._run_rd_device_flow(vault)
        ADDON.setSetting("provider_rd_enabled", "true")
        module._sync_umbrella_rd_settings(vault, True)
        xbmcgui.Window(10000).clearProperty("umbrella_settings")
        xbmcgui.Window(10000).setProperty("umbrella.updateSettings", "true")

        if not headless:
            xbmcgui.Dialog().notification("Aegis", "Real-Debrid setup complete.", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as exc:
        xbmc.log("Aegis: failed to rerun Real-Debrid setup: {}".format(exc), xbmc.LOGERROR)
        if not headless:
            xbmcgui.Dialog().notification("Aegis", "Real-Debrid setup failed.", xbmcgui.NOTIFICATION_ERROR, 3000)
    finally:
        _close_directory_if_needed()


def _route_ad_setup(query: Optional[Dict[str, str]] = None) -> None:
    query = query or {}
    headless = query.get("headless", "0") == "1"
    try:
        service_path = xbmcvfs.translatePath("special://home/addons/service.aegis.firstrun/service.py")
        if not xbmcvfs.exists(service_path):
            _notify("First-run service script is missing.")
            return

        spec = importlib.util.spec_from_file_location("aegis_firstrun_service_ad", service_path)
        if spec is None or spec.loader is None:
            raise RuntimeError("Unable to load first-run service module spec")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        vault = module.VaultStore(module._vault_dir())
        module._run_ad_device_flow(vault)
        ADDON.setSetting("provider_ad_enabled", "true")
        ADDON.setSetting("ad_enabled", "true")
        module._sync_umbrella_ad_settings(vault, True)
        xbmcgui.Window(10000).clearProperty("umbrella_settings")
        xbmcgui.Window(10000).setProperty("umbrella.updateSettings", "true")

        if not headless:
            xbmcgui.Dialog().notification("Aegis", "AllDebrid setup complete.", xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception as exc:
        xbmc.log("Aegis: failed to rerun AllDebrid setup: {}".format(exc), xbmc.LOGERROR)
        if not headless:
            xbmcgui.Dialog().notification("Aegis", "AllDebrid setup failed.", xbmcgui.NOTIFICATION_ERROR, 3000)
    finally:
        _close_directory_if_needed()


def _show_remote_control(query: Optional[Dict[str, str]] = None):
    """Display remote control access details (JSON-RPC credentials)."""
    try:
        query = query or {}
        if query.get("headless", "0") == "1":
            _close_directory_if_needed()
            return
        if VaultStore is None:
            xbmcgui.Dialog().notification("Aegis", "Vault module unavailable", xbmcgui.NOTIFICATION_ERROR, 3000)
            _show_home()
            return
        vault = VaultStore(_vault_dir())
        payload = vault.read()
        remote_data = payload.get("setup", {}).get("remote_control")
        
        if not remote_data:
            xbmcgui.Dialog().notification(
                "Aegis",
                "Remote control is not enabled. Run First-Run setup.",
                xbmcgui.NOTIFICATION_WARNING,
                3000,
            )
            _show_home()
            return
        
        username = remote_data.get("username", "kodi")
        password = remote_data.get("password", "")
        port = remote_data.get("port", 8080)
        
        # Build info text
        info_text = f"""
Remote Control (JSON-RPC)

Username: {username}
Port: {port}
Protocol: HTTP (LAN only)

Access URL:
http://{username}:<password>@<hostname>.local:{port}/jsonrpc

Hostname: <your-kodi-hostname>
(or use LAN IP if .local doesn't resolve)
        """.strip()
        
        # Show info with option to reveal password
        revealed = False
        while True:
            info_text.replace("<password>", "*" * len(password) if not revealed else password)
            
            if revealed:
                choice = xbmcgui.Dialog().contextmenu(
                    ["OK", "Hide Password", "Copy URL to Clipboard"]
                )
            else:
                choice = xbmcgui.Dialog().contextmenu(
                    ["OK", "Reveal Password"]
                )
            
            if choice in (-1, 0):  # Cancel / OK
                break
            elif choice == 1:  # Toggle password visibility
                revealed = not revealed
            elif choice == 2 and revealed:  # Copy to clipboard
                try:
                    import subprocess
                    url = f"http://{username}:{password}@<hostname>.local:{port}/jsonrpc"
                    subprocess.run(["clip"], input=url.encode(), check=True)
                    xbmcgui.Dialog().notification("Aegis", "URL copied to clipboard", xbmcgui.NOTIFICATION_INFO, 2000)
                except Exception:
                    pass
        
        _show_home()
    except Exception as exc:
        xbmc.log(f"Error showing remote control info: {exc}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("Aegis", "Error accessing remote control info", xbmcgui.NOTIFICATION_ERROR, 3000)
        _show_home()


def _show_games():
    """Show gaming menu or dispatch to IAGL if available."""
    if xbmc.getCondVisibility("System.HasAddon(plugin.program.iagl)"):
        # IAGL is installed, dispatch to it
        xbmc.executebuiltin("RunPlugin(plugin://plugin.program.iagl/)")
    else:
        # Show info and hint to install gaming addons
        xbmcgui.Dialog().notification(
            "Aegis",
            "Install gaming addons via First-Run setup (Settings > Add-ons).",
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
        _show_home()


def _split_prefixed_id(prefix_id: str) -> Tuple[str, str]:
    """Split a library_state id like "imdb:tt12345" into (prefix, id)."""
    if ":" in prefix_id:
        p, _, v = prefix_id.partition(":")
        return p, v
    return "", prefix_id


def _trakt_playback_to_resume_records(items: list, kind: str) -> list:
    """Normalize Trakt's /sync/playback response to library_state's
    ResumeRecord shape. `kind` is 'movie' or 'episode'.

    Each item is parsed inside its own try/except — a single malformed
    record from Trakt's response (unexpected type, partial payload)
    can't take down the whole Continue Watching widget render."""
    out = []
    if library_state is None:
        return out
    now = int(time.time())
    ttl_cutoff = now - library_state.RESUME_TTL_SECONDS
    for item in items or []:
        try:
            rec = _one_trakt_playback_record(item, kind)
        except Exception as exc:
            xbmc.log("Aegis Continue: skipping malformed Trakt item: {}".format(exc), xbmc.LOGWARNING)
            continue
        if rec is None:
            continue
        # Apply the same gates we use locally: drop ≤5% / ≥90% watched
        # (when we have a meaningful duration to compute that) and
        # drop entries older than RESUME_TTL_SECONDS. Otherwise Trakt
        # entries would show up under the Netflix-style rules
        # `should_record_resume` enforces for local capture.
        pos = float(rec.get("position_sec", 0) or 0)
        dur = float(rec.get("duration_sec", 0) or 0)
        if dur > 0 and not library_state.should_record_resume(pos, dur):
            continue
        # Only TTL-filter when we have a known watched_at; missing /
        # zero watched_at is "unknown freshness" — let it through and
        # sort it to the bottom of the merged list instead of dropping.
        watched_at = int(rec.get("watched_at", 0) or 0)
        if watched_at > 0 and watched_at < ttl_cutoff:
            continue
        out.append(rec)
    return out


def _one_trakt_playback_record(item: Dict[str, Any], kind: str):
    """Single-item helper for _trakt_playback_to_resume_records — kept
    separate so the per-item try/except in the caller stays readable.
    Returns the normalized ResumeRecord, or None if the item is missing
    required fields (no id we can map)."""
    progress = float(item.get("progress", 0) or 0)  # 0-100
    paused_at = item.get("paused_at", "")
    # Convert ISO-8601 → epoch (best-effort; default 0 sorts to bottom).
    watched_at = 0
    if paused_at:
        try:
            from datetime import datetime
            watched_at = int(datetime.fromisoformat(paused_at.replace("Z", "+00:00")).timestamp())
        except Exception:
            pass

    # Only IMDB/TMDB/TVDB-tagged ids are routable through Umbrella's play
    # action. Trakt-only ids would yield a Continue Watching click that
    # arrives at Umbrella with no usable scrape parameter (just title +
    # year), so the play silently fails. Drop those records up front
    # instead of polluting the row. (A future change could resolve
    # trakt:<id> → imdb:<id> via Trakt's summary endpoint.)
    if kind == "movie":
        movie = item.get("movie", {}) or {}
        ids = movie.get("ids", {}) or {}
        imdb = ids.get("imdb")
        tmdb = ids.get("tmdb")
        if imdb:
            item_id = "imdb:" + imdb
        elif tmdb:
            item_id = "tmdb:" + str(tmdb)
        else:
            return None  # trakt-only / no id → not routable
        duration = float((movie.get("runtime") or 0)) * 60.0  # minutes → seconds
        # Drop records with no runtime — without duration the progress bar
        # is meaningless and the user can't tell what "watched_at" refers to.
        if duration <= 0:
            return None
        position = duration * progress / 100.0
        return library_state.make_resume_record(
            item_type="movie",
            item_id=item_id,
            title=movie.get("title", ""),
            position_sec=position,
            duration_sec=duration,
            year=movie.get("year"),
            watched_at=watched_at,
        )
    elif kind == "episode":
        episode = item.get("episode", {}) or {}
        show = item.get("show", {}) or {}
        # Use the SHOW's id, not the episode's. Umbrella's play action
        # expects `imdb=<show_imdb>` + season/episode coordinates; the
        # episode-level imdb wouldn't resolve to the parent show. As a
        # side effect, this dedups Continue Watching to one row per
        # show (the most-recently-paused episode wins on watched_at).
        show_ids = show.get("ids", {}) or {}
        imdb = show_ids.get("imdb")
        tvdb = show_ids.get("tvdb")
        if imdb:
            item_id = "imdb:" + imdb
        elif tvdb:
            item_id = "tvdb:" + str(tvdb)
        else:
            return None  # trakt-only / no id → not routable
        duration = float((episode.get("runtime") or show.get("runtime") or 0)) * 60.0
        if duration <= 0:
            return None
        position = duration * progress / 100.0
        return library_state.make_resume_record(
            item_type="episode",
            item_id=item_id,
            title=episode.get("title", ""),
            position_sec=position,
            duration_sec=duration,
            show=show.get("title"),
            season=episode.get("season"),
            episode=episode.get("number"),
            watched_at=watched_at,
        )
    return None


def _umbrella_play_url_for_resume(rec: Dict[str, Any]) -> str:
    """Translate a resume record into an Umbrella play URL.

    Umbrella's generic `play` action takes imdb/tmdb/tvdb + season/episode
    params. We map our prefix-tagged ids back to those param names.
    """
    prefix, item_id = _split_prefixed_id(rec.get("id", ""))
    params: Dict[str, str] = {"action": "play"}
    if rec.get("title"):
        params["title"] = rec["title"]
    if rec.get("year"):
        params["year"] = str(rec["year"])
    # Map id prefix → Umbrella param name.
    if prefix == "imdb":
        params["imdb"] = item_id
    elif prefix == "tmdb":
        params["tmdb"] = item_id
    elif prefix == "tvdb":
        params["tvdb"] = item_id
    # `trakt:` ids alone don't get Umbrella anywhere — it needs imdb/tmdb
    # to scrape — but we still pass the title/year so user gets at least
    # a sensible failure rather than a silent no-op.
    if rec.get("type") == "episode":
        if rec.get("show"):
            params["tvshowtitle"] = rec["show"]
        if rec.get("season") is not None:
            params["season"] = str(rec["season"])
        if rec.get("episode") is not None:
            params["episode"] = str(rec["episode"])
    return UMBRELLA_PLUGIN_URL + "?" + urlencode(params)


def _widget_continue() -> None:
    """Display Continue Watching — local vault resume merged with Trakt
    playback sync (when linked). Items show progress bar, poster, and
    show/episode metadata; clicking routes to Umbrella's play action."""
    if HANDLE < 0:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Continue Watching")
    # Mixed movies + episodes — "videos" is the neutral content type;
    # "movies" would mis-classify episode entries for skins/sort methods.
    xbmcplugin.setContent(HANDLE, "videos")

    if library_state is None or VaultStore is None:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    try:
        vault = VaultStore(_vault_dir())
        payload = vault.read()
        # Prune stale (>90d) entries in-memory only so the row doesn't
        # show records the widget would otherwise hide. We deliberately
        # do NOT write back here — a write would overwrite any
        # concurrent resume / favorite mutation the player monitor (or
        # another addon path) may have made between our read and write.
        # The on-disk state gets a real prune on the next service-side
        # write (player capture writes through apply_resume_to_vault
        # which does its own fresh read).
        library_state.prune_stale_resume(payload)
        local_resume = library_state.list_resume(payload)

        trakt_movies: list = []
        trakt_episodes: list = []
        trakt_data = payload.get("trakt", {})
        if GuardedSession is not None and trakt_data.get("access_token"):
            session = GuardedSession(headers={"trakt-api-version": "2", "trakt-api-key": "aegis"})
            session.headers["Authorization"] = "Bearer {}".format(trakt_data.get("access_token"))
            # Tight timeout: this renders inline on the home screen, so a
            # slow/hung Trakt call can't be allowed to block the UI. 6s
            # is enough for a healthy Trakt round-trip; anything slower
            # falls back to local-only resume rather than holding the
            # widget hostage.
            try:
                resp = session.get("https://api.trakt.tv/sync/playback/movies", timeout=6)
                if resp.status_code == 200:
                    trakt_movies = _trakt_playback_to_resume_records(resp.json(), "movie")
            except Exception as exc:
                xbmc.log("Aegis Continue: Trakt movies fetch failed: {}".format(exc), xbmc.LOGWARNING)
            try:
                resp = session.get("https://api.trakt.tv/sync/playback/episodes", timeout=6)
                if resp.status_code == 200:
                    trakt_episodes = _trakt_playback_to_resume_records(resp.json(), "episode")
            except Exception as exc:
                xbmc.log("Aegis Continue: Trakt episodes fetch failed: {}".format(exc), xbmc.LOGWARNING)

        merged = library_state.merge_resume_with_trakt(local_resume, trakt_movies, trakt_episodes)

        for rec in merged:
            label = rec.get("title", "Unknown")
            if rec.get("type") == "episode" and rec.get("show"):
                # Netflix-style label for episodes: "Show — S01E03 · Episode Title"
                season = rec.get("season")
                episode = rec.get("episode")
                if season is not None and episode is not None:
                    label = "{} — S{:02d}E{:02d} · {}".format(
                        rec["show"], int(season), int(episode), rec.get("title", "")
                    ).rstrip(" ·")
                else:
                    label = "{} — {}".format(rec["show"], rec.get("title", ""))

            item = xbmcgui.ListItem(label=label)
            poster = rec.get("poster") or "DefaultVideo.png"
            item.setArt({"thumb": poster, "poster": poster, "icon": poster})

            # Surface progress in two places: the resume-point marker
            # (Kodi-native, drives the orange progress overlay on most
            # skins) and a "% watched" suffix in the label tail.
            if hasattr(item, "setProperty"):
                try:
                    pct = int(library_state.progress_fraction(rec) * 100)
                    item.setProperty("ResumeTime", str(int(rec.get("position_sec", 0))))
                    item.setProperty("TotalTime", str(int(rec.get("duration_sec", 0)) or 1))
                    item.setProperty("PercentPlayed", str(pct))
                    item.setProperty("WatchedProgress", str(pct))
                except Exception:
                    pass

            play_url = _umbrella_play_url_for_resume(rec)
            xbmcplugin.addDirectoryItem(HANDLE, play_url, item, False)

        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        xbmc.log("Aegis Continue Watching error: {}".format(exc), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)


# ---------- Favorites ----------


def _trakt_session() -> Optional[Any]:
    """Return an authenticated Trakt GuardedSession, or None if Trakt
    isn't linked. Used by both Continue Watching and Favorites sync."""
    if VaultStore is None or GuardedSession is None:
        return None
    try:
        payload = VaultStore(_vault_dir()).read()
    except Exception:
        return None
    token = (payload.get("trakt", {}) or {}).get("access_token", "")
    if not token:
        return None
    session = GuardedSession(headers={"trakt-api-version": "2", "trakt-api-key": "aegis"})
    session.headers["Authorization"] = "Bearer {}".format(token)
    return session


def _trakt_push_watchlist(rec: Dict[str, Any], remove: bool = False) -> None:
    """Best-effort push of a favorite to Trakt's watchlist. Swallows
    errors — local favorites are the source of truth; Trakt is optional
    overlay."""
    session = _trakt_session()
    if session is None:
        return
    prefix, item_id = _split_prefixed_id(rec.get("id", ""))
    if not prefix or not item_id:
        return
    # Trakt's `ids` block only recognizes a known set of sources. Forwarding
    # an unknown prefix (or a non-numeric value for tmdb/trakt/tvdb) leads
    # to 400 Bad Request and a silent sync failure; bail early instead.
    if prefix not in {"imdb", "tmdb", "trakt", "tvdb"}:
        return
    if prefix != "imdb" and not item_id.isdigit():
        return
    ids: Dict[str, Any] = {prefix: item_id if prefix == "imdb" else int(item_id)}
    body: Dict[str, Any] = {"movies": [], "shows": []}
    bucket = "movies" if rec.get("type") == "movie" else "shows"
    entry: Dict[str, Any] = {"ids": ids}
    if rec.get("title"):
        entry["title"] = rec["title"]
    if rec.get("year"):
        entry["year"] = rec["year"]
    body[bucket].append(entry)
    url = "https://api.trakt.tv/sync/watchlist"
    if remove:
        url = url + "/remove"
    try:
        # Tight timeout — this fires inline on the favorites toggle's UI
        # thread, so a hung Trakt POST would freeze the context menu.
        # Local is the source of truth; if the sync times out the user
        # still sees their favorite added locally and the next toggle
        # will retry.
        session.post(url, json=body, timeout=5)
    except Exception as exc:
        xbmc.log("Aegis Favorites: Trakt watchlist {} failed: {}".format(
            "remove" if remove else "add", exc), xbmc.LOGWARNING)


def _show_favorites() -> None:
    """Top-level Favorites router — picks movies/shows tabs."""
    if HANDLE < 0:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Aegis Favorites")
    xbmcplugin.setContent(HANDLE, "addons")
    _add_item("Favorite Movies", "favorites_movies")
    _add_item("Favorite Shows", "favorites_shows")
    xbmcplugin.endOfDirectory(HANDLE)


def _show_favorites_list(item_type: str) -> None:
    """Render the favorites list for movies or shows. Each entry routes
    to Umbrella's play (movies) or tvshowtitle navigator (shows) so users
    land on the actual content, not just a placeholder."""
    if HANDLE < 0:
        return
    label = "Favorite Movies" if item_type == "movie" else "Favorite Shows"
    xbmcplugin.setPluginCategory(HANDLE, label)
    xbmcplugin.setContent(HANDLE, "movies" if item_type == "movie" else "tvshows")

    if library_state is None or VaultStore is None:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    try:
        vault = VaultStore(_vault_dir())
        payload = vault.read()
        favs = library_state.list_favorites(payload, item_type=item_type)
        for rec in favs:
            label_text = rec.get("title", "Unknown")
            if rec.get("year"):
                label_text = "{} ({})".format(label_text, rec["year"])
            item = xbmcgui.ListItem(label=label_text)
            poster = rec.get("poster") or "DefaultVideo.png"
            item.setArt({"thumb": poster, "poster": poster, "icon": poster})

            # Build the target URL: movies route to Umbrella play; shows
            # route to Umbrella's tvshowtitle navigator so the user lands
            # on a per-season episode listing rather than a single play.
            prefix, item_id = _split_prefixed_id(rec.get("id", ""))
            if item_type == "movie":
                params: Dict[str, str] = {"action": "play", "title": rec.get("title", "")}
                if rec.get("year"):
                    params["year"] = str(rec["year"])
                if prefix == "imdb":
                    params["imdb"] = item_id
                elif prefix == "tmdb":
                    params["tmdb"] = item_id
                target = UMBRELLA_PLUGIN_URL + "?" + urlencode(params)
                is_folder = False
            else:
                params = {"action": "seasons", "tvshowtitle": rec.get("title", "")}
                if prefix == "imdb":
                    params["imdb"] = item_id
                elif prefix == "tvdb":
                    params["tvdb"] = item_id
                elif prefix == "tmdb":
                    params["tmdb"] = item_id
                target = UMBRELLA_PLUGIN_URL + "?" + urlencode(params)
                is_folder = True

            # Context menu: remove from favorites without leaving the list.
            if hasattr(item, "addContextMenuItems"):
                try:
                    remove_url = _url({
                        "action": "toggle_favorite",
                        "type": item_type,
                        "id": rec.get("id", ""),
                        "op": "remove",
                    })
                    item.addContextMenuItems([
                        ("Remove from Favorites", "RunPlugin({})".format(remove_url)),
                    ])
                except Exception:
                    pass

            xbmcplugin.addDirectoryItem(HANDLE, target, item, is_folder)
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        xbmc.log("Aegis Favorites list error: {}".format(exc), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)


def _toggle_favorite(query: Optional[Dict[str, str]] = None) -> None:
    """Add/remove a favorite. Used both from the in-plugin Favorites view
    (remove via context menu) and from Umbrella's context menu via a
    RunPlugin URL — Umbrella passes the item's metadata in the query so
    we can build a complete FavoriteRecord without a second lookup.

    Query params:
        type:    "movie" | "show" (required)
        id:      tagged id like "imdb:tt12345" (required)
        op:      "add" | "remove" | "toggle" (default: "toggle")
        title:   for new records (optional but recommended)
        year:    for new records (optional)
        poster:  art URL (optional)
    """
    if library_state is None or VaultStore is None:
        _notify("Favorites unavailable — Vault not loaded.")
        return
    query = query or {}
    item_type = query.get("type", "")
    item_id = query.get("id", "")
    if item_type not in ("movie", "show") or not item_id:
        _notify("Favorites: bad type/id; nothing to do.")
        return
    op = query.get("op", "toggle")
    try:
        vault = VaultStore(_vault_dir())
        payload = vault.read()
        existed = library_state.is_favorite(payload, item_type, item_id)
        if op == "toggle":
            op = "remove" if existed else "add"
        changed = False
        if op == "add" and not existed:
            rec = library_state.make_favorite_record(
                item_type=item_type,
                item_id=item_id,
                title=query.get("title", ""),
                # `str(... or "")` makes the digit check work for the in-plugin
                # call path too — callers there sometimes pass an int via the
                # dict directly, which would AttributeError on `.isdigit()`.
                year=int(query["year"]) if str(query.get("year") or "").isdigit() else None,
                poster=query.get("poster", ""),
            )
            changed = library_state.add_favorite(payload, rec)
            if changed:
                _trakt_push_watchlist(rec)
        elif op == "remove" and existed:
            # Look up the stored record so the Trakt push carries the
            # title/year/poster we saved on add — Umbrella's context-menu
            # remove path doesn't pass those, and Trakt's watchlist remove
            # endpoint dedups against full title+year+ids, not id alone.
            stored = next(
                (
                    r for r in library_state.list_favorites(payload, item_type)
                    if r.get("id") == item_id
                ),
                None,
            )
            rec = stored or {"type": item_type, "id": item_id, "title": query.get("title", "")}
            changed = library_state.remove_favorite(payload, item_type, item_id)
            if changed:
                _trakt_push_watchlist(rec, remove=True)
        if changed:
            vault.write(payload)
        # Toast feedback — context-menu actions are otherwise silent. The
        # "Already a favorite" / "Not in favorites" branches only fire for
        # explicit op=add / op=remove calls (idempotent feedback); a toggle
        # path already resolved op to add-or-remove based on `existed`, so
        # by construction `changed` is True there and the fallback strings
        # are unreachable from toggle invocations.
        xbmcgui.Dialog().notification(
            "Aegis",
            "Added to favorites." if op == "add" and changed else
            "Removed from favorites." if op == "remove" and changed else
            "Already a favorite." if op == "add" else
            "Not in favorites.",
            xbmcgui.NOTIFICATION_INFO,
            2000,
        )
        # Refresh the container so context-menu removes update the visible list.
        try:
            xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
    except Exception as exc:
        xbmc.log("Aegis toggle_favorite error: {}".format(exc), xbmc.LOGERROR)


def _widget_recent_games() -> None:
    """Display Recently Played Games widget."""
    if HANDLE < 0:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Recently Played")
    xbmcplugin.setContent(HANDLE, "addons")
    
    try:
        if VaultStore is None:
            xbmcplugin.endOfDirectory(HANDLE)
            return
        
        vault = VaultStore(_vault_dir())
        payload = vault.read()
        gaming_data = payload.get("gaming", {})
        recent_games = gaming_data.get("recent", [])
        
        # Sort by played_at descending, take last 20
        sorted_games = sorted(recent_games, key=lambda x: x.get("played_at", 0), reverse=True)[:20]
        
        for game in sorted_games:
            label = game.get("label", "Unknown")
            addon_id = game.get("addon_id", "")
            
            item = xbmcgui.ListItem(label=label)
            item.setArt({"thumb": "DefaultFolder.png"})
            url = _url({"action": "play_game", "addon_id": addon_id})
            xbmcplugin.addDirectoryItem(HANDLE, url, item, False)
        
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmc.log("Aegis Recent Games Widget error: {}".format(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)


def _widget_live_tv() -> None:
    """Display Now Playing Live TV widget with current programmes."""
    if HANDLE < 0:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Now Playing")
    xbmcplugin.setContent(HANDLE, "addons")
    
    try:
        import time
        from datetime import datetime, timezone
        # Kodi 21's PVR.GetBroadcasts returns starttime/endtime as ISO 8601
        # strings in UTC (e.g. "2026-05-19 11:00:00"), not epoch ints. Use
        # the same ISO string format for `now` so we can lex-compare cleanly.
        now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        del time  # unused after the switch; keep import in case future code wants it

        # Get channels
        channels_result = rpc("PVR.GetChannels", {"channelgroupid": 1, "properties": ["thumbnail", "uniqueid"]})

        if "error" in channels_result:
            # PVR not available
            xbmcplugin.endOfDirectory(HANDLE)
            return

        channels = channels_result.get("result", {}).get("channels", [])

        for channel in channels:
            channel_id = channel.get("channelid")
            channel_label = channel.get("label", "Unknown")
            channel_thumb = channel.get("thumbnail", "DefaultFolder.png")

            # Get current programme
            broadcasts_result = rpc("PVR.GetBroadcasts", {"channelid": channel_id, "properties": ["title", "starttime", "endtime"]})

            programme_title = "No Programme"
            broadcasts = broadcasts_result.get("result", {}).get("broadcasts", [])
            for broadcast in broadcasts:
                start = broadcast.get("starttime", "")
                end = broadcast.get("endtime", "")
                # All three are ISO 8601 strings; lex order matches time order.
                if start and end and start <= now_iso < end:
                    programme_title = broadcast.get("title", "Unknown")
                    break
            
            # Build label: channel + programme
            label = "{} - {}".format(channel_label, programme_title)
            
            item = xbmcgui.ListItem(label=label)
            item.setArt({"thumb": channel_thumb})
            
            # Build PVR playback URL
            pvr_url = "PlayMedia(pvr://channels/tv/Default%20TV/{}_{}.pvr)".format(channel_id, channel_label.replace(" ", "_"))
            url = _url({"action": "execute_builtin", "builtin": pvr_url})
            
            xbmcplugin.addDirectoryItem(HANDLE, url, item, False)
        
        xbmcplugin.endOfDirectory(HANDLE)
    except Exception as e:
        xbmc.log("Aegis Live TV Widget error: {}".format(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(HANDLE)


def _route_live_tv_channels(query: Optional[Dict[str, str]] = None) -> None:
    query = query or {}
    headless = query.get("headless", "0") == "1"
    out_dir = _tvhub_output_dir()
    m3u_path = out_dir / "merged.m3u"
    epg_path = out_dir / "merged-epg.xml"
    if not (m3u_path.exists() and epg_path.exists()):
        if headless:
            _close_directory_if_needed()
            return
        _notify("Live TV setup is incomplete. Run first-run setup, then Live TV Refresh.")
        return
    if not xbmc.getCondVisibility("System.HasAddon(pvr.iptvsimple)"):
        if headless:
            _close_directory_if_needed()
            return
        _notify("Live TV is not configured yet. Run first-run setup and enable Live TV.")
        return
    if not xbmc.getCondVisibility("PVR.HasTVChannels"):
        if headless:
            _close_directory_if_needed()
            return
        _notify("Live TV: no channels yet. Run Live TV Refresh from Settings.")
        return
    if headless:
        _close_directory_if_needed()
        return
    xbmc.executebuiltin("ActivateWindow(tvchannels)")
    _close_directory_if_needed()


# Channel-name fallback patterns (case-insensitive substring). These catch
# sports channels whose m3u group-title isn't explicitly "Sports" — e.g.
# Pluto sometimes tags an MLB feed under "MLB on Pluto", a Premier League feed
# under "Football", etc. Keep this list conservative; broad sport words like
# "race" or "game" produce too many false positives.
_SPORTS_NAME_KEYWORDS = (
    "espn", "fox sports", "cbs sports", "nbc sports",
    "nfl", "nba", "mlb", "nhl", "mls", "ncaa", "wnba",
    "premier league", "la liga", "bundesliga", "serie a", "ligue 1",
    "champions league", "europa league", "fifa", "uefa",
    "ufc", "boxing", "wwe", "rugby", "cricket",
    "tennis", "golf", "nascar", "formula", "motogp",
    "skysport", "sky sport", "beinsport", "bein sport", "dazn",
    "olympic", "paralympic",
)
_SPORTS_GROUP_KEYWORD = "sport"  # substring match, case-insensitive


def _is_sports_channel(group_title: str, channel_name: str) -> bool:
    """Return True if the EXTINF entry looks like a sports channel.

    Two layers: explicit group-title containing "sport" (catches the Sports /
    Sports - Premier League / Pluto Sports tagging), plus a name-keyword
    fallback for channels whose group label is the league/team rather than
    a generic Sports bucket.
    """
    if _SPORTS_GROUP_KEYWORD in (group_title or "").lower():
        return True
    name_lower = (channel_name or "").lower()
    return any(kw in name_lower for kw in _SPORTS_NAME_KEYWORDS)


def _parse_m3u_sports_entries(m3u_text: str) -> List[Dict[str, Any]]:
    """Parse merged.m3u and return only sports channel entries.

    Each entry is a dict shaped roughly:
        {"name": str, "logo": str, "group": str, "url": str,
         "kodiprops": List[str]}
    The m3u may emit optional #KODIPROP: lines between EXTINF and URL —
    collect those into a kodiprops list so callers can re-apply
    inputstream.adaptive headers when materializing the ListItem.
    """
    import re
    entries: List[Dict[str, Any]] = []
    lines = m3u_text.splitlines()
    i = 0
    extinf_re = re.compile(r'^#EXTINF:-?\d+\s*(?P<attrs>[^,]*),(?P<name>.*)$')
    attr_re = re.compile(r'(?P<key>[A-Za-z0-9_-]+)="(?P<val>[^"]*)"')
    while i < len(lines):
        line = lines[i].strip()
        m = extinf_re.match(line)
        if not m:
            i += 1
            continue
        attrs = {a.group("key"): a.group("val") for a in attr_re.finditer(m.group("attrs"))}
        name = m.group("name").strip()
        group_title = attrs.get("group-title", "")
        # Collect any following KODIPROP lines, then take the next non-prop
        # non-comment line as the stream URL.
        kodiprops: List[str] = []
        url = ""
        j = i + 1
        while j < len(lines):
            nxt = lines[j].strip()
            if nxt.startswith("#KODIPROP:"):
                kodiprops.append(nxt)
                j += 1
                continue
            if nxt.startswith("#") or not nxt:
                j += 1
                continue
            url = nxt
            break
        if url and _is_sports_channel(group_title, name):
            entries.append({
                "name": name,
                "logo": attrs.get("tvg-logo", ""),
                "group": group_title,
                "url": url,
                "kodiprops": kodiprops,
            })
        i = j + 1 if url else i + 1
    return entries


def _route_sports(query: Optional[Dict[str, str]] = None) -> None:
    """Sports tile: filter merged.m3u for sports channels and list them.

    Uses the same merge pipeline that powers Live TV, so coverage scales with
    whatever sources first-run pulled in (FAST providers, iptv-org per-region,
    plus the iptv-org sports.m3u category). Filter logic: group-title contains
    "sport" OR channel name contains a known league/network keyword.
    """
    query = query or {}
    headless = query.get("headless", "0") == "1"
    if HANDLE < 0:
        return
    xbmcplugin.setPluginCategory(HANDLE, "Sports")
    xbmcplugin.setContent(HANDLE, "videos")

    # NB: use Dialog().notification directly here (not _notify) — _notify
    # falls back to _show_home() after the toast, which would render the
    # home menu on top of the Sports directory and is wrong UX for this
    # screen. Users seeing an empty Sports list should stay on it so they
    # can back out normally.
    def _toast(message: str) -> None:
        xbmcgui.Dialog().notification("Aegis", message, xbmcgui.NOTIFICATION_INFO, 3000)

    m3u_path = _tvhub_output_dir() / "merged.m3u"
    if not m3u_path.exists():
        if headless:
            _close_directory_if_needed()
            return
        _toast("Live TV setup is incomplete. Run first-run setup, then revisit Sports.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    try:
        text = m3u_path.read_text(encoding="utf-8", errors="ignore")
    except OSError as exc:
        xbmc.log("Aegis sports: failed reading {}: {}".format(m3u_path, exc), xbmc.LOGERROR)
        if not headless:
            _toast("Couldn't read Live TV playlist; see logs.")
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    entries = _parse_m3u_sports_entries(text)
    if not entries:
        if not headless:
            _toast("No sports channels found. Run Live TV Refresh and try again.")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for entry in entries:
        item = xbmcgui.ListItem(label=entry["name"])
        if entry["logo"]:
            item.setArt({"thumb": entry["logo"], "icon": entry["logo"]})
        item.setInfo("video", {"title": entry["name"], "genre": entry["group"] or "Sports"})
        item.setProperty("IsPlayable", "true")
        # Re-apply the EXTINF #KODIPROP: lines that follow this entry in
        # merged.m3u (inputstream=inputstream.adaptive, manifest_type=hls,
        # manifest_headers / stream_headers UA, etc). Direct-URL sports
        # entries (no plugin:// cascade wrapper) need these or playback
        # fails — Pluto/Samsung edges 403 the default Kodi UA. Cascade URLs
        # (plugin://plugin.video.aegis/?action=tv_play&url=...) carry
        # nothing because tv_play sets headers on the resolved item itself,
        # so a kodiprops list is allowed to be empty.
        for prop_line in entry.get("kodiprops", []):
            payload = prop_line[len("#KODIPROP:"):] if prop_line.startswith("#KODIPROP:") else prop_line
            if "=" not in payload:
                continue
            key, value = payload.split("=", 1)
            item.setProperty(key, value)
        xbmcplugin.addDirectoryItem(HANDLE, entry["url"], item, False)

    xbmcplugin.endOfDirectory(HANDLE)


def _route_music_library(query: Optional[Dict[str, str]] = None) -> None:
    query = query or {}
    if query.get("headless", "0") == "1":
        _close_directory_if_needed()
        return
    xbmc.executebuiltin("ActivateWindow(music)")
    _close_directory_if_needed()


_VAULT_BACKUP_FILENAME = "aegis-vault-backup.abk"


def _route_vault_backup(query: Optional[Dict[str, str]] = None) -> None:
    """Export the vault to a portable, passphrase-encrypted file the user
    chooses the location for. Lets a user survive a vault wipe / move to a new
    device without re-running every OAuth flow."""
    try:
        if VaultStore is None:
            _notify("Vault module unavailable.")
            return
        dialog = xbmcgui.Dialog()
        # Two matching passphrase entries so a typo doesn't produce an
        # un-restorable backup. ALPHANUM keyboard, hidden input.
        pw1 = dialog.input("Backup passphrase", type=xbmcgui.INPUT_ALPHANUM,
                           option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not pw1:
            return  # user cancelled
        pw2 = dialog.input("Confirm passphrase", type=xbmcgui.INPUT_ALPHANUM,
                           option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if pw1 != pw2:
            _notify("Passphrases didn't match — backup cancelled.")
            return
        dest_dir = dialog.browseSingle(3, "Choose backup folder", "files")
        if not dest_dir:
            return
        blob = VaultStore(_vault_dir()).export_backup(pw1)
        dest = dest_dir.rstrip("/\\") + "/" + _VAULT_BACKUP_FILENAME
        f = xbmcvfs.File(dest, "wb")
        try:
            f.write(bytearray(blob))
        finally:
            f.close()
        xbmcgui.Dialog().notification("Aegis", "Vault backed up.",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.log("Aegis: vault backup written to {} ({} bytes)".format(dest, len(blob)),
                 xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log("Aegis: vault backup failed: {}".format(exc), xbmc.LOGERROR)
        _notify("Vault backup failed — see log.")
    finally:
        _close_directory_if_needed()


def _route_vault_restore(query: Optional[Dict[str, str]] = None) -> None:
    """Restore a passphrase-encrypted vault backup, replacing the current
    vault. Guarded by a confirmation because it overwrites debrid/Trakt state."""
    try:
        if VaultStore is None:
            _notify("Vault module unavailable.")
            return
        dialog = xbmcgui.Dialog()
        src = dialog.browseSingle(1, "Select vault backup file", "files",
                                  ".abk")
        if not src:
            return
        if not dialog.yesno("Aegis",
                            "Restoring will REPLACE the current vault "
                            "(debrid/Trakt tokens). Continue?"):
            return
        pw = dialog.input("Backup passphrase", type=xbmcgui.INPUT_ALPHANUM,
                          option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not pw:
            return
        f = xbmcvfs.File(src, "rb")
        try:
            blob = bytes(f.readBytes())
        finally:
            f.close()
        VaultStore(_vault_dir()).import_backup(blob, pw)
        xbmcgui.Dialog().notification("Aegis", "Vault restored.",
                                      xbmcgui.NOTIFICATION_INFO, 4000)
        xbmc.log("Aegis: vault restored from {}".format(src), xbmc.LOGINFO)
        # Re-sync restored debrid creds into Umbrella on next service tick.
        xbmcgui.Window(10000).setProperty("umbrella.updateSettings", "true")
    except Exception as exc:
        # VaultBackupError (wrong passphrase / corrupt) gives a friendly message;
        # anything else is a generic failure.
        if VaultBackupError is not None and isinstance(exc, VaultBackupError):
            _notify(str(exc))
        else:
            xbmc.log("Aegis: vault restore failed: {}".format(exc), xbmc.LOGERROR)
            _notify("Vault restore failed — see log.")
    finally:
        _close_directory_if_needed()


_HEALTH_ADDON_IDS = (
    "plugin.video.aegis",
    "script.module.aegis.vault",
    "script.module.aegis.tvhub",
    "script.module.aegis.netguard",
    "script.module.aegis.proxy",
    "service.aegis.firstrun",
    "script.module.testneto",
    "plugin.video.umbrella",
)


def _addon_version(addon_id: str) -> str:
    try:
        return xbmcaddon.Addon(addon_id).getAddonInfo("version") or "?"
    except Exception:
        return "not installed"


def _testneto_provider_count() -> Optional[int]:
    """Count enabled provider.* toggles in testneto's user settings, or None if
    testneto isn't installed / readable."""
    try:
        if not xbmc.getCondVisibility("System.HasAddon(script.module.testneto)"):
            return None
        p = Path(xbmcvfs.translatePath(
            "special://profile/addon_data/script.module.testneto/settings.xml"))
        if not p.exists():
            return 0
        root = ET.parse(str(p)).getroot()
        n = 0
        for s in root.iter("setting"):
            sid = s.get("id", "")
            if sid.startswith("provider.") and (s.text or "").strip().lower() == "true":
                n += 1
        return n
    except Exception:
        return None


def _gather_health_lines() -> List[str]:
    """Assemble the Aegis Health report — everything that otherwise needs an
    ADB/log dive: vault + token state, proxy, live-TV refresh, scraper count,
    addon versions."""
    lines: List[str] = []

    # --- Vault + tokens ---
    lines.append("[B]Vault & providers[/B]")
    vault_data: Dict[str, Any] = {}
    if VaultStore is None:
        lines.append("  Vault module: [COLOR red]unavailable[/COLOR]")
    else:
        try:
            vault_data = VaultStore(_vault_dir()).read()
            lines.append("  Vault: [COLOR lightgreen]readable[/COLOR]")
        except Exception as exc:
            lines.append("  Vault: [COLOR red]unreadable ({})[/COLOR]".format(exc))

    rd = vault_data.get("rd", {}) if isinstance(vault_data, dict) else {}
    if rd.get("refresh_token") or rd.get("access_token"):
        # A restored/foreign/hand-edited vault could carry a non-numeric
        # expires_at (e.g. an ISO string). Never let that fail the whole
        # report — the health screen's contract is "always renders".
        try:
            exp = int(rd.get("expires_at", 0) or 0)
        except (TypeError, ValueError):
            exp = 0
        if exp:
            when = time.strftime("%Y-%m-%d %H:%M", time.localtime(exp))
            remaining = exp - int(time.time())
            status = "expires {}".format(when) if remaining > 0 else "[COLOR red]expired {}[/COLOR]".format(when)
            lines.append("  Real-Debrid: linked (access token {})".format(status))
        else:
            lines.append("  Real-Debrid: linked")
    else:
        lines.append("  Real-Debrid: [COLOR yellow]not linked[/COLOR]")
    lines.append("  AllDebrid: {}".format(
        "linked" if (vault_data.get("ad", {}) or {}).get("apikey") else "not linked"))
    lines.append("  Trakt: {}".format(
        "linked" if (vault_data.get("trakt", {}) or {}).get("access_token") else "not linked"))

    # --- Scraper ---
    count = _testneto_provider_count()
    if count is None:
        lines.append("  Scraper (testneto): [COLOR yellow]not installed[/COLOR]")
    else:
        colour = "lightgreen" if count > 0 else "red"
        lines.append("  Scraper (testneto): [COLOR {}]{} providers enabled[/COLOR]".format(colour, count))

    # --- Live TV proxy + refresh ---
    lines.append("")
    lines.append("[B]Live TV[/B]")
    port = xbmcgui.Window(10000).getProperty("aegis_proxy_port")
    if port:
        lines.append("  HLS proxy: [COLOR lightgreen]running on 127.0.0.1:{}[/COLOR]".format(port))
    else:
        lines.append("  HLS proxy: [COLOR yellow]not running[/COLOR] (routing direct to ffmpegdirect)")
    live = vault_data.get("live_tv", {}) if isinstance(vault_data, dict) else {}
    ts = int(live.get("last_refresh_at", 0) or 0)
    if ts > 0:
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))
        res = live.get("last_refresh_result", {}) or {}
        lines.append("  Last refresh: {} ({} channels, dedup {}, {} errors)".format(
            when, res.get("total_channels", "?"), res.get("dedup_count", "?"),
            res.get("error_count", "?")))
    else:
        lines.append("  Last refresh: never")

    # --- Security ---
    lines.append("")
    lines.append("[B]Security[/B]")
    lines.append("  Network: HTTPS-only (netguard) ✓")
    lines.append("  Telemetry: none")

    # --- Versions ---
    lines.append("")
    lines.append("[B]Addon versions[/B]")
    for aid in _HEALTH_ADDON_IDS:
        lines.append("  {}: {}".format(aid, _addon_version(aid)))

    return lines


def _route_health(query: Optional[Dict[str, str]] = None) -> None:
    """Render the Aegis Health diagnostics report in a textviewer. Skin-agnostic
    (works on any skin), so users never need ADB/log access to see vault, proxy,
    refresh, scraper, and version state at a glance."""
    try:
        text = "\n".join(_gather_health_lines())
        xbmcgui.Dialog().textviewer("Aegis Health", text)
    except Exception as exc:
        xbmc.log("Aegis: health report failed: {}".format(exc), xbmc.LOGERROR)
        _notify("Health report failed — see log.")
    finally:
        _close_directory_if_needed()


def _route_addon_settings(query: Optional[Dict[str, str]] = None) -> None:
    query = query or {}
    if query.get("headless", "0") == "1":
        _close_directory_if_needed()
        return
    xbmc.executebuiltin("Addon.OpenSettings(plugin.video.aegis)")
    # Action-only route: tell Kodi we did not render a directory so it does NOT
    # push a blank navigation tab behind the addon-settings dialog. Without this,
    # clicking the Settings tile / Aegis Settings entry leaves the user on an
    # empty Videos window once they close the dialog.
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False, cacheToDisc=False)


def _format_last_refresh_status() -> str:
    """Return a one-line summary of the most recent refresh for the menu.

    Reads `live_tv.last_refresh_at` (unix seconds) + `live_tv.last_refresh_result`
    from the vault and renders e.g. "Last refresh: 2026-06-05 22:44 - 2929 channels,
    12000 EPG programmes (dedup=2598)". Returns "Last refresh: never" if no
    refresh has been recorded.

    This is the visible counterpart to the existing log line — the user can
    see in the menu that the refresh actually ran instead of having to grep
    kodi.log. Wrapped in a broad except so a malformed vault entry can't
    take down the menu (worst case is "Last refresh: unknown").
    """
    try:
        vault = VaultStore(_vault_dir())
        snapshot = vault.read()
        live_tv_data = snapshot.get("live_tv", {}) or {}
        ts = int(live_tv_data.get("last_refresh_at", 0) or 0)
        if ts <= 0:
            return "Last refresh: never"
        # Local time matches the user's wall-clock view of the log
        # timestamps in kodi.log, so they can correlate at a glance.
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(ts))
        result = live_tv_data.get("last_refresh_result", {}) or {}
        channels = result.get("total_channels", "?")
        dedup = result.get("dedup_count", "?")
        # `epg_programmes` isn't in the recorded result dict today —
        # surface what we have, fall back gracefully if a field is missing.
        return "Last refresh: {} - {} channels, dedup={}".format(when, channels, dedup)
    except Exception as exc:
        xbmc.log(
            "Aegis Live-TV: failed reading last_refresh_at for menu: {}".format(exc),
            xbmc.LOGWARNING,
        )
        return "Last refresh: unknown"


def _show_live_tv_refresh():
    """Show live-TV refresh menu with staging diff and apply option.

    Always reports `endOfDirectory(succeeded=True)` so Kodi's post-apply
    container redraw doesn't pop a `CGUIMediaWindow::GetDirectory ... failed`
    error toast when the underlying menu state momentarily looks empty.
    The previous code returned without endOfDirectory on the HANDLE<0 path
    (correct for non-directory invocations) but any unexpected exception
    after `setPluginCategory` would also leave Kodi waiting forever and
    eventually mark the directory call failed — that's what the user saw
    after `tv_refresh_apply` navigated home and Kodi tried to redraw the
    original `live_tv_refresh` URL.
    """
    if HANDLE < 0:
        return
    try:
        xbmcplugin.setPluginCategory(HANDLE, "Live-TV Refresh")
        xbmcplugin.setContent(HANDLE, "addons")

        _add_header_item("Live-TV Channel Refresh")
        _add_header_item(_format_last_refresh_status())
        _add_item("Refresh Now", "tv_refresh_apply")
    except Exception as exc:
        xbmc.log(
            "Aegis Live-TV: _show_live_tv_refresh body failed: {}".format(exc),
            xbmc.LOGWARNING,
        )
    finally:
        # Always end the directory with succeeded=True. Reporting failure
        # here only makes Kodi log a confusing error AND pop a "failed to
        # get directory" dialog — the user gets no recovery path from
        # that. A succeeded=True with an empty (or partially-built) list
        # at least shows the menu skeleton so the user can navigate away
        # or retry.
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)


def _close_directory_if_needed() -> None:
    if HANDLE >= 0:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)


def _tvhub_output_dir() -> Path:
    return Path(xbmcvfs.translatePath("special://profile/addon_data/script.module.aegis.tvhub/"))


def _normalize_legacy_estuary_settings() -> None:
    settings_path = Path(xbmcvfs.translatePath("special://profile/addon_data/skin.estuary/settings.xml"))
    if not settings_path.exists():
        return
    try:
        content = settings_path.read_text(encoding="utf-8")
    except Exception:
        return
    if 'type="bool"' not in content:
        return
    try:
        settings_path.write_text(content.replace('type="bool"', 'type="boolean"'), encoding="utf-8")
        xbmc.log("Aegis: normalized legacy skin.estuary settings types", xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log("Aegis: failed to normalize skin.estuary settings: {}".format(exc), xbmc.LOGWARNING)


def _pvr_iptvsimple_settings_ids() -> Optional[Dict[str, str]]:
    expected_keys = [
        "m3uPathType",
        "m3uPath",
        "epgPathType",
        "epgPath",
        "m3uRefreshMode",
    ]
    settings_xml = Path(
        xbmcvfs.translatePath("special://home/addons/pvr.iptvsimple/resources/settings.xml")
    )
    if not settings_xml.exists():
        xbmc.log("Aegis Live-TV: pvr.iptvsimple settings.xml not found", xbmc.LOGWARNING)
        return None

    try:
        root = ET.parse(str(settings_xml)).getroot()
        ids = {}
        for node in root.findall(".//setting"):
            setting_id = node.get("id", "")
            if setting_id in expected_keys:
                ids[setting_id] = setting_id
        for key in expected_keys:
            if key not in ids:
                xbmc.log("Aegis Live-TV: expected pvr.iptvsimple setting id missing: {}".format(key), xbmc.LOGWARNING)
                return None
    except Exception as exc:
        xbmc.log("Aegis Live-TV: failed parsing pvr.iptvsimple settings.xml: {}".format(exc), xbmc.LOGWARNING)
        return None

    return ids


def _ensure_kodi_addon_installed(addon_id: str, timeout_seconds: int = 60) -> bool:
    """Install a Kodi addon from the official repo if not already present.

    Mirrors `service.aegis.firstrun.service._ensure_kodi_addon_installed` —
    used here so the plugin's own manual-refresh path installs the same
    inputstream dependencies the service installs at first run.
    """
    cond = "System.HasAddon({})".format(addon_id)
    if xbmc.getCondVisibility(cond):
        return True
    xbmc.executebuiltin("InstallAddon({})".format(addon_id))
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if xbmc.getCondVisibility(cond):
            return True
        xbmc.sleep(1000)
    return False


def _ensure_pvr_iptvsimple_installed(timeout_seconds: int = 60) -> Tuple[bool, str]:
    """Install pvr.iptvsimple AND its required inputstream dependencies.

    pvr.iptvsimple's addon.xml declares inputstream.ffmpegdirect and
    inputstream.rtmp as required, but Kodi's InstallAddon RPC does NOT
    pull required dependencies automatically in Omega/21.3 — leaving the
    user with a partially-installed PVR client that warns at every
    startup and then crashes during background PVR work (see the
    matching helper in service.aegis.firstrun for the dump details).

    Deps are treated as REQUIRED. Installing pvr.iptvsimple alongside
    a missing dep recreates the crash-prone state this function exists
    to avoid, so a dep timeout fails the whole installer. The caller's
    manual-refresh path then surfaces a clear "couldn't install" toast
    rather than configuring iptvsimple into the silent-crash state.
    """
    for dep_id in ("inputstream.ffmpegdirect", "inputstream.rtmp"):
        if not _ensure_kodi_addon_installed(dep_id, timeout_seconds=timeout_seconds):
            return False, (
                "required inputstream dep {} did not install — skipping "
                "pvr.iptvsimple to avoid the missing-dep crash mode".format(dep_id)
            )

    if not _ensure_kodi_addon_installed("pvr.iptvsimple", timeout_seconds=timeout_seconds):
        return False, "pvr.iptvsimple install timed out"

    return True, "pvr.iptvsimple installed (with inputstream deps)"


def _configure_pvr_from_tvhub_outputs() -> Tuple[bool, str]:
    out_dir = _tvhub_output_dir()
    m3u_path = out_dir / "merged.m3u"
    epg_path = out_dir / "merged-epg.xml"
    xbmc.log("Aegis L8: checking outputs: m3u={}, epg={}".format(m3u_path.exists(), epg_path.exists()), xbmc.LOGINFO)
    if m3u_path.exists():
        xbmc.log("Aegis L8: m3u file exists at {}".format(m3u_path), xbmc.LOGINFO)
    if epg_path.exists():
        xbmc.log("Aegis L8: epg file exists at {}".format(epg_path), xbmc.LOGINFO)
    
    if not (m3u_path.exists() and epg_path.exists()):
        xbmc.log("Aegis Live-TV: merged outputs missing; expected {} and {}".format(m3u_path, epg_path), xbmc.LOGWARNING)
        return False, "merged outputs missing ({}, {})".format(m3u_path, epg_path)

    xbmc.log("Aegis L8: ensuring pvr.iptvsimple installed", xbmc.LOGINFO)
    installed, install_reason = _ensure_pvr_iptvsimple_installed()
    if not installed:
        xbmc.log("Aegis Live-TV: {}".format(install_reason), xbmc.LOGWARNING)
        return False, install_reason
    xbmc.log("Aegis L8: pvr.iptvsimple confirmed installed", xbmc.LOGINFO)

    xbmc.log("Aegis L8: resolving pvr.iptvsimple setting IDs", xbmc.LOGINFO)
    ids = _pvr_iptvsimple_settings_ids()
    if not ids:
        xbmc.log("Aegis Live-TV: could not resolve pvr.iptvsimple setting IDs", xbmc.LOGWARNING)
        return False, "could not resolve pvr.iptvsimple setting IDs"
    xbmc.log("Aegis L8: resolved setting IDs: {}".format(ids), xbmc.LOGINFO)

    xbmc.log("Aegis L8: applying pvr.iptvsimple settings via addon API", xbmc.LOGINFO)
    pvr = None
    deadline = time.time() + 45
    while time.time() < deadline:
        try:
            pvr = xbmcaddon.Addon("pvr.iptvsimple")
            break
        except Exception:
            xbmc.sleep(500)
    if pvr is None:
        xbmc.log("Aegis L8: could not obtain pvr.iptvsimple addon handle", xbmc.LOGWARNING)
        return False, "could not open pvr.iptvsimple addon settings"

    try:
        pvr.setSetting(ids["m3uPathType"], "0")
        pvr.setSetting(ids["m3uPath"], str(m3u_path))
        pvr.setSetting(ids["epgPathType"], "0")
        pvr.setSetting(ids["epgPath"], str(epg_path))
        pvr.setSetting(ids["m3uRefreshMode"], "0")
    except Exception as exc:
        xbmc.log("Aegis L8: failed to set pvr.iptvsimple settings via addon API: {}".format(exc), xbmc.LOGWARNING)
        return False, "failed to configure pvr.iptvsimple settings"

    def _patch_settings_file(path_obj: Path) -> bool:
        if not path_obj.exists():
            return True
        try:
            tree = ET.parse(str(path_obj))
            root = tree.getroot()
            updates = {
                ids["m3uPathType"]: "0",
                ids["m3uPath"]: str(m3u_path),
                ids["epgPathType"]: "0",
                ids["epgPath"]: str(epg_path),
                ids["m3uRefreshMode"]: "0",
            }
            for key, value in updates.items():
                node = root.find(".//setting[@id='{}']".format(key))
                if node is None:
                    continue
                node.text = value
            tree.write(str(path_obj), encoding="utf-8", xml_declaration=False)
            return True
        except Exception as exc:
            xbmc.log("Aegis L8: failed to patch {}: {}".format(path_obj, exc), xbmc.LOGWARNING)
            return False

    addon_data_dir = Path(xbmcvfs.translatePath("special://profile/addon_data/pvr.iptvsimple"))
    if not _patch_settings_file(addon_data_dir / "settings.xml"):
        return False, "failed to patch pvr.iptvsimple settings.xml"
    if not _patch_settings_file(addon_data_dir / "instance-settings-1.xml"):
        return False, "failed to patch pvr.iptvsimple instance settings"

    # PVR.GetChannels stayed at -32100 until the client was re-enabled after settings changed; this forces IPTV Simple to reload the merged M3U/EPG.
    disable_payload = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": "pvr.iptvsimple", "enabled": False},
    })))
    if disable_payload.get("error"):
        xbmc.log("Aegis L8: failed to disable pvr.iptvsimple for reload: {}".format(disable_payload.get("error")), xbmc.LOGWARNING)
        return False, "failed to disable pvr.iptvsimple for reload"
    xbmc.sleep(1000)
    enable_payload = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": "pvr.iptvsimple", "enabled": True},
    })))
    if enable_payload.get("error"):
        xbmc.log("Aegis L8: failed to re-enable pvr.iptvsimple for reload: {}".format(enable_payload.get("error")), xbmc.LOGWARNING)
        return False, "failed to enable pvr.iptvsimple after refresh"
    xbmc.sleep(2000)

    xbmc.log("Aegis L8: stopping PVR manager", xbmc.LOGINFO)
    xbmc.executebuiltin("StopPVRManager")
    xbmc.sleep(1000)
    xbmc.log("Aegis L8: starting PVR manager", xbmc.LOGINFO)
    xbmc.executebuiltin("StartPVRManager")
    xbmc.log("Aegis L8: PVR manager restart complete", xbmc.LOGINFO)
    return True, "ok"


def _run_tvhub_merge() -> Tuple[bool, str]:
    """Re-fetch upstream m3u/EPG sources and write merged.m3u +
    merged-epg.xml. Returns (success, reason_or_summary). Importing
    tvhub here (instead of at module load) keeps the plugin usable on
    profiles where tvhub hasn't installed yet — the live-tv menus
    surface a helpful error rather than crashing the addon."""
    try:
        from script.module.aegis.tvhub.lib.merge import merge as _merge  # type: ignore  # noqa: E501
        from script.module.aegis.tvhub.lib.sources import SourceRegistry  # type: ignore
    except ImportError:
        # Kodi ships the script.module addon under a separate sys.path
        # entry; the dotted import above won't resolve unless that entry
        # is already wired in. Resolve the addon's lib/ path explicitly
        # via xbmcaddon.Addon(<id>).getAddonInfo('path'), insert it at the
        # front of sys.path, and import via the `lib.` prefix so we can't
        # accidentally bind to another `sources` or `merge` module that
        # happens to be earlier on the path.
        try:
            import sys
            import importlib
            try:
                tvhub_addon = xbmcaddon.Addon("script.module.aegis.tvhub")
                tvhub_root = xbmcvfs.translatePath(tvhub_addon.getAddonInfo("path"))
            except Exception as exc:
                return False, "tvhub addon not installed: {}".format(exc)
            if tvhub_root not in sys.path:
                sys.path.insert(0, tvhub_root)
            merge_mod = importlib.import_module("lib.merge")
            sources_mod = importlib.import_module("lib.sources")
            SourceRegistry = sources_mod.SourceRegistry  # type: ignore
            _merge = merge_mod.merge  # type: ignore
        except Exception as exc:
            return False, "tvhub modules unavailable: {}".format(exc)

    try:
        from aegis_netguard import GuardedSession  # type: ignore
        from aegis_vault import VaultStore  # type: ignore
    except ImportError as exc:
        return False, "aegis modules unavailable: {}".format(exc)

    vault_dir = xbmcvfs.translatePath("special://masterprofile/aegis")
    vault = VaultStore(vault_dir)
    registry = SourceRegistry(vault)
    if not registry.get_enabled():
        return False, "no live-TV sources enabled — run first-run setup"

    out_dir = _tvhub_output_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    session = GuardedSession()
    result = _merge(registry, out_dir, session)
    # MergeResult exposes total_channels (post-dedup m3u count) and
    # epg_programmes (count surviving the orphan + window filters). The
    # dedup_count gives an at-a-glance signal that cross-source merging
    # actually did something.
    summary = "{} channels, {} EPG programmes (dedup={})".format(
        getattr(result, "total_channels", "?"),
        getattr(result, "epg_programmes", "?"),
        getattr(result, "dedup_count", "?"),
    )
    xbmc.log("Aegis Live-TV: manual refresh merge complete: {}".format(summary), xbmc.LOGINFO)

    # Record last_refresh_at so the firstrun service's periodic ticker
    # treats this manual refresh as a real refresh. Without this, a
    # user who hits "Refresh Now" while the stored timestamp is stale
    # would get a second full upstream merge from the ticker on its
    # next ~30-min wake — same data, twice the bandwidth.
    try:
        snapshot = vault.read()
        live_tv_data = snapshot.setdefault("live_tv", {})
        live_tv_data["last_refresh_at"] = int(time.time())
        live_tv_data["last_refresh_result"] = {
            "total_channels": getattr(result, "total_channels", 0),
            "dedup_count": getattr(result, "dedup_count", 0),
            "error_count": len(getattr(result, "errors", []) or []),
        }
        vault.write(snapshot)
    except Exception as exc:
        xbmc.log(
            "Aegis Live-TV: failed recording manual last_refresh_at: {}".format(exc),
            xbmc.LOGWARNING,
        )

    return True, summary


def _apply_live_tv_refresh(query=None):
    """Apply live-TV refresh: re-fetch upstream sources, regenerate the
    merged m3u/EPG files, then reconfigure pvr.iptvsimple to point at them.

    The previous version only reconfigured pvr.iptvsimple — it did NOT
    re-fetch, so users hitting "Refresh Now" got an empty no-op while
    their EPG silently decayed. The scheduled refresh path in
    service.aegis.firstrun runs the merge, and now this UI path does too.
    """
    try:
        query = query or {}
        dialog = xbmcgui.Dialog()
        headless = query.get("headless", "0") == "1"

        # Show staging info
        staging_text = """
Preparing to refresh Live-TV sources...

This will:
• Fetch latest m3u lists from configured regions
• Deduplicate and parse channel data
• Generate updated merged.m3u + merged-epg.xml

Current sources:
• iptv-org regions
• Custom sources (if added)
• Famelack (if enabled)
        """.strip()

        if not headless:
            if not dialog.yesno(
                "Live-TV Refresh",
                staging_text + "\n\nApply refresh now?",
                yeslabel="Refresh",
                nolabel="Cancel"
            ):
                _notify("Refresh cancelled.")
                return

        # Re-fetch upstream sources before reconfiguring iptvsimple, so
        # the addon actually points at fresh data. The DialogProgress is
        # cosmetic — wrap it so an environment without one (e.g., test
        # mocks that only stub xbmcgui.Dialog) doesn't break the flow.
        progress = None
        if not headless:
            try:
                progress = xbmcgui.DialogProgress()
                progress.create("Aegis Live-TV", "Fetching sources, merging channels + EPG…")
            except Exception:
                progress = None
        merged, merge_reason = _run_tvhub_merge()
        if progress:
            try:
                progress.close()
            except Exception:
                pass

        # Emit the route-called marker before any early return so the
        # kodi_harness "live_tv_refresh_logged" check can confirm the action
        # was wired and the route ran — even if the merge bailed out (e.g.,
        # no sources enabled yet in a fresh CI profile).
        applied = False
        reason = ""
        if merged:
            applied, reason = _configure_pvr_from_tvhub_outputs()
        # `merged` is a real bool so the harness/logs can grep the truth value;
        # `reason` is the PVR-config outcome on success, falling back to
        # `merge_reason` (why the merge failed) so we always log something useful.
        xbmc.log("L8: tv_refresh_apply route called headless={} merged={} applied={} reason={}".format(
            headless, merged, applied, reason or merge_reason), xbmc.LOGINFO)

        if not merged:
            if not headless:
                xbmcgui.Dialog().notification(
                    "Aegis",
                    "Live-TV refresh: {}".format(merge_reason),
                    xbmcgui.NOTIFICATION_WARNING, 5000,
                )
                _show_home()
            else:
                _close_directory_if_needed()
            return

        if headless:
            _close_directory_if_needed()
            return

        if applied:
            xbmcgui.Dialog().notification(
                "Aegis",
                "Live-TV refresh applied ({}).".format(merge_reason),
                xbmcgui.NOTIFICATION_INFO, 3000,
            )
        else:
            if "merged outputs missing" in reason:
                xbmcgui.Dialog().notification(
                    "Aegis",
                    "Live-TV setup incomplete. Run first-run setup to generate channel outputs.",
                    xbmcgui.NOTIFICATION_WARNING,
                    5000,
                )
            elif "inputstream" in reason:
                # Match the dep-timeout reason BEFORE the generic
                # pvr.iptvsimple branch — that reason string contains
                # "pvr.iptvsimple" too (it explains we skipped the parent
                # install) so the generic branch would otherwise win the
                # match and hide the real cause.
                xbmcgui.Dialog().notification(
                    "Aegis",
                    "Live-TV refresh skipped: missing inputstream dep — "
                    "install from Kodi repository then retry.",
                    xbmcgui.NOTIFICATION_WARNING,
                    5000,
                )
            elif "pvr.iptvsimple" in reason:
                xbmcgui.Dialog().notification(
                    "Aegis",
                    "Live-TV refresh requires PVR IPTV Simple Client (pvr.iptvsimple).",
                    xbmcgui.NOTIFICATION_WARNING,
                    5000,
                )
            else:
                xbmcgui.Dialog().notification("Aegis", "Live-TV refresh failed: {}".format(reason), xbmcgui.NOTIFICATION_WARNING, 5000)
        _show_home()
    except Exception as exc:
        xbmc.log(f"Error in live_tv_refresh: {exc}", xbmc.LOGERROR)
        if query.get("headless", "0") == "1":
            _close_directory_if_needed()
            return
        xbmcgui.Dialog().notification("Aegis", "Refresh failed - see logs", xbmcgui.NOTIFICATION_ERROR, 3000)
        _show_home()


# --------------------------------------------------------------------------
# FAST CDN per-provider HTTP headers
# --------------------------------------------------------------------------
# Different FAST CDNs gate playback on different User-Agent / Origin / Referer
# combinations:
# - Pluto TV uses a Chrome UA but also requires pluto.tv Origin/Referer —
#   without them the stitcher serves a "We'll be right back" filler loop.
# - Samsung TV+'s segment edge (cloudfront) 403s a generic Chrome UA;
#   Samsung's Tizen TV UA + samsungtvplus.com Origin/Referer passes the gate.
# - Plex Live auths via X-Plex-Token but some endpoints reject without
#   an app.plex.tv Origin.
# - Tubi wants tubitv.com Origin/Referer to look like the official app.
# - iptv-org direct streams are mixed; default Chrome UA with no extras
#   is the safest default for "unknown".
#
# These constants live next to _route_tv_play because changes to header
# semantics often ride alongside changes to the cascade-resolve flow.

_PROVIDER_UA = {
    "samsung": (
        "Mozilla/5.0 (SMART-TV; LINUX; Tizen 5.0) AppleWebKit/537.36 "
        "(KHTML, like Gecko) 73.0.3683.103 SamsungBrowser/9.1 LFD Safari/537.36"
    ),
    # Default desktop Chrome — used by Pluto, Tubi, Plex, and unknown providers.
    "default": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
}

_PROVIDER_EXTRA_HEADERS: Dict[str, Dict[str, str]] = {
    # Mirror of script.module.aegis.tvhub.lib.stream_headers — see that
    # module for why each provider needs specific Origin/Referer.
    "pluto": {
        "Origin": "https://pluto.tv",
        "Referer": "https://pluto.tv/",
    },
    "samsung": {
        "Origin": "https://www.samsungtvplus.com",
        "Referer": "https://www.samsungtvplus.com/",
    },
    "plex": {
        "Origin": "https://app.plex.tv",
        "Referer": "https://app.plex.tv/",
    },
    "tubi": {
        "Origin": "https://tubitv.com",
        "Referer": "https://tubitv.com/",
    },
    # Roku Channel FAST — mirrors the canonical tvhub copy; see
    # stream_headers.py for the live-capture reasoning.
    "roku": {
        "Origin": "https://therokuchannel.roku.com",
        "Referer": "https://therokuchannel.roku.com/",
    },
}


def _is_pluto_stitcher_url(url: str) -> bool:
    """Mirror of script.module.aegis.tvhub.lib.stream_headers._is_pluto_stitcher_url.

    Uses `urlparse` so the hostname is extracted structurally and
    can't be spoofed by an attacker putting `pluto.tv/v1/stitch/`
    somewhere in the URL path. Must stay in lock-step with the
    tvhub copy (verified by tests/test_stream_headers.py mirror-sync
    checks).
    """
    # Strict type gate: `urlparse` raises `TypeError`/`AttributeError`
    # on non-str inputs (None, bytes, int, etc.) — defensive allow-list
    # gates must reject anything non-str upfront so a bad input can't
    # crash the cascade resolver. Mirrors the tvhub copy.
    if not isinstance(url, str) or not url:
        return False
    try:
        parsed = urlparse(url)
    except (ValueError, TypeError):
        return False
    if parsed.scheme not in ("http", "https"):
        return False
    host = (parsed.hostname or "").lower()
    if not (host == "pluto.tv" or host.endswith(".pluto.tv")):
        return False
    return parsed.path.lower().startswith("/v1/stitch/")


def _classify_stream(url: str) -> str:
    """Classify a stream URL into a provider key for header selection.

    Used to choose Samsung-Tizen UA vs. desktop Chrome UA and to pick the
    right Origin / Referer header set. Returns one of:
    "pluto", "samsung", "plex", "tubi", "unknown".

    Both jmp2.uk/plex- (the redirector form used by FAST aggregation and our
    tvhub dedup output) and the direct provider.plex.tv host get classified
    as "plex". Must stay in lock-step with
    script.module.aegis.tvhub.lib.stream_headers.classify_stream (verified
    by tests/test_stream_headers.py mirror-sync checks).
    """
    # Defensive: caller may pass non-str (None from missing settings,
    # bytes from a decode-forgot, etc.). Treat anything non-str as
    # unclassifiable so `.lower()` / `in` don't raise.
    if not isinstance(url, str) or not url:
        return "unknown"
    lowered = url.lower()
    # Match the jmp2.uk `plu-` redirector form AND the direct stitcher
    # URL (`stitcher-ipv4.pluto.tv/v1/stitch/...`) the tvhub adapter
    # rewrites to once jmp2.uk's plu- route started returning 404.
    # Pluto stitcher uses real `urlparse` host+path checks (see
    # `_is_pluto_stitcher_url`) so attacker-controlled URLs that embed
    # `pluto.tv/v1/stitch/` in the path (e.g.
    # `https://attacker.example/.pluto.tv/v1/stitch/...`) can't sneak
    # past — substring checks alone could be evaded.
    if "jmp2.uk/plu-" in lowered or _is_pluto_stitcher_url(url):
        return "pluto"
    if "jmp2.uk/stvp-" in lowered:
        return "samsung"
    if "jmp2.uk/plex-" in lowered or "provider.plex.tv" in lowered:
        return "plex"
    if "tubi.io" in lowered or "tubitv.com" in lowered:
        return "tubi"
    # Roku Channel FAST via the jmp2.uk `rok-` redirector form. Mirror
    # of tvhub.lib.stream_headers.classify_stream.
    if "jmp2.uk/rok-" in lowered:
        return "roku"
    return "unknown"


def _headers_for_url(url: str) -> Dict[str, str]:
    """Return the {header_name: header_value} dict to send for `url`.

    Pure Python dict (NOT URL-encoded). _kodi_header_string() handles the
    inputstream.adaptive on-the-wire format separately.
    """
    provider = _classify_stream(url)
    ua = _PROVIDER_UA.get(provider, _PROVIDER_UA["default"])
    headers: Dict[str, str] = {"User-Agent": ua}
    headers.update(_PROVIDER_EXTRA_HEADERS.get(provider, {}))
    return headers


# Mirror of script.module.aegis.tvhub.lib.stream_headers._FFMPEG_RECONNECT_OPTS
# — ffmpeg AVDictionary options (not HTTP headers) that ride along the
# pipe-tail for ffmpegdirect-routed URLs. See the tvhub copy for the
# full reasoning. Must stay in lock-step (verified by
# tests/test_stream_headers.py mirror-sync checks).
_FFMPEG_RECONNECT_OPTS: Dict[str, str] = {
    "reconnect": "1",
    "reconnect_streamed": "1",
    "reconnect_delay_max": "1",
}


def _ffmpegdirect_pipe_options(url: str) -> Dict[str, str]:
    """Mirror of script.module.aegis.tvhub.lib.stream_headers.ffmpegdirect_pipe_options.

    Returns ffmpeg AVDictionary options to merge into the pipe-tail when
    `url` is routed through inputstream.ffmpegdirect. Provider-agnostic
    today (Samsung is the only ffmpegdirect-routed provider) but per-URL
    so future providers can override.
    """
    return dict(_FFMPEG_RECONNECT_OPTS)


# Window property the proxy service publishes when it's running.
# Empty string means proxy isn't available — routing falls back to
# passing the upstream URL straight to ffmpegdirect.
_AEGIS_PROXY_PORT_WINDOW_PROP = "aegis_proxy_port"


def _aegis_proxy_url(upstream_url: str, headers: Dict[str, str]) -> Optional[str]:
    """Return a `http://127.0.0.1:PORT/p?u=...&h=...` URL that routes
    `upstream_url` through the local Aegis HLS proxy with `headers`
    applied on the upstream fetch. Returns None when the proxy isn't
    running (Window property unset / unreadable) so the caller can
    fall back to the direct URL.

    The proxy strips `EXT-X-DISCONTINUITY` and SCTE-35 hint tags from
    HLS manifests before ffmpegdirect sees them, eliminating the
    per-discontinuity decoder re-init stutter on Samsung TV+ / Roku /
    Plex Live.

    Headers are JSON-then-base64-encoded into the `h` query param —
    same scheme `lib/server.py::encode_proxy_target` uses on the
    proxy side. Kept inline here (rather than importing the proxy
    addon's helper) because the plugin doesn't have the proxy module
    on its sys.path and a runtime cross-addon import would add a
    failure mode for a small helper.
    """
    try:
        port_str = xbmcgui.Window(10000).getProperty(_AEGIS_PROXY_PORT_WINDOW_PROP)
    except Exception:
        return None
    if not port_str or not port_str.isdigit():
        return None
    import base64
    import json
    def _b64url(data: bytes) -> str:
        return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")
    parts = ["u=" + _b64url(upstream_url.encode("utf-8"))]
    if headers:
        parts.append("h=" + _b64url(json.dumps(headers, separators=(",", ":")).encode("utf-8")))
    return "http://127.0.0.1:{}/p?{}".format(port_str, "&".join(parts))


def _kodi_header_string(headers: Dict[str, str]) -> str:
    """Format header dict for inputstream.adaptive.{manifest,stream}_headers.

    inputstream.adaptive expects `Key=Value&Key2=Value2` with URL-encoded
    values. Keys are not encoded (header names never contain reserved chars).
    """
    from urllib.parse import quote
    return "&".join("{}={}".format(k, quote(v, safe="")) for k, v in headers.items())


def _kodi_pipe_header_url(url: str, headers: Dict[str, str]) -> str:
    """Mirror of script.module.aegis.tvhub.lib.stream_headers.kodi_pipe_header_url.

    Append HTTP headers to a URL using Kodi's pipe-separator syntax —
    ffmpegdirect picks them up via Kodi's CurlFile on both manifest
    and segment fetches. If the URL already carries a pipe tail
    (decorated by an upstream layer), merge new headers into the
    existing tail rather than appending a second `|` — CurlFile only
    parses the first segment, so a `url|...|...` shape silently drops
    the second header set.

    New keys win on conflict: the explicit `headers` argument is the
    caller's "current intent" and overrides whatever was baked in.
    Values in the existing tail are URL-decoded before re-encoding so
    a repeated apply doesn't double-encode.

    Returns `url` unchanged when `headers` is empty so callers can
    stay single-path. Must stay in lock-step with the tvhub copy
    (mirror sync coverage: tests/test_stream_headers.py).
    """
    if not headers:
        return url
    from urllib.parse import unquote
    base, sep, existing_tail = url.partition("|")
    if not sep:
        return "{}|{}".format(base, _kodi_header_string(headers))
    merged: Dict[str, str] = {}
    for chunk in existing_tail.split("&"):
        if not chunk or "=" not in chunk:
            continue
        k, _, v = chunk.partition("=")
        merged[k] = unquote(v)
    merged.update(headers)
    return "{}|{}".format(base, _kodi_header_string(merged))


def _route_tv_play(query: Optional[Dict[str, str]] = None) -> None:
    """Live-TV cascade: probe alternate stream URLs in priority order, resolve
    to the first one returning HTTP 200.

    Invoked by pvr.iptvsimple when a channel's m3u line points at
    plugin://plugin.video.aegis/?action=tv_play&url=<url1>&url=<url2>&...

    Repeated `url=` parameters (not a pipe-separated `urls=` value)
    because Kodi parses pipes inside URL query values as inputstream
    header separators (`?url=...|User-Agent=...`) — that's the
    CurlFile pipe-header syntax. We re-parse `sys.argv[2]` via
    `parse_qsl` rather than the kwargs `query` because `dict(...)`
    collapses repeat keys, losing all but the last URL.

    The dedup pass in script.module.aegis.tvhub.dedup keeps cross-provider
    duplicates as alternates so a Pluto/jmp2.uk throttle automatically falls
    through to Samsung, Plex, or an iptv-org direct-CDN copy.
    """
    # parse_qsl collapses duplicate keys when passed through dict(), so we
    # re-parse argv[2] directly to recover all `url=` repetitions in order.
    raw_query = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    candidate_urls = [v for k, v in parse_qsl(raw_query, keep_blank_values=False) if k == "url"]
    if not candidate_urls:
        xbmc.log("Aegis tv_play: no candidate URLs in query", xbmc.LOGWARNING)
        _set_resolved_failure()
        return
    # Diagnostic: log query length + parsed URL count so we can confirm
    # whether Kodi is truncating very long plugin:// query strings. The
    # original 12-param Pluto stitcher URLs (~520 chars each, since
    # shortened to ~230) tripped a parser limit at ~1000 chars
    # somewhere between Kodi/pvr.iptvsimple and the plugin's argv,
    # arriving as 3 candidates from a 5-URL m3u line. Keep the log line
    # in case a future cascade growth (e.g. more alternates per
    # channel) walks back into the same trap.
    xbmc.log(
        "Aegis tv_play: parsed {} candidate URL(s) from query of {} chars".format(
            len(candidate_urls), len(raw_query),
        ),
        xbmc.LOGINFO,
    )

    chosen_url, chosen_idx, was_barker_fallback = _probe_cascade(candidate_urls)
    if chosen_url is None:
        xbmc.log(
            "Aegis tv_play: all {} candidates failed: {}".format(
                len(candidate_urls), [u.split("?")[0] for u in candidate_urls]
            ),
            xbmc.LOGWARNING,
        )
        _set_resolved_failure()
        return

    xbmc.log(
        "Aegis tv_play: cascade resolved to candidate[{}/{}]: {}".format(
            chosen_idx + 1, len(candidate_urls), chosen_url.split("?")[0]
        ),
        xbmc.LOGINFO,
    )

    if was_barker_fallback:
        # Every candidate failed the deep-probe — we're about to play a
        # URL whose child manifest came back empty. Pluto's SSAI stitcher
        # is the most common offender (its "We'll be right back" filler)
        # but any cascade with Samsung/Plex/iptv-org alternates can land
        # here too, so the toast stays provider-agnostic to avoid
        # misattributing the failure. The log line earlier in
        # `_probe_cascade` records the actual chosen URL for triage.
        try:
            xbmcgui.Dialog().notification(
                "Aegis Live TV",
                "Channel is serving filler — upstream refused our session. "
                "Try another channel.",
                xbmcgui.NOTIFICATION_WARNING,
                5000,
            )
        except Exception as exc:
            xbmc.log("Aegis tv_play: barker-fallback toast failed: {}".format(exc), xbmc.LOGWARNING)

    # HLS streams need an inputstream addon — Pluto/Samsung/Plex CDNs
    # 405 on HEAD probes that Kodi's native demuxer issues. Use the
    # same `_is_hls_candidate` helper as `_probe_cascade` so probe-time
    # and playback-time HLS decisions can't drift.
    #
    # Provider split (only applies to HLS — non-HLS URLs like
    # progressive .ts from iptv-org direct streams skip the inputstream
    # addon entirely and go through Kodi's native demuxer):
    #   - Samsung TV+ HLS uses inputstream.ffmpegdirect because
    #     Samsung's stream carries SCTE-35 ad-break markers as
    #     `#EXT-X-DISCONTINUITY` boundaries that crash
    #     inputstream.adaptive v21.5.18 (bundled with Kodi 21) in
    #     `CHLSTree::ParseChildManifest: Period of discontinuity N not
    #     found`. ffmpegdirect handles discontinuities through the
    #     ffmpeg HLS demuxer instead and doesn't trip the bug.
    #   - Other HLS providers (Pluto, Plex, Tubi, plus any iptv-org
    #     direct HLS source) stay on inputstream.adaptive — they
    #     don't trip the bug and adaptive handles their manifests
    #     fine.
    # Defensive: split off any Kodi CurlFile pipe-tail header section
    # (`...master.m3u8|User-Agent=...`) BEFORE running provider /
    # HLS classification. `_is_hls_candidate`, `_classify_stream`, and
    # `_headers_for_url` all evaluate against the bare URL — running
    # them against a piped form would (a) miss `.m3u8` detection
    # because `.split("?")[0]` doesn't strip pipes, (b) potentially
    # let an attacker-baked pipe-tail influence classifier output.
    # `_probe_cascade` rejects pipe-tailed URLs in production
    # (urlopen() raises on `|`), so reaching here with a pipe tail is
    # an edge case — but the cheap split keeps this layer honest.
    base_url = chosen_url.partition("|")[0]
    provider = _classify_stream(base_url) if _is_hls_candidate(base_url) else "unknown"
    if provider in ("samsung", "roku", "plex"):
        # Samsung TV+, Roku Channel, and Plex Live all carry SCTE-35
        # ad-break `EXT-X-DISCONTINUITY` markers that crash
        # inputstream.adaptive v21.5.18 (the Omega bundle the user
        # has installed). The crash signatures differ slightly —
        # Samsung trips `CHLSTree::ParseChildManifest: Period of
        # discontinuity N not found`; Plex Live and Roku more often
        # hit `SESSION::OnSegmentChanged: Cannot get the stream
        # sample reader` followed by `CVideoPlayerVideo::OpenStream
        # - could not open video codec` at each discontinuity —
        # but the underlying cause is the same: adaptive 21.5.18
        # doesn't have the period-detach fix that landed on main
        # (only shipped on the Piers / Kodi 22 branch as of
        # 2025-12-02).
        #
        # Route all three through ffmpegdirect, whose ffmpeg HLS
        # demuxer handles discontinuities cleanly. Pipe-tail carries
        # BOTH (a) HTTP headers — provider-specific UA + Origin/
        # Referer that ffmpegdirect's GetFFMpegOptionsFromInput
        # hands to ffmpeg as `user_agent` and `headers` options —
        # and (b) ffmpeg AVDictionary options (`reconnect=1` etc.)
        # that the same code path applies to ffmpeg's http protocol
        # via av_dict_set. See `_FFMPEG_RECONNECT_OPTS` in
        # stream_headers.py / its mirror in this module for the
        # full reasoning behind each reconnect option.
        #
        # Pass `chosen_url` (with any existing tail) so
        # `_kodi_pipe_header_url` merges into the existing tail —
        # CurlFile only parses ONE pipe segment, so `url|...|...`
        # silently drops the second set. Headers + ffmpeg-opts come
        # from `base_url` (no tail) so the classifier isn't
        # influenced by stale tail content.
        _http_headers = _headers_for_url(base_url)
        _ffmpeg_opts = _ffmpegdirect_pipe_options(base_url)
        # If the Aegis HLS proxy is up, route through it. The proxy
        # strips EXT-X-DISCONTINUITY tags before ffmpegdirect sees
        # them — eliminates the 1-15s decoder re-init stutter at each
        # SCTE-35 ad break (live capture 2026-06-11 21:40:37 caught
        # a 14s stall on Modern Marvels via Samsung). The proxy
        # applies the per-provider HTTP headers on the upstream
        # fetch; ffmpegdirect's pipe-tail only carries the ffmpeg
        # reconnect options now since the HTTP path between
        # ffmpegdirect and the proxy is localhost (no need to
        # re-encode the headers the proxy will apply anyway).
        #
        # Falls through to the pre-PR-43 direct-pipe-tail shape when
        # the proxy isn't running (Window property unset). Same
        # graceful-degrade story as a fresh install where the service
        # hasn't started the proxy yet.
        proxied_chosen = _aegis_proxy_url(chosen_url.partition("|")[0], _http_headers)
        if proxied_chosen is not None:
            piped_url = _kodi_pipe_header_url(proxied_chosen, _ffmpeg_opts)
        else:
            _pipe_dict = dict(_http_headers)
            _pipe_dict.update(_ffmpeg_opts)
            piped_url = _kodi_pipe_header_url(chosen_url, _pipe_dict)
        item = xbmcgui.ListItem(path=piped_url)
        item.setProperty("inputstream", "inputstream.ffmpegdirect")
        # `manifest_type=hls` matches the adaptive setting; explicit
        # `stream_mode=live` keeps ffmpegdirect from treating this as
        # a VOD-style fixed-length playlist (matters for the rolling
        # discontinuity buffer); `is_realtime_stream=true` tells the
        # player not to do seeking calculations against a wall clock.
        item.setProperty("inputstream.ffmpegdirect.manifest_type", "hls")
        item.setProperty("inputstream.ffmpegdirect.stream_mode", "live")
        item.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
        if provider == "samsung":
            # Pin the MPEG-TS program number for Samsung TV+.
            #
            # Samsung uses SSAI (server-side ad insertion, vendor
            # SSSLIVE — visible in the master URL's `ads.ssai_vendor`
            # query param) to stitch ad segments into the TS stream
            # at the CDN edge. The HLS playlist may emit
            # `EXT-X-DISCONTINUITY` at ad/content boundaries — those
            # the proxy strips (PR #43) — but the underlying MPEG-TS
            # bytes have different PMT (Program Map Table) entries
            # for ad vs content. ffmpegdirect's IsProgramChange()
            # detects the PMT change and signals STREAMCHANGE to
            # Kodi's VideoPlayer → ~14s decoder re-init stutter at
            # every ad break, even with the HLS-level strip in place.
            #
            # Live capture 2026-06-12 11:49:10 confirmed a re-init
            # at the 5:14 mark on 48 Hours through the proxy. PR #43
            # pushed the stutter from ~50s to 5+ min but didn't
            # eliminate it.
            #
            # `program_number=1` tells ffmpegdirect to pin the first
            # program — most Samsung TV+ streams use program 1 for
            # the main content. If ads come in on the SAME program
            # number (just different stream descriptors), this might
            # not fully fix the re-init either, but it's a low-risk
            # ~5 LOC experiment compared to building a full TS
            # re-muxer in the proxy. If it doesn't help, the
            # property is harmless (matches what's already there).
            item.setProperty("inputstream.ffmpegdirect.program_number", "1")
        xbmcplugin.setResolvedUrl(HANDLE, True, item)
        return
    # Use `base_url` (no pipe tail) for the non-Samsung path. Adaptive
    # gets its headers via dedicated properties — forwarding a
    # pipe-tail in the URL would be redundant at best and could
    # confuse Kodi's CurlFile parser in subtle ways (e.g.
    # double-encoded entities once adaptive re-fetches the manifest
    # for segment URLs). For non-HLS URLs we hand the bare URL to
    # Kodi's native demuxer; same reasoning applies — no caller
    # downstream expects a pipe tail on a non-FAST URL.
    item = xbmcgui.ListItem(path=base_url)
    if _is_hls_candidate(base_url):
        item.setProperty("inputstream", "inputstream.adaptive")
        item.setProperty("inputstream.adaptive.manifest_type", "hls")
        # Per-provider headers (Mozilla-Chrome UA for Pluto/Tubi/Plex/iptv-org).
        # Set on BOTH manifest fetch (.m3u8) and segment fetch (.ts/.fmp4) —
        # inputstream.adaptive exposes these as separate properties.
        # Compute headers from `base_url` so a pre-existing pipe tail
        # can't influence the classifier; adaptive doesn't need the
        # tail forwarded since its headers go in dedicated properties.
        header_str = _kodi_header_string(_headers_for_url(base_url))
        item.setProperty("inputstream.adaptive.manifest_headers", header_str)
        item.setProperty("inputstream.adaptive.stream_headers", header_str)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def _set_resolved_failure() -> None:
    """Tell Kodi the resolution failed so it stops trying this channel."""
    if HANDLE < 0:
        return
    item = xbmcgui.ListItem()
    xbmcplugin.setResolvedUrl(HANDLE, False, item)


# Minimum segment count for a child HLS manifest to be considered "real"
# rather than the barker / We'll-be-right-back filler that Pluto's stitcher
# serves to clients it doesn't recognize. Pluto's filler manifests usually
# come back with zero EXTINF lines (Kodi logs "No segments in the manifest"
# and limps along on cached buffer for ~10 seconds before exiting). A real
# live HLS feed reliably has 3+ segments in its rolling window — using 2 as
# the floor keeps headroom for the edge case where a brand-new live event
# just started and only has 2 segments queued.
_PROBE_MIN_CHILD_SEGMENTS = 2

# How much of the master m3u8 we'll read while looking for child URLs.
# 64 KB is far larger than any realistic master playlist (typically <2 KB)
# but defends against an attacker-controlled mirror trying to stream us an
# unbounded body.
_PROBE_MAX_MANIFEST_BYTES = 64 * 1024

# Substrings that, when present in a child HLS manifest, indicate Pluto's
# stitcher served us a filler/takedown loop instead of the real channel
# content. The takedown form has a populated child manifest (so the
# segment-count check passes) but every #EXTINF points at a specific
# rotating "channel removed" / "we'll be right back" clip in Pluto's
# CDN, so the user sees the same 30s filler on repeat instead of the
# channel they asked for.
#
# Observed segment URL pattern:
#   siloh-ns1.plutotv.net/.../clip/<id>_ptv_takedownslates_all_1500/...
#
# Treat any of these substrings in the child manifest body as the same
# class of failure as an empty manifest — the cascade should fall through
# to the next candidate (usually Samsung TV+ or Plex Live).
_PLUTO_FILLER_CLIP_MARKERS = (
    "_ptv_takedownslates_",
    "pluto_help_we_will_be_right_back",
)


def _is_hls_candidate(url: str) -> bool:
    """Decide whether a cascade candidate URL needs the HLS deep-probe.

    `.m3u8` suffix is the obvious signal, but several providers serve
    HLS from URLs without that suffix:

    - `jmp2.uk` is the FAST aggregator redirector — serves URLs like
      `https://jmp2.uk/stvp-US12345` (no suffix) that redirect to
      real HLS masters.
    - `epg.provider.plex.tv/library/parts/{id}/?X-Plex-Token=...` is
      Plex Live's URL form: trailing slash, no extension, and the
      X-Plex-Token query param is required auth (so we can't strip
      query strings as a signal). The endpoint serves HLS m3u8
      content but the URL doesn't look like HLS at the suffix level.
      Live capture 2026-06-08 22:20:04 showed Plex playing without
      inputstream.adaptive (native demux), stuttering every ~5-6s
      at segment boundaries — exactly because this gap let Plex
      fall through to the non-HLS branch in `_route_tv_play`.

    The plugin's playback path forces inputstream.adaptive for any
    URL this returns True for — keep the probe path consistent so
    candidates don't sneak past the barker check.

    Query strings are stripped before the suffix check; many CDNs
    sign m3u8 URLs as `master.m3u8?token=...`, and an endswith()
    against the raw URL would miss those. `_route_tv_play` shares
    this helper so the probe-time and playback-time HLS decisions
    can't drift.
    """
    lower = url.split("?")[0].lower()
    if lower.endswith(".m3u8"):
        return True
    if "jmp2.uk" in lower:
        return True
    # Plex Live's `library/parts/{id}/` form is HLS but has no
    # `.m3u8` extension. Match the hostname structurally rather than
    # substring so an attacker URL like
    # `https://attacker.example/.provider.plex.tv/...` can't sneak
    # past — `urlparse` extracts the actual hostname.
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
    except (ValueError, TypeError):
        return False
    if parsed.scheme not in ("http", "https"):
        return False
    host = (parsed.hostname or "").lower()
    return host == "provider.plex.tv" or host.endswith(".provider.plex.tv")


# Allow-listed URL schemes for any URL the plugin opens with
# urllib.request.urlopen. A hostile or compromised playlist could
# include `file://...`, `ftp://...`, `data:`, etc. as a candidate URL
# or as a variant URI inside a master playlist — passing those to
# urlopen would let the user's Kodi host read local files or hit
# unexpected protocol handlers. urlparse() returns scheme="" for
# malformed input (e.g. "javascript:alert(1)") which the allow-list
# also rejects.
_ALLOWED_PROBE_SCHEMES = ("http", "https")


def _is_probe_url_safe(url: str) -> bool:
    """True iff `url` parses to an http(s) scheme. Used at both
    cascade-candidate and HLS-child URL entry points before urlopen."""
    import urllib.parse
    return urllib.parse.urlparse(url).scheme in _ALLOWED_PROBE_SCHEMES


# Exception families urllib.request can legitimately raise on the wire.
# Listed explicitly (not as bare `Exception`) so unrelated programming
# errors (TypeError, AttributeError, ...) propagate to the log instead
# of looking like a probe failure. Ruff B014 flags
# `except (URLError, Exception):` because Exception is URLError's
# superclass; this tuple is the narrow alternative.
def _build_probe_network_errors():
    import http.client
    # OSError covers urllib.error.URLError (which is itself a subclass of
    # OSError), socket.timeout, and ConnectionError. Listing URLError
    # separately would be redundant and misleading — it suggests URLError
    # gets special handling here when it doesn't.
    return (
        OSError,                # URLError, socket.timeout, ConnectionError, etc.
        http.client.HTTPException,  # malformed HTTP response
        ValueError,             # urlopen rejects a few bad URL shapes synchronously
    )


_PROBE_NETWORK_ERRORS = _build_probe_network_errors()


def _hls_master_has_real_segments(master_url: str, master_body: str, headers: Dict[str, str], timeout: float = 5.0) -> bool:
    """Continuation of the deep-probe from an already-fetched master body.

    `_probe_cascade` reads the master playlist as part of its initial
    200-check, so re-fetching it inside `_probe_url_has_real_segments`
    would be a wasted network round-trip per candidate. This helper
    takes the body the caller already has and only fetches the child
    (one extra request) — net 2 requests per HLS candidate instead of
    3, which matters when the cascade has multiple alternates and the
    user hits "Play" on a channel they tune to a lot.

    `master_url` should be the URL the body was fetched from (post-
    redirect when applicable, so urljoin resolves relative child paths
    against the actual CDN location, not the jmp2.uk redirector input).
    """
    import urllib.parse
    import urllib.request

    if "#EXTM3U" not in master_body:
        # Not an HLS document — caller's 200-check already accepted it.
        # We return False here because this function is strictly about
        # HLS depth; the caller's tier-2 path covers the non-HLS case.
        return False

    # Case 2: media playlist — segments inline. Easy count.
    if "#EXT-X-STREAM-INF" not in master_body:
        # Same takedown-filler check as the master→child path: even with
        # enough EXTINF lines, if the segment URLs are Pluto's filler
        # clips it's still a barker.
        lowered_inline = master_body.lower()
        for marker in _PLUTO_FILLER_CLIP_MARKERS:
            if marker in lowered_inline:
                return False
        segs = sum(1 for line in master_body.splitlines() if line.startswith("#EXTINF:"))
        return segs >= _PROBE_MIN_CHILD_SEGMENTS

    # Case 1: master playlist — find first child URL line. Per HLS spec
    # the URL is the first non-tag, non-blank line after a
    # #EXT-X-STREAM-INF tag. Spec doesn't bound how many blank or
    # EXT-X-MEDIA / EXT-X-I-FRAME-STREAM-INF / comment lines may appear
    # between the STREAM-INF and its variant URI — the previous
    # 4-line cap could miss a perfectly valid playlist and report
    # False (treated as barker). Scan forward until we either find the
    # URI or hit the next STREAM-INF (i.e. moved past this variant).
    child_url = None
    lines = master_body.splitlines()
    for i, line in enumerate(lines):
        if not line.startswith("#EXT-X-STREAM-INF"):
            continue
        for j in range(i + 1, len(lines)):
            candidate = lines[j].strip()
            if not candidate:
                continue
            if candidate.startswith("#EXT-X-STREAM-INF"):
                # Next variant entry — current STREAM-INF had no URI
                # (malformed playlist). Bail rather than wrongly
                # adopting a later variant's URI.
                break
            if candidate.startswith("#"):
                continue
            child_url = urllib.parse.urljoin(master_url, candidate)
            break
        if child_url:
            break
    if not child_url:
        return False

    # Scheme allow-list: a hostile / compromised playlist could point
    # its variant URL at `file://...`, `ftp://...`, `data:`, etc. See
    # `_is_probe_url_safe` for the full rationale.
    if not _is_probe_url_safe(child_url):
        return False

    try:
        req = urllib.request.Request(child_url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.getcode() != 200:
                return False
            child_body = resp.read(_PROBE_MAX_MANIFEST_BYTES).decode("utf-8", errors="ignore")
    except _PROBE_NETWORK_ERRORS:
        return False

    # Takedown-filler detection: even when the child has plenty of
    # segments, if every segment URL points at one of Pluto's well-known
    # filler clip slugs ("takedownslates", "we_will_be_right_back"),
    # treat this as a barker so the cascade falls through to the next
    # candidate. Substring scan over the full body covers both the
    # #EXT-X-KEY URI lines and the segment URIs themselves.
    lowered = child_body.lower()
    for marker in _PLUTO_FILLER_CLIP_MARKERS:
        if marker in lowered:
            return False

    segs = sum(1 for line in child_body.splitlines() if line.startswith("#EXTINF:"))
    return segs >= _PROBE_MIN_CHILD_SEGMENTS


def _probe_url_has_real_segments(master_url: str, headers: Dict[str, str], timeout: float = 5.0) -> bool:
    """Deep-probe: master → child → count segments. Returns True only when
    the manifest hierarchy ends in a child with at least _PROBE_MIN_CHILD_SEGMENTS
    EXTINF lines. Returns False on any HTTP error, malformed manifest, or
    a child manifest with zero/insufficient segments — the latter is the
    Pluto barker pattern we're guarding against.

    Convenience wrapper around `_hls_master_has_real_segments` that
    fetches the master itself; `_probe_cascade` prefers the inner
    helper because it has the master body in hand from its own
    200-check. Kept here for the existing test interface and any
    direct callers.

    Same `headers` are sent on BOTH fetches because we've seen Pluto's
    stitcher gate based on Referer/Origin not just on the master but on
    every child fetch too.
    """
    import urllib.request

    try:
        req = urllib.request.Request(master_url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.getcode() != 200:
                return False
            body = resp.read(_PROBE_MAX_MANIFEST_BYTES).decode("utf-8", errors="ignore")
            # Use the post-redirect URL for child URL resolution — when
            # the input was a jmp2.uk redirector, child paths are
            # relative to the CDN's master URL, not the redirector.
            final_url = resp.geturl() if hasattr(resp, "geturl") else master_url
    except _PROBE_NETWORK_ERRORS:
        return False

    return _hls_master_has_real_segments(final_url, body, headers, timeout=timeout)


def _reorder_cascade_for_known_flaky_providers(urls: List[str]) -> List[str]:
    """Move Plex Live URLs to the end of the cascade.

    Plex Live's HLS doesn't keep continuous PTS across
    EXT-X-DISCONTINUITY boundaries — at every SCTE-35 ad break the
    new period starts at an absolute timestamp far from where the
    old period ended. ffmpegdirect forwards the packets and Kodi's
    player computes wall-clock-vs-PTS delta as nonsense, then the
    audio thread spirals into "large audio sync error" / stall
    (live capture 2026-06-09 00:23:08 saw -4906s drift accumulate
    in 4 seconds at the first discontinuity).

    Until we have a localhost m3u8 proxy that strips
    EXT-X-DISCONTINUITY (deferred follow-up), Plex Live is
    "playable only when nothing else is available." When the
    cascade has any non-Plex alternate, prefer those — Tubi direct
    HLS and Samsung-via-ffmpegdirect both have far more predictable
    PTS behaviour through ad breaks.

    Cascades with ONLY Plex candidates are NOT reordered — we still
    need Plex as the last-resort for channels with no alternates,
    and the existing barker-fallback tier in `_probe_cascade` will
    still pick the best Plex URL among them.

    Order within the non-Plex set is preserved (the upstream tvhub
    dedup logic already ranks them by quality). Same for the Plex
    set among itself.
    """
    plex_urls: List[str] = []
    non_plex_urls: List[str] = []
    for url in urls:
        # Strip any pipe-tail before classifying — same defence as
        # `_route_tv_play.base_url` and `_probe_cascade`.
        base = url.partition("|")[0]
        if _classify_stream(base) == "plex":
            plex_urls.append(url)
        else:
            non_plex_urls.append(url)
    if not non_plex_urls:
        # Plex-only cascade: keep original order, fall through to the
        # existing two-tier probe ranking unchanged.
        return urls
    return non_plex_urls + plex_urls


def _probe_cascade(urls: List[str]) -> Tuple[Optional[str], int, bool]:
    """Probe URLs in order; return the URL most likely to actually play.

    Returns `(url, idx, was_barker_fallback)`. `was_barker_fallback=True`
    means we resolved to a Tier-2 URL (every candidate failed deep-probe)
    — the caller can surface that as a "channel is currently serving
    filler" notification instead of silently playing the barker.

    Two-tier ranking applied in a single pass:
      Tier 1: URL returns 200 AND (if HLS) deep-probe finds real segments
              in the child manifest. This is the Pluto-barker guard — the
              barker case is a master that parses fine but whose child
              manifest has no EXTINF lines, so inputstream.adaptive logs
              "No segments in the manifest" and Kodi limps along on
              cached buffer for ~10s before stalling.
      Tier 2: URL returns 200 but deep-probe couldn't confirm segments.
              Used as fallback ONLY if every candidate fails Tier 1 —
              keeps us no-worse-than-before for the all-barker case.

    Non-HLS URLs (direct .ts, MPEG-DASH, etc.) skip the deep-probe and
    take Tier 1 on any 200 — we have no equivalent segment check there
    and inputstream.adaptive handles them via different code paths.
    HLS is detected by `.m3u8` suffix OR `jmp2.uk` substring (the FAST
    aggregators serve HLS through the jmp2.uk redirector even when the
    URL doesn't end in .m3u8).

    Per HLS candidate, the initial probe reads the full master playlist
    (instead of just 512 bytes) and reuses it for the deep-probe — net 2
    network requests per HLS candidate (master + child) instead of 3
    (master 200-check + master refetch + child).

    Before the probe loop, the URL list is run through
    `_reorder_cascade_for_known_flaky_providers` to push Plex Live URLs
    to the end. Plex Live's HLS has a PTS-jump problem at SCTE-35
    discontinuities that no inputstream addon recovers from cleanly;
    cascades with non-Plex alternates should land on those first.

    On total failure returns (None, -1, False).
    """
    import urllib.error
    import urllib.request

    urls = _reorder_cascade_for_known_flaky_providers(urls)

    tier2_url: Optional[str] = None
    tier2_idx: int = -1

    for idx, url in enumerate(urls):
        # Scheme allow-list: defend the cascade entry point too. The
        # deep-probe already filters child URLs inside HLS masters, but
        # an attacker can also feed `file://` / `ftp://` straight into
        # a cascade URL via a compromised m3u (or via a malicious
        # alternates upgrade). Same allow-list either way.
        if not _is_probe_url_safe(url):
            xbmc.log(
                "Aegis tv_play: candidate[{}/{}] probe FAIL "
                "(scheme not allowed): {}".format(
                    idx + 1, len(urls), url.split("?")[0]
                ),
                xbmc.LOGWARNING,
            )
            continue

        # Send the SAME header set the playback path will use for this URL —
        # Samsung-Tizen UA for stvp-, default Chrome UA for everything else.
        # Without this, probes succeed with Chrome UA but Samsung's cloudfront
        # edge 403s the .ts segments at playback time.
        probe_headers = _headers_for_url(url)
        is_hls = _is_hls_candidate(url)
        reason = ""
        ok_200 = False
        master_body = ""
        master_final_url = url
        try:
            req = urllib.request.Request(url, headers=probe_headers)
            with urllib.request.urlopen(req, timeout=5) as resp:
                if resp.getcode() == 200:
                    if is_hls:
                        # Read the full master so the deep-probe can reuse
                        # it without a second round-trip. Bounded by
                        # _PROBE_MAX_MANIFEST_BYTES so a hostile mirror
                        # can't stream us an unbounded body.
                        master_body = resp.read(_PROBE_MAX_MANIFEST_BYTES).decode("utf-8", errors="ignore")
                        if hasattr(resp, "geturl"):
                            master_final_url = resp.geturl()
                    else:
                        # Non-HLS: just confirm the body is actually
                        # deliverable (some CDNs return 200 headers then
                        # 403/empty body on data read).
                        resp.read(512)
                    ok_200 = True
                else:
                    reason = "code=" + str(resp.getcode())
        except urllib.error.HTTPError as exc:
            reason = "http=" + str(exc.code)
        except _PROBE_NETWORK_ERRORS as exc:
            # Use the same narrow exception tuple as the helpers so a
            # programming error (TypeError, AttributeError, ...) in the
            # probe path surfaces in the log instead of being silently
            # categorized as a probe failure and demoting the candidate.
            reason = type(exc).__name__ + ":" + str(exc)[:60]

        if not ok_200:
            xbmc.log(
                "Aegis tv_play: candidate[{}/{}] probe FAIL ({}): {}".format(
                    idx + 1, len(urls), reason, url.split("?")[0]
                ),
                xbmc.LOGINFO,
            )
            continue

        # Decide tier. HLS gets the deep-probe (reusing the master body
        # already read above); non-HLS passes Tier 1 on any 200.
        if not is_hls or _hls_master_has_real_segments(
            master_final_url, master_body, probe_headers
        ):
            xbmc.log(
                "Aegis tv_play: candidate[{}/{}] probe OK: {}".format(
                    idx + 1, len(urls), url.split("?")[0]
                ),
                xbmc.LOGINFO,
            )
            return url, idx, False

        # 200 OK on the master but deep-probe didn't confirm playable
        # segments. The dominant cause is Pluto's barker (master parses,
        # child manifest comes back empty), but the same `False` return
        # also covers child-fetch timeouts, HTTP errors, malformed
        # manifests, and non-HLS bodies — so the log line stays neutral
        # to keep triage honest. Remember as Tier-2 fallback in case
        # nothing else passes Tier 1.
        xbmc.log(
            "Aegis tv_play: candidate[{}/{}] 200 but deep-probe failed "
            "(barker, transient child-fetch error, malformed manifest, or "
            "non-HLS body); trying next: {}".format(
                idx + 1, len(urls), url.split("?")[0]
            ),
            xbmc.LOGINFO,
        )
        if tier2_url is None:
            tier2_url = url
            tier2_idx = idx

    if tier2_url is not None:
        xbmc.log(
            "Aegis tv_play: no candidate passed deep-probe; falling back to "
            "first 200 (barker-tolerant): {}".format(tier2_url.split("?")[0]),
            xbmc.LOGWARNING,
        )
        return tier2_url, tier2_idx, True
    return None, -1, False


def _tv_rebuild(query=None):
    """Re-run the full merge pipeline from vault sources (fetches real channels).

    This is a headless-compatible action that loads the firstrun service module
    and calls _setup_live_tv() directly, bypassing the interactive wizard flow.
    Useful when pvr.iptvsimple was not available during first-run.
    """
    query = query or {}
    headless = query.get("headless", "0") == "1"
    try:
        service_path = xbmcvfs.translatePath("special://home/addons/service.aegis.firstrun/service.py")
        if not xbmcvfs.exists(service_path):
            xbmc.log("Aegis tv_rebuild: service.aegis.firstrun/service.py not found", xbmc.LOGWARNING)
            if not headless:
                xbmcgui.Dialog().notification("Aegis", "First-run service missing.", xbmcgui.NOTIFICATION_ERROR, 3000)
            _close_directory_if_needed()
            return

        spec = importlib.util.spec_from_file_location("aegis_firstrun_service_tv", service_path)
        if spec is None or spec.loader is None:
            raise RuntimeError("Cannot load service module spec")
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        from aegis_vault import VaultStore
        vault = VaultStore(mod._vault_dir())
        mod._setup_live_tv(vault, enabled=True)
        xbmc.log("Aegis tv_rebuild: _setup_live_tv complete", xbmc.LOGINFO)
        # Force the PVR disable/enable reload cycle so the new M3U takes effect immediately.
        applied, reason = _configure_pvr_from_tvhub_outputs()
        xbmc.log("Aegis tv_rebuild: pvr reconfigure applied={} reason={}".format(applied, reason), xbmc.LOGINFO)
        if not headless:
            if applied:
                xbmcgui.Dialog().notification("Aegis", "Live-TV channels rebuilt.", xbmcgui.NOTIFICATION_INFO, 4000)
            else:
                xbmcgui.Dialog().notification("Aegis", "Rebuild done but pvr config failed: {}".format(reason), xbmcgui.NOTIFICATION_WARNING, 5000)
    except Exception as exc:
        xbmc.log("Aegis tv_rebuild: failed: {}".format(exc), xbmc.LOGERROR)
        if not headless:
            xbmcgui.Dialog().notification("Aegis", "Rebuild failed - see logs", xbmcgui.NOTIFICATION_ERROR, 3000)
    _close_directory_if_needed()


def run():
    query = dict(parse_qsl(sys.argv[2][1:]))
    action = query.get("action", "home")
    _normalize_legacy_estuary_settings()
    global HANDLE
    if action not in DIRECTORY_ACTIONS and HANDLE < 0:
        HANDLE = 1
    routes = {
        "home": _show_home,
        "movies": _route_movies,
        "shows": _route_shows,
        "search": _show_search_menu,
        "settings_panel": _show_settings_panel,
        "search_movies": _route_search_movies,
        "search_tv": _route_search_tv,
        "rd_cloud": _route_rd_cloud,
        "rd_setup": lambda: _route_rd_setup(query),
        "ad_setup": lambda: _route_ad_setup(query),
        "firstrun": lambda: _route_firstrun(query),
        "remote": lambda: _show_remote_control(query),
        "games": _show_games,
        "music": lambda: _route_music_library(query),
        "settings": lambda: _route_addon_settings(query),
        "health": lambda: _route_health(query),
        "vault_backup": lambda: _route_vault_backup(query),
        "vault_restore": lambda: _route_vault_restore(query),
        "live_tv": lambda: _route_live_tv_channels(query),
        "sports": lambda: _route_sports(query),
        "live_tv_refresh": _show_live_tv_refresh,
        "tv_refresh_apply": lambda: _apply_live_tv_refresh(query),
        "tv_rebuild": lambda: _tv_rebuild(query),
        "tv_play": lambda: _route_tv_play(query),
        "widget_continue": _widget_continue,
        "widget_recent_games": _widget_recent_games,
        "widget_live_tv": _widget_live_tv,
        "favorites": _show_favorites,
        "favorites_movies": lambda: _show_favorites_list("movie"),
        "favorites_shows": lambda: _show_favorites_list("show"),
        "toggle_favorite": lambda: _toggle_favorite(query),
    }
    routes.get(action, _show_home)()


if __name__ == "__main__":
    run()
