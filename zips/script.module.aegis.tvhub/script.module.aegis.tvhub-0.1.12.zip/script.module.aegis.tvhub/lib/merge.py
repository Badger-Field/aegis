"""Live-TV merge pipeline: fetch, parse, dedup, write merged m3u+EPG."""
import calendar
import time
import xml.etree.ElementTree as ET
from pathlib import Path

import xbmc

# EPG output bounds. Two real-world constraints push us here:
#
# 1. Orphan programmes: source XMLTV files routinely contain programmes
#    whose `channel` attribute doesn't match any `<channel id="...">`
#    we declare in the merged file. The original Pluto / Plex / Samsung
#    EPGs use composite or stitched IDs that don't survive m3u dedup,
#    and pvr.iptvsimple silently chokes (Kodi hard-crashes after
#    LoadChannelEpgs) when a large fraction of programmes reference
#    undeclared channels. Filter them out at merge time.
#
# 2. Size limit: even with orphans removed, a large EPG blows up
#    iptvsimple's in-memory model. Empirical crash zone on Windows
#    during the LoadEpgEntries pass (Kodi exits silently after the
#    LoadChannelEpgs log line):
#      - 7700 programmes:  parsed in 505ms — safe
#      - 11-12k:           safe
#      - ~14k:             borderline OK
#      - 16k+:             crashes on user's profile (observed)
#      - 27k+:             crashes consistently
#      - 36k+:             crashes immediately
#
# Strategy: pair a generous time window (gives the merge logic plenty
# to work with) with a HARD CAP on output size. When the window-filtered
# count exceeds EPG_MAX_PROGRAMMES we keep the closest-to-now programmes
# (where "close" is the minimum of |start - now| and |stop - now|), so
# we trim the far-future tail first — that's the part users won't see
# in the next refresh cycle anyway.
EPG_WINDOW_PAST_HOURS = 1
EPG_WINDOW_FUTURE_HOURS = 6
# Conservative cap: well under the observed 14k borderline so the
# safety margin survives growth in either source EPG. Bump cautiously
# if iptvsimple ships a parser fix or you confirm a higher cap on
# the target platform.
EPG_MAX_PROGRAMMES = 12000

# Per-channel programme floor for the cap. When the cap fires, every
# channel with at least one in-window programme is guaranteed up to this
# many slots before the remaining budget is distributed by closeness-to-
# now. Without a floor the closeness sort starved ~49% of channels of any
# EPG at all (channels whose next programme starts >2-3h out lost every
# slot to channels with continuously-airing programmes that span "now").
# The floor evens out per-channel coverage so the guide doesn't render
# wide swaths of blank rows.
EPG_PER_CHANNEL_FLOOR = 3

try:
    from .dedup import dedupe
    from .fabric.manager import FabricManager
    from .fetch import fetch_epg
    from .sources import SourceRegistry
    from .stream_headers import (
        classify_stream,
        ffmpegdirect_pipe_options,
        headers_for_url,
        kodi_header_string,
        kodi_pipe_header_url,
    )
except (ImportError, ValueError):
    from dedup import dedupe
    from fabric.manager import FabricManager
    from fetch import fetch_epg
    from sources import SourceRegistry
    from stream_headers import (
        classify_stream,
        ffmpegdirect_pipe_options,
        headers_for_url,
        kodi_header_string,
        kodi_pipe_header_url,
    )


class MergeResult:
    """Result of a merge operation."""

    def __init__(self):
        self.total_channels = 0
        self.dedup_count = 0
        self.epg_channels = 0
        self.epg_programmes = 0
        self.errors = []  # list of (source_id, error_msg)
        self.source_statuses = []  # list of provider status dictionaries


class _SourceWithEpg:
    """Read-only wrapper that exposes an override for `epg_url` while
    forwarding every other attribute to the wrapped Source. We use this
    when the auto-discovered url-tvg fills in for a missing config entry
    — mutating the live registry Source would persist back to the vault
    on the next write and confuse later cold starts."""

    def __init__(self, inner, epg_url: str):
        self._inner = inner
        self.epg_url = epg_url

    def __getattr__(self, name: str):
        return getattr(self._inner, name)


def merge(
    registry: SourceRegistry,
    output_dir: Path,
    session,  # GuardedSession
) -> MergeResult:
    """
    Fetch all enabled sources, merge and dedup channels, write merged.m3u + merged-epg.xml.

    Args:
        registry: SourceRegistry instance
        output_dir: output directory (created if missing)
        session: GuardedSession for fetching

    Returns:
        MergeResult with stats and error log
    """
    result = MergeResult()
    output_dir.mkdir(parents=True, exist_ok=True)

    # Fetch all sources through provider fabric manager
    enabled_sources = registry.get_enabled()
    source_ids = [src.id for src in enabled_sources]
    manager = FabricManager(registry, session, output_dir)
    all_channels, source_statuses, source_errors = manager.collect_channels()
    result.source_statuses = source_statuses
    result.errors.extend(source_errors)

    for status in source_statuses:
        xbmc.log(
            "Aegis tvhub: source {} [{}] channels={} warnings={}".format(
                status.get("name", "unknown"),
                status.get("status", "unknown"),
                status.get("channels", 0),
                len(status.get("warnings", [])),
            ),
            xbmc.LOGINFO,
        )

    # Dedup
    deduped = dedupe(all_channels, source_priority_order=source_ids)
    result.dedup_count = len(all_channels) - len(deduped)
    result.total_channels = len(deduped)

    # Write merged m3u
    m3u_path = output_dir / "merged.m3u"
    _write_m3u(m3u_path, deduped)

    # Fetch and merge EPG. For sources without a configured epg_url, fall
    # back to whatever the m3u's own `#EXTM3U url-tvg="..."` header advertised
    # (captured by FabricManager.collect_channels). This auto-recovers EPG for
    # iptv-org regional m3us and BuddyChewChew's Roku playlist, which both
    # ship the EPG URL inline but our config historically left unset.
    discovered_epg_by_id = {
        s.get("name"): s.get("discovered_epg_url") or ""
        for s in source_statuses
    }
    all_programmes = []
    for source in enabled_sources:
        effective_epg_url = source.epg_url or discovered_epg_by_id.get(source.id, "")
        if not effective_epg_url:
            continue

        try:
            # `fetch_epg` reads source.epg_url directly; build a shim source
            # with the discovered URL so we don't have to mutate registry
            # state mid-merge (the registry write would persist and confuse
            # later runs).
            fetch_source = source if source.epg_url else _SourceWithEpg(source, effective_epg_url)
            epg_bytes = fetch_epg(fetch_source, session)
            if epg_bytes:
                programmes = _parse_xmltv(epg_bytes)
                all_programmes.extend(programmes)
        except Exception as exc:
            xbmc.log(
                f"Aegis tvhub: EPG parse error {source.id}: {exc}",
                xbmc.LOGWARNING,
            )

    # Dedup EPG and write
    epg_path = output_dir / "merged-epg.xml"
    result.epg_channels, result.epg_programmes = _write_xmltv(
        epg_path, deduped, all_programmes
    )

    return result


def _write_m3u(path: Path, channels) -> None:
    """Write channels to m3u file.

    Channels with alternate_urls (cross-provider duplicates kept by dedup) emit
    a plugin:// URL that routes through plugin.video.aegis's tv_play action.
    The plugin probes each URL in priority order and resolves to the first one
    returning HTTP 200 — so when Pluto's stitcher throttles us via jmp2.uk, the
    channel automatically falls through to Samsung, Plex, or iptv-org's direct-
    CDN copy without user intervention.
    """
    from urllib.parse import quote_plus

    lines = ["#EXTM3U"]
    cascade_count = 0
    direct_count = 0
    skipped_count = 0

    for ch in channels:
        attrs_parts = []
        if ch.tvg_id:
            attrs_parts.append(f'tvg-id="{ch.tvg_id}"')
        if ch.tvg_name:
            attrs_parts.append(f'tvg-name="{ch.tvg_name}"')
        if ch.tvg_logo:
            attrs_parts.append(f'tvg-logo="{ch.tvg_logo}"')
        if ch.group_title:
            attrs_parts.append(f'group-title="{ch.group_title}"')

        # Canonical m3u format: a single EXTINF line ending with ",<channel-name>",
        # immediately followed by the stream URL line. An embedded "\n" inside the
        # EXTINF string would create a blank line that pvr.iptvsimple treats as a
        # record terminator (only parsing the first channel).
        extinf = f"#EXTINF:-1 {' '.join(attrs_parts)},{ch.tvg_name or ''}"
        lines.append(extinf)

        primary = ch.stream_url
        alternates = list(getattr(ch, "alternate_urls", []) or [])

        # Identity-preserved fallback: when a winning channel's primary
        # source is dead (e.g. Pluto canary nulled the stream_url to
        # preserve tvg-id continuity across availability changes), promote
        # the first working alternate to primary. The remaining alternates
        # cascade behind it normally. Channels with no URLs at all get
        # skipped entirely so the user's guide doesn't show clickable
        # rows that go nowhere.
        if not primary:
            if alternates:
                primary = alternates.pop(0)
            else:
                # No primary, no alternates — Pluto-only channel during
                # a dead canary, or a parsing bug. Either way, nothing
                # playable. Skip the EXTINF we just appended.
                lines.pop()
                skipped_count += 1
                continue

        # Strip any Kodi CurlFile pipe tail before classifying so a
        # legacy / attacker-baked tail can't push a non-provider URL
        # into a provider bucket. `classify_stream()` uses substring
        # matches for some providers (notably Tubi via `tubi.io` /
        # `tubitv.com`), so a crafted `https://attacker/...|...tubi.io...`
        # could otherwise force tubi-style KODIPROPs onto a URL that
        # isn't really Tubi. Same defence as
        # `plugin.video.aegis._route_tv_play.base_url`.
        base_primary = primary.partition("|")[0]
        provider = classify_stream(base_primary)

        # Cascade-route any channel that has alternates, OR any
        # single-URL channel where the plugin's cascade path delivers
        # behaviour we can't get from the direct-write path:
        #
        #  - Pluto single-URL: the plugin's deep-probe detects Pluto's
        #    "We'll be right back" / "Please hold" barker fallback and
        #    surfaces an honest "currently filler" toast. Worst case
        #    the cascade just plays the single URL anyway (Tier-2
        #    fallback) so users aren't worse off than before this
        #    branch.
        #  - Samsung / Roku / Plex single-URL: the plugin routes the
        #    chosen URL through the local Aegis HLS proxy
        #    (`_aegis_proxy_url`), which strips `EXT-X-DISCONTINUITY`
        #    tags before they reach ffmpegdirect. Without this, direct
        #    Plex entries (e.g. `epg.provider.plex.tv/library/parts/`
        #    URLs from `fast-plex-*` sources) bypass the proxy entirely
        #    and the user still sees the per-discontinuity stutter that
        #    PR #43 was supposed to fix everywhere. Live capture
        #    2026-06-12 09:16:12 confirmed the gap on CNN Headlines.
        #
        # `force_cascade_for_*` flags are kept separate so a future
        # reader can grep which reason a given route is on.
        force_cascade_for_barker_check = (
            not alternates and provider == "pluto"
        )
        force_cascade_for_proxy_routing = (
            not alternates and provider in ("samsung", "roku", "plex")
        )

        if alternates or force_cascade_for_barker_check or force_cascade_for_proxy_routing:
            # Cascade path: route through Aegis plugin so it can probe + fall
            # through. The plugin handler sets inputstream.adaptive on the
            # resolved item; no KODIPROP needed here.
            # Use repeated url= params instead of a pipe-separated list because
            # Kodi treats `|` in URLs as a header separator (e.g., url|user-agent=...).
            urls = [primary] + alternates
            params = "action=tv_play&" + "&".join("url={}".format(quote_plus(u)) for u in urls)
            stream_line = "plugin://plugin.video.aegis/?" + params
            cascade_count += 1
        else:
            # Direct path: pvr.iptvsimple opens the URL itself. Inject
            # inputstream KODIPROPs based on provider classification.
            #
            # IMPORTANT: After PR #43 / #44, this branch only runs for
            # providers we DO NOT need to route through the plugin's
            # proxy code path. Samsung / Roku / Plex / Pluto single-URL
            # entries are all force-cascaded above so the proxy strip +
            # barker checks apply. The remaining providers that land
            # here are:
            #   - Tubi → inputstream.adaptive (no SCTE-35 issue,
            #     adaptive's manifest/stream header properties work
            #     fine)
            #   - "unknown" (iptv-org direct streams etc.) → no
            #     KODIPROP so pvr.iptvsimple uses Kodi's default
            #     demuxer path. iptv-org's mix includes direct .ts
            #     progressive sources alongside HLS — we can't safely
            #     force inputstream.adaptive on the .ts subset
            #     without breaking them.
            #
            # The samsung/roku/plex branch here is kept as a defensive
            # fallback (e.g. if a future refactor disables the proxy
            # routing and the force-cascade above gets reverted), but
            # in normal operation it's unreachable for those providers.
            if provider in ("samsung", "roku", "plex"):
                # Samsung TV+, Roku Channel, and Plex Live all carry
                # SCTE-35 ad-break discontinuities that crash
                # inputstream.adaptive 21.5.18 (Omega bundle). Route
                # all three through ffmpegdirect, whose ffmpeg HLS
                # demuxer handles discontinuities cleanly. See
                # plugin.video.aegis._route_tv_play for the full
                # reasoning (this is the direct-channel mirror of
                # that cascade-resolver branch).
                lines.append("#KODIPROP:inputstream=inputstream.ffmpegdirect")
                lines.append("#KODIPROP:inputstream.ffmpegdirect.manifest_type=hls")
                lines.append("#KODIPROP:inputstream.ffmpegdirect.stream_mode=live")
                lines.append("#KODIPROP:inputstream.ffmpegdirect.is_realtime_stream=true")
                # Pipe-tail carries BOTH provider-specific headers
                # (consumed by ffmpegdirect's GetFFMpegOptionsFromInput
                # as ffmpeg headers/user_agent) AND ffmpeg reconnect
                # options (reconnect=1 etc., av_dict_set'd onto the
                # ffmpeg http protocol). See `_FFMPEG_RECONNECT_OPTS`
                # in stream_headers.py for full reasoning.
                #
                # Pass `primary` (with any existing tail) so
                # kodi_pipe_header_url merges into the existing tail —
                # CurlFile only parses ONE pipe segment, so `url|...|...`
                # silently drops the second set. Headers + ffmpeg-opts
                # themselves come from `base_primary` so the classifier
                # isn't influenced by a stale tail.
                _pipe_dict = headers_for_url(base_primary)
                _pipe_dict.update(ffmpegdirect_pipe_options(base_primary))
                stream_line = kodi_pipe_header_url(primary, _pipe_dict)
            elif provider != "unknown":
                header_str = kodi_header_string(headers_for_url(base_primary))
                lines.append("#KODIPROP:inputstream=inputstream.adaptive")
                lines.append("#KODIPROP:inputstream.adaptive.manifest_type=hls")
                lines.append("#KODIPROP:inputstream.adaptive.manifest_headers=" + header_str)
                lines.append("#KODIPROP:inputstream.adaptive.stream_headers=" + header_str)
                # Adaptive sets headers via dedicated properties — drop
                # the pipe tail from the URL too so it doesn't end up
                # in pvr.iptvsimple's CurlFile call alongside the
                # property-based headers (would be double-set at best).
                stream_line = base_primary
            else:
                # Native demuxer path — same reasoning: don't forward
                # an unexpected pipe tail to Kodi.
                stream_line = base_primary
            direct_count += 1

        lines.append(stream_line)

    path.write_text("\n".join(lines), encoding="utf-8")
    # `written_count` is the actual EXTINF rows in the file —
    # `len(channels)` over-reports because the no-URL branch (Pluto-
    # only with dead canary) `continue`s past channels without
    # emitting them. Log skipped separately so a sudden gap between
    # "channels supplied" and "channels written" is obvious during
    # triage instead of being hidden in the cascade/direct sum.
    written_count = cascade_count + direct_count
    xbmc.log(
        "Aegis tvhub: wrote {} (written={}/{}, cascade={}, direct={}, "
        "skipped_no_url={})".format(
            path, written_count, len(channels),
            cascade_count, direct_count, skipped_count,
        ),
        xbmc.LOGINFO,
    )


def _parse_xmltv(content: bytes) -> list:
    """Parse XMLTV into list of programme elements. Handles gzip transparently.

    mjh.nz serves Pluto/Samsung/Plex EPG as .xml.gz; iptv-org serves uncompressed
    .xml. We detect gzip by the magic bytes (0x1f 0x8b) rather than URL suffix
    so the caller doesn't have to know which one a given source uses.
    """
    if content[:2] == b"\x1f\x8b":
        import gzip
        try:
            content = gzip.decompress(content)
        except Exception:
            return []

    try:
        root = ET.fromstring(content)
    except Exception:
        return []

    return list(root.findall("programme"))


def _parse_xmltv_dt(s: str) -> int:
    """Parse an XMLTV timestamp like '20260521210000 +0000' into a UTC
    epoch. Returns 0 on bad input — callers treat that as "drop this
    programme" via the window check.

    Source feeds emit timestamps in UTC (`+0000`). We use calendar.timegm
    (which interprets struct_time as UTC) rather than time.mktime
    (which interprets as local) — otherwise on non-UTC hosts every
    programme's epoch is shifted by the local TZ offset, and the
    now-relative window filter drops tonight's lineup as "out of window."
    """
    if not s or len(s) < 14:
        return 0
    try:
        return calendar.timegm(time.strptime(s[:14], "%Y%m%d%H%M%S"))
    except ValueError:
        return 0


def _write_xmltv(path: Path, channels, programmes) -> tuple:
    """
    Write merged EPG. Six filters guard against the pvr.iptvsimple
    crash modes we've observed (see module-level comment for context):

      1. Channels deduplicated by tvg_id from the m3u.
      2. Programmes that reference an undeclared channel are dropped.
      3. Programmes with malformed start/stop timestamps are dropped —
         _parse_xmltv_dt returns 0 on bad input and iptvsimple chokes
         on those entries during LoadEpgEntries. Dropped at the top of
         the filter pipeline rather than relying on the cap to deprio
         them, so a below-cap file is still guaranteed safe.
      4. Programmes outside the (now-EPG_WINDOW_PAST_HOURS,
         now+EPG_WINDOW_FUTURE_HOURS) window are dropped — currently
         (now-1h, now+6h); see the module-level comment for why the
         forward bound is conservative.
      5. Duplicate (channel_id, start) pairs are dropped so a programme
         that appears in multiple source feeds doesn't double-count.
      6. Hard cap at EPG_MAX_PROGRAMMES — if filters 1-5 still leave
         more than the cap, sort by closeness-to-now and trim the
         farthest ones. iptvsimple has crashed on us at ~16k entries
         on Windows, so this is the final safety net even when the
         time window check passes.

    Returns: (channel_count, programme_count)
    """
    root = ET.Element("tv")

    # Dedup channels by ID
    seen_ids = set()
    for ch in channels:
        if ch.tvg_id and ch.tvg_id not in seen_ids:
            channel_elem = ET.SubElement(root, "channel")
            channel_elem.set("id", ch.tvg_id)
            name_elem = ET.SubElement(channel_elem, "display-name")
            name_elem.text = ch.tvg_name or ch.tvg_id
            seen_ids.add(ch.tvg_id)

    now = int(time.time())
    lower = now - EPG_WINDOW_PAST_HOURS * 3600
    upper = now + EPG_WINDOW_FUTURE_HOURS * 3600

    seen_programmes: set = set()
    orphans_dropped = 0
    out_of_window = 0
    duplicate_dropped = 0
    malformed_dropped = 0
    for prog in programmes:
        channel_id = prog.get("channel")
        # Filter 1: drop programmes for channels we didn't declare. These
        # are the FAST/composite IDs that crash iptvsimple.
        if channel_id not in seen_ids:
            orphans_dropped += 1
            continue
        # Filter 2: drop programmes with malformed start/stop unconditionally.
        # _parse_xmltv_dt returns 0 on bad input. Previously these were only
        # deprioritized by the cap's closeness sort, so below-cap files could
        # still ship malformed programmes through to iptvsimple — defeating
        # the safety envelope the cap is supposed to provide. With this
        # filter every programme that survives has parseable bounds.
        start = _parse_xmltv_dt(prog.get("start", ""))
        stop = _parse_xmltv_dt(prog.get("stop", ""))
        if start == 0 or stop == 0:
            malformed_dropped += 1
            continue
        # Filter 3: window the EPG to (now-EPG_WINDOW_PAST_HOURS,
        # now+EPG_WINDOW_FUTURE_HOURS) — 6h forward by default. Past
        # programmes are useless for the guide; very-future ones blow up
        # the parser (see module-level comment for the empirical limit).
        if stop < lower or start > upper:
            out_of_window += 1
            continue
        # Filter 4: drop duplicate programmes (same channel + start).
        key = (channel_id, prog.get("start"))
        if key in seen_programmes:
            duplicate_dropped += 1
            continue
        root.append(prog)
        seen_programmes.add(key)

    # Filter 6 (safety net): hard cap on total programme count, with a
    # per-channel floor so coverage doesn't collapse onto a small slice
    # of channels.
    #
    # Two-phase distribution:
    #   Phase 1 — every channel with in-window programmes gets up to
    #             EPG_PER_CHANNEL_FLOOR closest-to-now slots (or fewer
    #             if the channel has fewer programmes available).
    #   Phase 2 — any remaining budget up to EPG_MAX_PROGRAMMES is
    #             distributed globally by closeness-to-now.
    #
    # This guarantees that channels whose next programme starts >2-3h out
    # still appear in the guide (instead of being starved by always-on
    # channels that span "now"), while preserving the iptvsimple safety
    # envelope the absolute cap provides.
    capped_off = 0

    # Use the seen_programmes set's size as the cheap pre-check — it
    # tracks every programme appended above. Avoid materializing the
    # full programme list (and re-walking the XML tree) on the common
    # case where the count is under cap.
    if len(seen_programmes) > EPG_MAX_PROGRAMMES:

        def _closeness(prog):
            # 0 if "now" is inside [start, stop], else distance to nearer
            # edge. Currently-airing programmes always sort first regardless
            # of how long ago they started.
            # Filter 2 above already drops programmes with malformed start
            # or stop timestamps before they reach the cap path, so the
            # 0-checks below are a defensive guard rather than the primary
            # rejection — if a future refactor moves or weakens Filter 2,
            # any leakage sorts to the bottom and trims first via the
            # `float("inf")` return so iptvsimple still doesn't see a
            # malformed entry.
            s = _parse_xmltv_dt(prog.get("start", ""))
            e = _parse_xmltv_dt(prog.get("stop", ""))
            if s == 0 or e == 0:
                return float("inf")
            if s <= now <= e:
                return 0
            return min(abs(s - now), abs(e - now))

        kept_programmes = list(root.findall("programme"))
        # Pre-sort globally so per-channel groups inherit closeness order.
        kept_programmes.sort(key=_closeness)

        per_channel: dict = {}
        for prog in kept_programmes:
            per_channel.setdefault(prog.get("channel"), []).append(prog)

        # Phase 1: floor per channel.
        keep_ids: set = set()
        for progs in per_channel.values():
            for prog in progs[:EPG_PER_CHANNEL_FLOOR]:
                keep_ids.add(id(prog))

        # Phase 2: fill remaining budget from the global closeness order,
        # skipping anything Phase 1 already kept.
        budget = EPG_MAX_PROGRAMMES - len(keep_ids)
        if budget > 0:
            for prog in kept_programmes:
                if budget <= 0:
                    break
                pid = id(prog)
                if pid in keep_ids:
                    continue
                keep_ids.add(pid)
                budget -= 1

        # If Phase 1 alone overflowed the cap (very wide source set with
        # FLOOR * channel_count > EPG_MAX_PROGRAMMES), trim phase-1 picks
        # back by global closeness. The cap is the hard ceiling.
        if len(keep_ids) > EPG_MAX_PROGRAMMES:
            ordered_keeps = [p for p in kept_programmes if id(p) in keep_ids]
            keep_ids = set(id(p) for p in ordered_keeps[:EPG_MAX_PROGRAMMES])

        for prog in list(root.findall("programme")):
            if id(prog) not in keep_ids:
                root.remove(prog)
                capped_off += 1

    tree = ET.ElementTree(root)
    tree.write(str(path), encoding="utf-8", xml_declaration=True)
    final_count = len(root.findall("programme"))
    xbmc.log(
        "Aegis tvhub: wrote {} ({} channels, {} programmes; "
        "dropped {} orphans, {} malformed-timestamp, {} out-of-window, "
        "{} duplicates, {} over cap)".format(
            path, len(seen_ids), final_count,
            orphans_dropped, malformed_dropped, out_of_window,
            duplicate_dropped, capped_off,
        ),
        xbmc.LOGINFO,
    )

    return len(seen_ids), final_count
