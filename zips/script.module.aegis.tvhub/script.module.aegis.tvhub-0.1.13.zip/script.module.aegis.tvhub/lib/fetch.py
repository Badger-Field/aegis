"""Fetch live-TV m3u and EPG feeds."""
from typing import Optional

import xbmc


class FetchError(Exception):
    """Raised on fetch failures."""

    pass


def _validate_url(url: str) -> None:
    """Enforce HTTPS-only."""
    if not url.startswith("https://"):
        raise FetchError(f"Non-HTTPS URL rejected: {url}")


def _validate_git_commit(url: str, commit_pin: Optional[str]) -> None:
    """For git_m3u sources, assert the URL has a pinned commit SHA."""
    if not commit_pin:
        raise FetchError(f"git_m3u source requires commit_pin; url={url}")

    if f"/{commit_pin}/" not in url:
        raise FetchError(
            f"git_m3u URL must include commit SHA; expected /{commit_pin}/ in {url}"
        )


def fetch_m3u(source, session) -> bytes:
    """
    Fetch m3u from a source using GuardedSession.

    Args:
        source: Source instance with kind='git_m3u' or 'url_m3u'
        session: aegis_netguard.GuardedSession instance

    Returns:
        Raw m3u bytes

    Raises:
        FetchError on HTTPS violation, commit-pin mismatch, or fetch failure
    """
    _validate_url(source.url)

    if source.kind == "git_m3u":
        _validate_git_commit(source.url, source.commit_pin)

    try:
        response = session.get(source.url, timeout=30)
        response.raise_for_status()
    except Exception as exc:
        raise FetchError(f"Failed to fetch {source.url}: {exc}") from exc

    # Sanity check: m3u should be < 50MB
    content = response.content
    if len(content) > 50_000_000:
        raise FetchError(
            f"Fetched m3u too large ({len(content)} bytes > 50MB); rejecting"
        )

    xbmc.log(
        f"Aegis tvhub: fetched {source.id} ({len(content)} bytes)",
        xbmc.LOGINFO,
    )
    return content


def fetch_epg(source, session) -> Optional[bytes]:
    """
    Fetch EPG (XMLTV) from a source if epg_url is set.

    Args:
        source: Source instance
        session: aegis_netguard.GuardedSession instance

    Returns:
        Raw XMLTV bytes, or None if no epg_url

    Raises:
        FetchError on HTTPS violation or fetch failure
    """
    if not source.epg_url:
        return None

    _validate_url(source.epg_url)

    try:
        response = session.get(source.epg_url, timeout=30)
        response.raise_for_status()
    except Exception as exc:
        xbmc.log(
            f"Aegis tvhub: failed to fetch EPG {source.id}: {exc}",
            xbmc.LOGWARNING,
        )
        return None

    content = response.content
    if len(content) > 100_000_000:
        xbmc.log(
            f"Aegis tvhub: EPG too large ({len(content)} bytes); skipping",
            xbmc.LOGWARNING,
        )
        return None

    xbmc.log(
        f"Aegis tvhub: fetched EPG {source.id} ({len(content)} bytes)",
        xbmc.LOGINFO,
    )
    return content
