"""Parse m3u playlists into Channel records."""
import re
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Channel:
    """A parsed m3u channel entry."""

    tvg_id: Optional[str] = None
    tvg_name: Optional[str] = None
    tvg_logo: Optional[str] = None
    group_title: Optional[str] = None
    stream_url: str = ""
    raw_attrs: dict = None  # unparsed extinction attributes
    source_id: Optional[str] = None  # which source this channel came from
    # Lower-priority duplicates of this channel found during dedup, in descending
    # preference. Used by merge._write_m3u to emit a tv_play cascade URL so a
    # CDN-throttled primary (e.g., jmp2.uk Pluto rate limit) automatically falls
    # through to an iptv-org or alternate-provider copy without user action.
    alternate_urls: List[str] = field(default_factory=list)
    # Known-degraded URLs kept as an ABSOLUTE-last-resort cascade tail, tried
    # only after every real primary/alternate has failed. Populated when the
    # Pluto canary nulls a channel's stream_url during a dead-region window:
    # the stitcher URL is probably serving filler right now, but (a) an
    # individual channel may still be live even when the region canary tripped,
    # and (b) the plugin's play-time deep-probe rejects filler anyway, so a
    # genuinely-dead URL just falls through to an honest toast instead of a
    # crash. Kept SEPARATE from alternate_urls so a channel with only
    # last_resort URLs (Pluto-only, canary-dead) is still skipped from the guide
    # by _write_m3u — we only append these behind at least one real URL.
    last_resort_urls: List[str] = field(default_factory=list)

    def __post_init__(self):
        if self.raw_attrs is None:
            self.raw_attrs = {}
        # Defensive: dataclass default_factory covers normal construction, but
        # channels built by **dict-splat from adapters that predate this field
        # can arrive with the attr unset on older pickled cache entries.
        if getattr(self, "last_resort_urls", None) is None:
            self.last_resort_urls = []


def parse_m3u(content: bytes) -> List[Channel]:
    """
    Parse m3u playlist into Channel records.

    Args:
        content: Raw m3u bytes (UTF-8 assumed)

    Returns:
        List of Channel instances
    """
    try:
        text = content.decode("utf-8", errors="replace")
    except Exception:
        return []

    lines = text.split("\n")
    channels = []
    i = 0

    while i < len(lines):
        line = lines[i].rstrip()

        if line.startswith("#EXTINF"):
            # Parse the EXTINF line
            extinf_attrs = _parse_extinf(line)

            # Next non-empty line should be the stream URL
            i += 1
            while i < len(lines) and not lines[i].strip():
                i += 1

            if i < len(lines):
                stream_url = lines[i].strip()
                if stream_url:
                    # Fall back to the post-comma display name (canonical m3u) when
                    # the source didn't supply a quoted tvg-name attribute.
                    tvg_name = extinf_attrs.get("tvg-name") or extinf_attrs.get("_display_name")
                    # iptv-org tvg-id encodes country as "<name>.<cc>@<quality>";
                    # derive the country code so we can group by country in the merged
                    # output. Channels with no country fall back to source group_title.
                    country = _country_from_tvg_id(extinf_attrs.get("tvg-id"))
                    group = country.upper() if country else extinf_attrs.get("group-title")
                    channel = Channel(
                        tvg_id=extinf_attrs.get("tvg-id"),
                        tvg_name=tvg_name,
                        tvg_logo=extinf_attrs.get("tvg-logo"),
                        group_title=group,
                        stream_url=stream_url,
                        raw_attrs=extinf_attrs,
                    )
                    channels.append(channel)

        i += 1

    return channels


def _parse_extinf(line: str) -> dict:
    """
    Parse #EXTINF line into attributes.

    Format: #EXTINF:-1 tvg-id="..." tvg-name="..." tvg-logo="..." group-title="...",...

    Returns:
        Dict of attributes (tvg-id, tvg-name, tvg-logo, group-title, etc.)
    """
    attrs = {}

    # Extract all quoted attributes: key="value"
    pattern = r'(\w+(?:-\w+)*)="([^"]*)"'
    for match in re.finditer(pattern, line):
        key = match.group(1)
        value = match.group(2)
        attrs[key] = value

    # Canonical m3u puts the channel display name after the LAST comma on the
    # EXTINF line. iptv-org follows this convention. Store it as _display_name
    # so the caller can fall back to it when no tvg-name attr is present.
    last_comma = line.rfind(",")
    if last_comma >= 0:
        display_name = line[last_comma + 1 :].strip()
        if display_name:
            attrs["_display_name"] = display_name

    return attrs


# iptv-org encodes the country in tvg-id as ".<cc>@" (e.g., "1KZNTV.za@SD").
# This regex captures that country code so we can group channels by country.
_TVG_ID_COUNTRY = re.compile(r"\.([a-z]{2})@", re.IGNORECASE)


def _country_from_tvg_id(tvg_id):
    """Extract 2-letter country code from an iptv-org tvg-id; None if no match."""
    if not tvg_id:
        return None
    match = _TVG_ID_COUNTRY.search(tvg_id)
    return match.group(1).lower() if match else None
