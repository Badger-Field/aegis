"""Live-TV dedup engine with cascade-preserving alternates."""
import re
from typing import List

import xbmc

try:
    from .parse import Channel
except (ImportError, ValueError):
    from parse import Channel


# Network-brand prefixes safe to strip for dedup matching: the content name
# after the prefix is what identifies the channel ("MTV Jersey Shore" and
# "Jersey Shore" are the same show on two Pluto channel IDs). Kept narrow on
# purpose — broader prefixes like "BBC " or "FOX " would over-merge
# real-distinct channels (BBC News vs BBC One; FOX News vs FOX Sports).
_DEDUP_PREFIXES = (
    "mtv ",
    "vh1 ",
    "pluto tv ",
    "samsung tv plus ",
)

# Channel-name suffixes safe to strip — quality markers, time-zone feeds,
# and generic "always-on" indicators. Anything that varies between provider
# copies of the same channel but doesn't change the content.
_DEDUP_SUFFIXES = (
    " 4k",
    " hd",
    " fhd",
    " (1080p)",
    " (720p)",
    " (480p)",
    " 24/7",
    " east",
    " west",
    " central",
    " mountain",
    " pacific",
)


def _norm(name: str) -> str:
    """
    Normalize a channel name for dedup matching.

    - lowercase
    - strip common network-brand prefixes (`MTV `, `VH1 `, `Pluto TV `,
      `Samsung TV Plus `) so per-network variants of the same content
      dedup together — e.g., "MTV Jersey Shore" + "Jersey Shore" both
      become "jersey shore". Conservative list; see `_DEDUP_PREFIXES`.
    - strip common quality/region suffixes (`HD`, `(1080p)`, `East`,
      `West`, `24/7`, ...). See `_DEDUP_SUFFIXES`.
    - collapse whitespace
    """
    if not name:
        return ""

    name = name.lower().strip()

    # Strip a leading brand prefix only when something non-trivial remains
    # (>= 4 chars AND contains at least one letter). Without the letter
    # check, names like "MTV 1234" would collapse to "1234" — losing the
    # network identity entirely. Without the length check, "MTV" alone
    # would collapse to "" and every brand-only channel would merge.
    for prefix in _DEDUP_PREFIXES:
        if name.startswith(prefix):
            remainder = name[len(prefix):].strip()
            if len(remainder) >= 4 and any(c.isalpha() for c in remainder):
                name = remainder
                break

    # Suffix strip: keep looping in case multiple apply (e.g. "Foo HD East").
    changed = True
    while changed:
        changed = False
        for suffix in _DEDUP_SUFFIXES:
            if name.endswith(suffix):
                name = name[: -len(suffix)].rstrip()
                changed = True
                break

    # Collapse whitespace
    name = re.sub(r"\s+", " ", name).strip()

    return name


def _attach_alternate(winner: Channel, loser: Channel, cap: int = 4) -> None:
    """Fold loser's URLs onto the winner: real URLs (stream_url + alternates)
    into winner.alternate_urls, and known-degraded URLs into
    winner.last_resort_urls. Both deduped and capped.

    The last-resort merge runs even when the loser has an empty stream_url —
    a canary-nulled Pluto channel carries its stitcher URL in last_resort_urls
    and we must not lose it just because its primary was nulled.
    """
    # Real-URL merge: loser's primary, then its alternates.
    if loser.stream_url and loser.stream_url != winner.stream_url:
        if loser.stream_url not in winner.alternate_urls and len(winner.alternate_urls) < cap:
            winner.alternate_urls.append(loser.stream_url)
    # Also pull in the loser's own alternates so a transitive cascade chain works
    # (e.g., if loser was already a tvg-id dedup winner with its own alternates).
    for url in loser.alternate_urls:
        if url and url != winner.stream_url and url not in winner.alternate_urls and len(winner.alternate_urls) < cap:
            winner.alternate_urls.append(url)
    # Last-resort merge: always (independent of loser.stream_url being empty).
    for url in list(loser.last_resort_urls):
        if (
            url
            and url != winner.stream_url
            and url not in winner.alternate_urls
            and url not in winner.last_resort_urls
            and len(winner.last_resort_urls) < cap
        ):
            winner.last_resort_urls.append(url)


def dedupe(
    channels: List[Channel],
    source_priority_order: List[str],
) -> List[Channel]:
    """
    Deduplicate channels by tvg-id, then by normalized name.

    Losers don't disappear — their stream URLs are kept on the winner as
    alternate_urls. The merge writer then emits a tv_play plugin URL that
    cascades through them on playback failure (e.g., if Pluto's stitcher
    rate-limits the IP, the channel automatically falls through to Plex,
    Samsung, or an iptv-org direct-CDN copy).

    Args:
        channels: list of Channel instances (may have duplicates across sources)
        source_priority_order: list of source IDs in descending priority

    Returns:
        Deduplicated channel list. Each surviving channel may carry up to 4
        alternate_urls in priority order.
    """
    priority_map = {src_id: i for i, src_id in enumerate(source_priority_order)}

    def _get_priority(channel: Channel) -> tuple:
        priority = priority_map.get(channel.source_id, 9999)
        has_hd_in_id = 1 if "hd" in (channel.tvg_id or "").lower() else 0
        has_hd_in_url = 1 if any(kw in channel.stream_url.lower() for kw in ["1080", "hd", "hls8"]) else 0
        return (priority, -has_hd_in_id, -has_hd_in_url)

    # Pass 1: tvg-id dedup. Losers attach as alternates on the winner.
    pass1_winners: List[Channel] = []
    channels_by_tvg = {}
    for ch in channels:
        if not ch.tvg_id:
            continue
        channels_by_tvg.setdefault(ch.tvg_id, []).append(ch)

    for tvg_id, group in channels_by_tvg.items():
        sorted_group = sorted(group, key=_get_priority)
        winner = sorted_group[0]
        for loser in sorted_group[1:]:
            _attach_alternate(winner, loser)
            xbmc.log(
                "Aegis tvhub: dedup tvg-id={}: kept {} from {}, kept-as-alternate from {}".format(
                    tvg_id,
                    winner.tvg_name,
                    winner.source_id or "?",
                    loser.source_id or "?",
                ),
                xbmc.LOGDEBUG,
            )
        pass1_winners.append(winner)

    # Pass 2: name-based dedup across the Pass-1 winners. The FAST aggregators
    # (Pluto / Samsung / Plex) emit different tvg-ids for the SAME logical
    # channel (e.g., "LiveNOW from FOX" appears 4× with different ids). Without
    # this pass the user sees one entry per provider and clicks at random.
    # Sort by priority first so each name's incumbent is the best candidate and
    # subsequent losers attach as alternates in priority-descending order — the
    # cascade in plugin.video.aegis tries alternates left-to-right.
    pass1_winners.sort(key=_get_priority)
    by_name = {}
    no_name_entries: List[Channel] = []
    for ch in pass1_winners:
        norm_name = _norm(ch.tvg_name or "")
        if not norm_name:
            no_name_entries.append(ch)
            continue
        existing = by_name.get(norm_name)
        if existing is None:
            by_name[norm_name] = ch
            continue
        # Pick lower-priority-key as winner, attach the loser's URL+alternates.
        ranked = sorted((existing, ch), key=_get_priority)
        winner, loser = ranked[0], ranked[1]
        _attach_alternate(winner, loser)
        by_name[norm_name] = winner
        xbmc.log(
            "Aegis tvhub: dedup name={}: kept {} from {} (+{} alternates), folded {} from {}".format(
                norm_name,
                winner.tvg_name,
                winner.source_id or "?",
                len(winner.alternate_urls),
                loser.tvg_name,
                loser.source_id or "?",
            ),
            xbmc.LOGINFO,
        )

    # Fold in channels parsed without any tvg-id that haven't been seen by name.
    for ch in channels:
        if ch.tvg_id:
            continue
        norm_name = _norm(ch.tvg_name or "")
        if not norm_name:
            no_name_entries.append(ch)
            continue
        if norm_name not in by_name:
            by_name[norm_name] = ch

    return list(by_name.values()) + no_name_entries
