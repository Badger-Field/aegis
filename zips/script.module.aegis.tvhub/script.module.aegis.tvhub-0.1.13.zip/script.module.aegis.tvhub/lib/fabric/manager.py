"""Live TV Source Fabric manager with cache-backed fallback."""
import re
from datetime import datetime, timezone
from pathlib import Path

import xbmc

from .cache import ProviderCache
from .health import evaluate_m3u
from .status_writer import write_status

# Captures `url-tvg="..."` or `x-tvg-url="..."` (both seen in the wild) from
# the `#EXTM3U` header line. We restrict the search to the first non-empty
# line to avoid spurious matches inside EXTINF attribute strings further down.
_URL_TVG_RE = re.compile(r'\b(?:url-tvg|x-tvg-url)="([^"]+)"')


# url-tvg lives only in the #EXTM3U header (always the first non-empty
# line of an m3u). 1 KB is more than enough to capture that line for any
# realistic playlist — header attributes are usually < 200 chars — while
# bounding memory + CPU. Full-file playlists routinely run multiple MB,
# and decoding them just to inspect a single attribute is wasted work.
_URL_TVG_HEADER_SNIFF_BYTES = 1024


def _extract_url_tvg(payload: bytes) -> str:
    """Return the first url-tvg / x-tvg-url URL declared in an m3u's
    `#EXTM3U` header, or "" if absent. Sources that ship a header hint
    (iptv-org/iptv, BuddyChewChew/Roku, many community FAST aggregators)
    let us pick up EPG without a hardcoded config entry — important
    because each new source otherwise silently joins as no-EPG.

    Only the first `_URL_TVG_HEADER_SNIFF_BYTES` of the payload is
    decoded — the header is always on the first non-blank line, so
    decoding multi-MB playlists in full just to inspect a single
    attribute would be a needless allocation hit.
    """
    if not payload:
        return ""
    # Slice before decoding so we never allocate a multi-MB str for a
    # multi-MB playlist. errors="ignore" keeps the header readable even
    # if downstream bytes are mojibake'd.
    snippet = payload[:_URL_TVG_HEADER_SNIFF_BYTES]
    try:
        text = snippet.decode("utf-8", errors="ignore")
    except Exception:
        return ""
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith("#EXTM3U"):
            match = _URL_TVG_RE.search(line)
            if match:
                # A single header line can list multiple URLs separated by
                # commas (per the de-facto convention); take the first.
                return match.group(1).split(",")[0].strip()
        # Stop after the first non-blank line — url-tvg lives only in the
        # `#EXTM3U` header, never on a later line.
        return ""
    return ""

try:
    from ..adapters.custom_m3u_xmltv import CustomM3UXMLTVAdapter
    from ..adapters.fast_playlist import FastPlaylistAdapter
    from ..adapters.iptv_org import IPTVOrgAdapter
except (ImportError, ValueError):
    from adapters.custom_m3u_xmltv import CustomM3UXMLTVAdapter
    from adapters.fast_playlist import FastPlaylistAdapter
    from adapters.iptv_org import IPTVOrgAdapter


class FabricManager:
    """Coordinates provider adapters, cache fallback, and status output."""

    def __init__(self, registry, session, output_dir: Path):
        self.registry = registry
        self.session = session
        self.output_dir = output_dir
        self.cache = ProviderCache(output_dir / "cache")
        self.status_path = output_dir / "source_status.json"

    def collect_channels(self):
        """Collect channels from enabled providers with cache fallback."""
        all_channels = []
        errors = []
        statuses = []

        for source in self.registry.get_enabled():
            adapter = self._adapter_for(source)
            provider = adapter.provider_name
            now = _now_iso()
            status = {
                "name": source.id,
                "provider": provider,
                "status": "healthy",
                "channels": 0,
                "epg_match_percent": 0,
                "last_success": None,
                "warnings": [],
                # url-tvg discovered from the m3u header — `merge()` falls
                # back to this when the source's own epg_url is unset, so
                # iptv-org/Roku-style playlists that ship their EPG hint
                # inline don't need a hardcoded mirror entry.
                "discovered_epg_url": "",
            }

            try:
                adapter.validate(source)
                payload, channels = adapter.fetch_channels(source, self.session)
                health = evaluate_m3u(payload)
                if not health["valid_header"]:
                    raise ValueError("m3u header missing #EXTM3U")
                if health["extinf_count"] <= 0:
                    raise ValueError("m3u contains no #EXTINF entries")

                for ch in channels:
                    ch.source_id = source.id
                    ch.raw_attrs["source"] = source.id
                all_channels.extend(channels)
                self.cache.save_m3u(source.id, payload)
                status["discovered_epg_url"] = _extract_url_tvg(payload)

                status["status"] = "healthy"
                status["channels"] = len(channels)
                status["last_success"] = now
            except Exception as exc:
                cached = self.cache.load_m3u(source.id)
                if cached:
                    try:
                        payload, channels = self._parse_cached(source.id, cached)
                        all_channels.extend(channels)
                        status["status"] = "degraded"
                        status["channels"] = len(channels)
                        status["warnings"].append("fetch failed, using cache: {}".format(exc))
                        status["discovered_epg_url"] = _extract_url_tvg(payload)
                    except Exception as cache_exc:
                        status["status"] = "unavailable"
                        status["warnings"].append("cache parse failed: {}".format(cache_exc))
                        errors.append((source.id, str(exc)))
                else:
                    status["status"] = "unavailable"
                    status["warnings"].append("fetch failed and no cache: {}".format(exc))
                    errors.append((source.id, str(exc)))

                xbmc.log(
                    "Aegis tvhub fabric: source={} status={} reason={}".format(
                        source.id, status["status"], exc
                    ),
                    xbmc.LOGWARNING,
                )

            statuses.append(status)

        write_status(self.status_path, statuses)
        return all_channels, statuses, errors

    def _parse_cached(self, source_id: str, payload: bytes):
        try:
            from ..parse import parse_m3u
        except (ImportError, ValueError):
            from parse import parse_m3u
        channels = parse_m3u(payload)
        for ch in channels:
            ch.source_id = source_id
            ch.raw_attrs["source"] = source_id
        return payload, channels

    def _adapter_for(self, source):
        if source.kind == "disabled":
            return CustomM3UXMLTVAdapter()

        if source.kind in ("fast_m3u", "fast_url") or source.id.startswith("fast-"):
            return FastPlaylistAdapter()

        if source.id.startswith("iptv-org-"):
            return IPTVOrgAdapter()

        return CustomM3UXMLTVAdapter()


def _now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()
