"""Internal models for Live TV Source Fabric."""
from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class NormalizedChannel:
    """Canonical channel model used across provider adapters."""

    id: str
    name: str
    provider: str
    region: str
    stream_url: str
    epg_id: Optional[str] = None
    logo: Optional[str] = None
    groups: List[str] = field(default_factory=list)
    headers: Dict[str, str] = field(default_factory=dict)
    source_priority: int = 50
    reliability_score: float = 0.0
    epg_match_score: float = 0.0
    last_seen: Optional[str] = None
    last_success: Optional[str] = None
    last_failure: Optional[str] = None
    failure_reason: Optional[str] = None


@dataclass
class ProviderStatus:
    """Runtime health/status snapshot for UI and diagnostics."""

    name: str
    provider: str
    status: str
    channels: int
    epg_match_percent: int
    last_success: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
