"""Provider cache for last-known-good source payloads."""
from pathlib import Path


def _safe_key(source_id: str) -> str:
    return "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in source_id)


class ProviderCache:
    """Stores last-known-good source payloads for degraded fallback."""

    def __init__(self, root_dir: Path):
        self.root_dir = root_dir
        self.root_dir.mkdir(parents=True, exist_ok=True)

    def _m3u_path(self, source_id: str) -> Path:
        return self.root_dir / ("{}_channels.m3u".format(_safe_key(source_id)))

    def save_m3u(self, source_id: str, payload: bytes) -> None:
        self._m3u_path(source_id).write_bytes(payload)

    def load_m3u(self, source_id: str):
        path = self._m3u_path(source_id)
        if not path.exists():
            return None
        try:
            return path.read_bytes()
        except Exception:
            return None
