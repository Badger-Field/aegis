"""Health checks for source payload validation."""


def evaluate_m3u(payload: bytes) -> dict:
    """Run basic payload validation and return health details."""
    text = payload.decode("utf-8", errors="replace") if payload else ""
    lines = text.splitlines()
    extinf_count = sum(1 for line in lines if line.startswith("#EXTINF"))
    return {
        "valid_header": text.lstrip().startswith("#EXTM3U"),
        "extinf_count": extinf_count,
        "syntactic_url_ratio": _stream_url_ratio(lines),
    }


def _stream_url_ratio(lines) -> float:
    urls = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        urls.append(line)
    if not urls:
        return 0.0
    valid = 0
    for url in urls:
        if url.startswith("http://") or url.startswith("https://") or url.startswith("pvr://"):
            valid += 1
    return float(valid) / float(len(urls))
