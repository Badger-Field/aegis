"""Writes provider status JSON for Kodi skin/UI."""
import json
from pathlib import Path


def write_status(path: Path, statuses) -> None:
    payload = {
        "sources": statuses,
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
