"""Provider adapter interface for Live TV Source Fabric."""
from abc import ABC, abstractmethod


class ProviderAdapter(ABC):
    """Common interface implemented by all source adapters."""

    @abstractmethod
    def fetch_channels(self, source, session):
        """Return (raw_bytes, parsed_channels)."""

    @abstractmethod
    def fetch_epg(self, source, session):
        """Return EPG payload bytes or None."""

    @abstractmethod
    def validate(self, source):
        """Raise when source configuration is invalid."""

    @abstractmethod
    def get_health(self, source):
        """Return provider health metadata dict."""

    @abstractmethod
    def get_metadata(self, source):
        """Return provider metadata dict for diagnostics/UI."""
