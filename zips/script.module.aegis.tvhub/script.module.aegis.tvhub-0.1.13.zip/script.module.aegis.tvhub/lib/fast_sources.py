"""FAST channel (Pluto TV / Samsung TV+ / Plex) live-TV source configuration.

These sources point at the BuddyChewChew/app-m3u-generator daily-CI playlists,
which expose stream URLs as jmp2.uk redirectors that re-sign Pluto/Samsung/Plex
JWTs on every play. This gives ~99% uptime per-channel compared to iptv-org's
~50% rot from third-party rebroadcasters.

Systemic risk: the entire FAST aggregation ecosystem depends on jmp2.uk
remaining online and BuddyChewChew continuing daily CI. Both are single points
of failure; if either goes away these sources break wholesale, but iptv-org
remains as the breadth fallback.
"""
from typing import Dict, List

FAST_PROVIDERS = {
    # `priority_bias` orders FAST providers on dedup conflict (higher wins).
    # Pluto's edge (siloh.pluto.tv) has consistently responded to jmp2.uk redirects
    # from US residential IPs in our testing. Samsung's edge (pb-*.akamaized.net)
    # gates with aggressive anti-bot heuristics that 403 even with correct headers,
    # so we demote it: when Pluto and Samsung both publish the same channel name,
    # the user gets the Pluto copy in the merged playlist.
    "pluto": {
        "label": "Pluto TV",
        "url_template": "https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/plutotv_{region}.m3u",
        "epg_template": "https://i.mjh.nz/PlutoTV/{region}.xml.gz",
        "regions": {"us", "ca", "gb", "de", "fr", "mx", "br", "es", "it", "ar", "cl", "dk", "no", "se"},
        "priority_bias": 20,
    },
    "plex": {
        "label": "Plex",
        "url_template": "https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/plex_{region}.m3u",
        "epg_template": "https://i.mjh.nz/Plex/{region}.xml.gz",
        "regions": {"us", "ca", "gb", "au", "mx", "fr", "es"},
        "priority_bias": 10,
    },
    "samsung": {
        "label": "Samsung TV+",
        "url_template": "https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/samsungtvplus_{region}.m3u",
        "epg_template": "https://i.mjh.nz/SamsungTVPlus/{region}.xml.gz",
        "regions": {"us", "ca", "gb", "de", "fr", "es", "it", "in"},
        "priority_bias": 0,
    },
    # Roku and Tubi only publish a single _all.m3u (no per-region split) so we
    # pull them once regardless of selected_regions. They broaden sports
    # coverage (Roku Channel sports FAST tier; Tubi news/sports). priority_bias
    # is between Plex (10) and Samsung (0) — Roku/Tubi streams are more stable
    # than Samsung's anti-bot-gated edge but less so than Plex's.
    "roku": {
        "label": "The Roku Channel",
        "url_template": "https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/roku_all.m3u",
        # mjh.nz publishes the Roku EPG at the same pattern as Pluto/Samsung/Plex.
        # The Roku playlist's own #EXTM3U header advertises this URL as `url-tvg=`;
        # we hardcode it here for parity with the other FAST providers (the
        # auto-discovery fallback in fabric.manager._extract_url_tvg covers any
        # future source that ships a header hint without our own config entry).
        "epg_template": "https://i.mjh.nz/Roku/all.xml.gz",
        "regions": {"all"},
        "priority_bias": 5,
        "region_invariant": True,
    },
    "tubi": {
        "label": "Tubi TV",
        "url_template": "https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/tubi_all.m3u",
        # Tubi EPG ships in the BuddyChewChew repo itself (tubi_epg.xml), not on mjh.nz.
        "epg_template": "https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/tubi_epg.xml",
        "regions": {"all"},
        "priority_bias": 5,
        "region_invariant": True,
    },
}

# Our region keys → BuddyChewChew region codes. iptv-org uses "uk", BuddyChewChew
# uses ISO "gb"; we map at this seam so the firstrun region-selection UI keeps
# one consistent set of labels. Regions absent from this map ("jp", "world")
# have no FAST mapping — channels fall back to iptv-org for those regions.
REGION_KEY_TO_PROVIDER_CODE = {
    "us": "us",
    "ca": "ca",
    "uk": "gb",
    "de": "de",
    "fr": "fr",
    "mx": "mx",
    "br": "br",
    "in": "in",
    "au": "au",
}

# Higher than iptv-org (30) so FAST wins dedup conflicts — these streams are
# more reliable than iptv-org's rebroadcasters for the same channel.
FAST_DEFAULT_PRIORITY = 80


def get_fast_sources(selected_regions: List[str]) -> List[Dict]:
    """
    Build Source dicts for FAST channel providers covering selected regions.

    For each selected region with a known provider mapping, emit one Source
    per FAST provider that publishes a playlist for that region.

    Args:
        selected_regions: list of region keys (us, uk, ca, de, fr, mx, br, in, au, jp, world)

    Returns:
        list of Source dicts ready for SourceRegistry.upsert
    """
    sources = []
    region_invariant_emitted: set = set()
    for region_idx, region_key in enumerate(selected_regions):
        provider_code = REGION_KEY_TO_PROVIDER_CODE.get(region_key)

        for provider_id, cfg in FAST_PROVIDERS.items():
            # Region-invariant providers (Roku, Tubi) publish one global playlist.
            # Emit them exactly once across all selected regions.
            if cfg.get("region_invariant"):
                if provider_id in region_invariant_emitted:
                    continue
                region_invariant_emitted.add(provider_id)
                sources.append({
                    "id": f"fast-{provider_id}",
                    "kind": "url_m3u",
                    "url": cfg["url_template"],
                    "enabled": True,
                    "priority": FAST_DEFAULT_PRIORITY + cfg.get("priority_bias", 0) + 100,
                    "commit_pin": None,
                    "region_filter": None,
                    "epg_url": cfg.get("epg_template"),
                })
                continue

            if not provider_code or provider_code not in cfg["regions"]:
                continue
            sources.append({
                "id": f"fast-{provider_id}-{region_key}",
                "kind": "url_m3u",
                "url": cfg["url_template"].format(region=provider_code),
                "enabled": True,
                # priority = base + provider-reliability bias + region-selection-order bias.
                # The provider bias (20/10/0 for pluto/plex/samsung) means dedup picks the
                # most reliable provider when the same channel name appears in multiple.
                "priority": FAST_DEFAULT_PRIORITY + cfg.get("priority_bias", 0) + (100 - region_idx),
                "commit_pin": None,
                "region_filter": region_key,
                "epg_url": cfg["epg_template"].format(region=provider_code) if cfg.get("epg_template") else None,
            })
    return sources
