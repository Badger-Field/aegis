"""Live-TV source registry and management."""
from dataclasses import asdict, dataclass
from typing import List, Optional


@dataclass
class Source:
    """A live-TV m3u/EPG source."""

    id: str  # e.g., "iptv-org-global", "iptv-org-us", "famelack", "user-custom"
    kind: str  # "git_m3u", "url_m3u", "url_epg" — not all sources have all kinds
    url: str  # m3u or EPG URL
    enabled: bool = True
    priority: int = 50  # higher = higher priority (user-supplied ~100, regional ~30, global ~20)
    commit_pin: Optional[str] = None  # for git_m3u: 40-char SHA commit; required for git sources
    epg_url: Optional[str] = None  # optional XMLTV EPG URL
    region_filter: Optional[str] = None  # e.g., "us", "world" — for labeling/filtering


class SourceRegistry:
    """Manages a collection of live-TV sources stored in vault."""

    VAULT_KEY = "tv.sources"

    def __init__(self, vault_store):
        """
        Initialize registry with a vault store.
        
        Args:
            vault_store: aegis_vault.VaultStore instance
        """
        self.vault = vault_store

    def load(self) -> List[Source]:
        """Load all sources from vault."""
        try:
            data = self.vault.read()
        except Exception:
            return []

        sources_json = data.get(self.VAULT_KEY, [])
        if not isinstance(sources_json, list):
            return []

        sources = []
        for item in sources_json:
            if isinstance(item, dict):
                try:
                    src = Source(**item)
                    sources.append(src)
                except TypeError:
                    # Ignore malformed entries
                    pass
        return sources

    def save(self, sources: List[Source]) -> None:
        """Save all sources to vault."""
        try:
            data = self.vault.read()
        except Exception:
            data = {}

        data[self.VAULT_KEY] = [asdict(src) for src in sources]
        self.vault.write(data)

    def add(self, source: Source) -> None:
        """Add or update a source by id."""
        sources = self.load()
        sources = [s for s in sources if s.id != source.id]
        sources.append(source)
        self.save(sources)

    # `upsert` is the semantic name used by service.aegis.firstrun's L6 region
    # selection step. Live-test on 2026-05-17 surfaced AttributeError: 'SourceRegistry'
    # has no 'upsert'. Aliased to add() (which already has add-or-update behavior)
    # so both names work without breaking existing call sites or tests.
    upsert = add

    def remove(self, source_id: str) -> None:
        """Remove a source by id."""
        sources = self.load()
        sources = [s for s in sources if s.id != source_id]
        self.save(sources)

    def get_enabled(self) -> List[Source]:
        """Get all enabled sources, sorted by priority (descending)."""
        sources = [s for s in self.load() if s.enabled]
        return sorted(sources, key=lambda s: s.priority, reverse=True)

    def get_by_id(self, source_id: str) -> Optional[Source]:
        """Get a source by id."""
        for src in self.load():
            if src.id == source_id:
                return src
        return None
