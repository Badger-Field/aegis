"""Aegis Live-TV Hub — sources, fetcher, parser, dedup, merge, and source fabric."""

try:
	from .fabric.manager import FabricManager
except Exception:
	FabricManager = None
