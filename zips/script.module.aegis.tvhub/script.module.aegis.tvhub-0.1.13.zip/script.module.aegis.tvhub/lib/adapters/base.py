"""Adapter base implementations."""

try:
    from ..fabric.interfaces import ProviderAdapter
except (ImportError, ValueError):
    from fabric.interfaces import ProviderAdapter


class BaseAdapter(ProviderAdapter):
    """Shared default methods for M3U-backed adapters."""

    provider_name = "generic"

    def fetch_epg(self, source, session):
        if not getattr(source, "epg_url", None):
            return None
        try:
            from ..fetch import fetch_epg
        except (ImportError, ValueError):
            from fetch import fetch_epg
        return fetch_epg(source, session)

    def get_health(self, source):
        return {
            "provider": self.provider_name,
            "enabled": bool(getattr(source, "enabled", False)),
        }

    def get_metadata(self, source):
        return {
            "id": getattr(source, "id", ""),
            "provider": self.provider_name,
            "kind": getattr(source, "kind", ""),
            "region": getattr(source, "region_filter", None),
        }
