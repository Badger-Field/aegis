"""Adapter for iptv-org sources."""

try:
    from .custom_m3u_xmltv import CustomM3UXMLTVAdapter
except (ImportError, ValueError):
    from custom_m3u_xmltv import CustomM3UXMLTVAdapter


class IPTVOrgAdapter(CustomM3UXMLTVAdapter):
    provider_name = "iptv_org"
