"""Adapter for FAST (free ad-supported TV) playlists.

Routed when source.id starts with 'fast-' or source.kind is in ('fast_m3u',
'fast_url'). Inherits CustomM3UXMLTVAdapter for fetch+parse and specialises
two things:

  1. Diagnostic metadata so status output identifies the FAST sub-provider
     (pluto / samsung / plex) instead of a generic "custom_m3u" label.

  2. Pluto URL rewriting. BuddyChewChew's m3u-generator emits Pluto stream
     URLs as `https://jmp2.uk/plu-<channel_id>.m3u8`, but in June 2026
     jmp2.uk's `plu-` route started returning Cloudflare 404 — Samsung's
     `stvp-` route on the same redirector kept working. We rewrite Pluto
     URLs to call Pluto's stitcher directly, bypassing the jmp2.uk
     middleman entirely. The stitcher returns a real HLS master playlist
     when given the required `appVersion` query param.
"""
import math
import random
import re
import urllib.error
import urllib.parse
import urllib.request
import uuid

import xbmc

try:
    from .custom_m3u_xmltv import CustomM3UXMLTVAdapter
except (ImportError, ValueError):
    from custom_m3u_xmltv import CustomM3UXMLTVAdapter


# Direct Pluto stitcher template. Path tells Pluto we want an embed-mode
# HLS master (no client-side ad insertion handshake, no boot.pluto.tv
# session — the stitcher handles SSAI server-side based on the device
# params we pass in the query string). `appVersion=na` is the magic
# string that satisfies the stitcher's "missing plutotv-app-version"
# rejection without making us look like a specific Pluto client version
# that might get rate-limited.
_PLUTO_STITCHER_BASE = "https://stitcher-ipv4.pluto.tv/v1/stitch/embed/hls/channel/{channel_id}/master.m3u8"

# Stable per-process UUID used to populate the stitcher `sid` query
# param (as `sid=WEB-{uuid}`) so successive merges within one Kodi
# session look like the same web client rather than a new identity
# on every run. The merge runs every ~30 min in production so this
# becomes effectively per-session. Despite the historical "device +
# client id" framing, this single UUID only feeds `sid` — other
# device fields (`deviceMake`, `deviceModel`, `deviceVersion`, etc.)
# are hardcoded literals in `_build_pluto_stitcher_url`.
_PLUTO_DEVICE_UUID = str(uuid.uuid4())

# Matches `https://jmp2.uk/plu-<channel_id>(.m3u8)?(?…query)?(|…headers)?`
# with the channel id captured. The optional `?…` query string AND the
# optional `|…` pipe-header tail are both consumed by the match so the
# substitution produces a clean stitcher URL — both are DISCARDED, the
# rewrite builds a fresh URL from the stitcher template + our device
# params.
#
# Pipe-header consumption is a security-defence: if an upstream playlist
# (or an attacker-controlled middleman) shipped a Pluto URL with
# `|User-Agent=...&Origin=...`, leaving the tail attached to the rewritten
# URL would forward attacker-controlled headers into our stitcher fetch
# AND produce an invalid `stitcher-ipv4.pluto.tv/...|...` URL that
# CurlFile would mis-parse. Consuming the tail drops the attacker headers
# AND yields a clean stitcher URL. The playback path applies its own
# Pluto Origin/Referer via `classify_stream(url)` at resolve time, so
# discarding the upstream-provided ones loses nothing legitimate.
#
# The query-string class is `[^\s|]*` (excluding pipe) so a URL like
# `…?token=…|User-Agent=…` partitions cleanly: the query stops at `|`
# and the pipe-header alternation picks up the rest.
#
# If the upstream generator ever starts attaching semantically-meaningful
# query params (or pipe headers), this rewrite would need to forward
# them — at which point both the regex and the substitution need
# updating, not just the regex.
_JMP2_PLUTO_RE = re.compile(
    r"https?://jmp2\.uk/plu-([A-Za-z0-9]+)(?:\.m3u8)?(?:\?[^\s|]*)?(?:\|[^\s]*)?",
    re.IGNORECASE,
)


def _build_pluto_stitcher_url(channel_id: str) -> str:
    """Return a direct Pluto stitcher master URL for `channel_id`.

    All required device params are baked in as query string args so the
    URL is self-contained — no headers needed for the rewrite itself
    (the existing Origin/Referer Pluto headers from PR #19 still apply
    at playback time because `classify_stream(url)` matches "pluto" on
    these too via the stitcher PATH `pluto.tv/v1/stitch/` — the match
    is anchored on the path, not the bare host, so `images.pluto.tv/...`
    logo URLs in tvg-logo attrs don't accidentally pick up stream
    headers).
    """
    # Minimum param set the stitcher will accept without 400-ing. As of
    # 2026-06-01 the endpoint enforces, in order of discovery via the
    # "missing X header or Y query param" probe loop:
    #   - appVersion
    #   - deviceDNT
    #   - deviceModel
    #   - deviceVersion
    #   - deviceMake
    #   - deviceType
    #   - sid  (session id; without it the endpoint says "sid is not
    #           coercible". A random UUID with the WEB- prefix that the
    #           web app uses is accepted server-side.)
    #
    # Anything missing → 400. The stitcher serves takedown filler
    # regardless of values when there's no real session/cookie context
    # (we don't bootstrap one), but a 200 is required for the cascade
    # probe to even attempt the deep-probe filler-detection that lets
    # the cascade fall through to Samsung/Plex alternates. A 400 here
    # would short-circuit to "candidate failed" without ever giving
    # the alternates a turn.
    #
    # URL length stays around 230 chars — well under the ~1000-char
    # plugin-URL truncation threshold observed when 5 candidates were
    # bundled via the previous 520-char form.
    base = _PLUTO_STITCHER_BASE.format(channel_id=channel_id)
    sid = "WEB-{}".format(_PLUTO_DEVICE_UUID)
    return (
        base + "?appVersion=na&deviceDNT=0"
        "&deviceModel=na&deviceVersion=na&deviceMake=na&deviceType=web"
        "&sid=" + sid
    )


def rewrite_pluto_urls(payload: bytes) -> bytes:
    """Rewrite every `jmp2.uk/plu-<id>` URL in an m3u to call Pluto's
    stitcher directly.

    Applied at the payload-bytes level so it runs once per source fetch
    rather than per channel in the parser. Non-Pluto URLs are
    untouched. Returns the rewritten payload; the caller's parser sees
    the new URLs without knowing the rewrite happened.

    If the payload doesn't decode as UTF-8, return it unchanged — the
    parser will likely fail anyway, and we don't want to mask the real
    failure with a silently-empty rewrite.
    """
    try:
        text = payload.decode("utf-8")
    except UnicodeDecodeError:
        return payload

    def _sub(match):
        return _build_pluto_stitcher_url(match.group(1))

    rewritten = _JMP2_PLUTO_RE.sub(_sub, text)
    if rewritten == text:
        return payload
    return rewritten.encode("utf-8")


# Sampled markers Pluto's stitcher serves when it won't grant us real
# content (no session, no rights, geo-restricted, etc.). Same constants
# the cascade deep-probe uses — keep them in sync. The substring scan
# runs against both #EXT-X-KEY URIs and segment URIs in the variant
# manifest body.
_PLUTO_FILLER_MARKERS = (
    "_ptv_takedownslates_",
    "pluto_help_we_will_be_right_back",
)

# Canary probe budget + decision rule.
#
# Empirical Pluto takedown rate (latest observation 2026-06-05):
# about ~80% of randomly sampled Pluto channels return
# `_ptv_takedownslates_` filler, ~20% return real content. That's
# softened from the late-May 2026 observation when CA was 100%
# filler (20/20 random samples 2026-06-01); rights restored on some
# channels in early June.
#
# Sample size 5 keeps the canary cheap — each probe is 2 HTTP
# requests (master + first variant) so 5 channels = ~10 requests =
# ~5-8 sec at typical Pluto stitcher latency.
_PLUTO_CANARY_SAMPLE_SIZE = 5
# Threshold 1.0 (UNANIMOUS) — a single playable channel in the
# random sample keeps the region alive. We started at 0.8 (4/5) on
# the late-May 100%-filler assumption, but against the current 80%
# rate that threshold fires DEAD ~74% of refreshes (binomial CDF)
# so playable Pluto-only channels get nulled in most refreshes and
# disappear from the user's guide inconsistently between merges.
#
# At 1.0 the canary only fires DEAD when EVERY sampled channel is
# filler (probability ~0.8^5 = 33% at the current 80% rate) —
# strong signal Pluto has actually nuked the region. The cascade-
# time deep-probe in plugin.video.aegis/default.py::_probe_cascade (PR #24's
# takedown-filler detection) is the real per-play content guard:
# if a Pluto channel happens to be filler at play time the cascade
# falls through to alternates or surfaces the "filler" toast. The
# canary's job is to prune obviously-dead regions, not to be the
# per-channel filler checker — that's substantially per-channel
# probing work we'll do in a follow-up PR (cached at the merge
# layer so per-refresh latency stays low).
_PLUTO_CANARY_FILLER_THRESHOLD = 1.0
_PLUTO_PROBE_TIMEOUT_SEC = 6
# Cap how much of each manifest we read — 32 KB covers any real master
# or variant playlist while bounding memory if the stitcher decides to
# stream us a runaway response.
_PLUTO_PROBE_MAX_BYTES = 32 * 1024

# Custom redirect handler — gates each redirect hop against the host
# allow-list BEFORE following. `urllib.request.urlopen`'s default
# behaviour is to follow 3xx silently and only let the caller see the
# final URL via `resp.geturl()`. That makes the allow-list a post-hoc
# decision: the attacker fetch has already happened by the time the
# caller validates. This handler intercepts each hop in the redirect
# chain and refuses to follow off-domain Location headers, so the
# allow-list becomes a real network boundary.
#
# Pluto's stitcher legitimately 302s between subdomains (e.g.
# cfd-v4-... → stitcher-ipv4-...) — both still under `*.pluto.tv`, so
# the allow-list passes and the redirect chain proceeds normally.
class _PlutoAllowListRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not _is_pluto_probe_url_safe(newurl):
            raise urllib.error.HTTPError(
                req.full_url, code,
                "redirect off-domain refused by Pluto canary allow-list",
                headers, fp,
            )
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_PLUTO_PROBE_OPENER = urllib.request.build_opener(_PlutoAllowListRedirectHandler())


# Default Pluto headers — kept consistent with stream_headers.headers_for_url
# so the probe sees the same gating context the playback path will.
_PLUTO_PROBE_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Origin": "https://pluto.tv",
    "Referer": "https://pluto.tv/",
}

# Allow-list for the canary probe. FAST playlists are fetched from the
# network — a compromised upstream could embed `file:///`, `ftp://`, or
# `data:` URLs (or a cross-host probe target) to make Kodi's process
# fetch local files or arbitrary hosts during the merge.
#
# Scheme policy is HTTPS-ONLY to match `aegis_netguard.GuardedSession`
# (which rejects any non-https request). Allowing `http://pluto.tv/...`
# would let a compromised upstream playlist downgrade canary probes to
# plaintext, which is a real attack vector for a public Wi-Fi
# adversary even though Pluto's real stitcher only serves HTTPS.
#
# Host policy locks to *.pluto.tv so an attacker can't redirect probes
# elsewhere by replacing stitcher URLs in their m3u.
#
# Same allow-list is applied to BOTH the master URL we're given AND
# the variant URL we discover by parsing the master body — the
# variant URL is attacker-influenced (master body is downloaded over
# the wire) so it gets the same gating as the entry point.
_PLUTO_ALLOWED_HOST_SUFFIX = ".pluto.tv"


def _is_pluto_probe_url_safe(url):
    """Allow-list gate for canary probes. See `_PLUTO_ALLOWED_HOST_SUFFIX`."""
    # Strict type gate: `urlparse` raises `TypeError`/`AttributeError`
    # on non-str inputs (None, bytes, int, etc.) — defensive allow-list
    # gates must reject anything non-str upfront so a bad input can't
    # crash the canary probe loop. Aligns with the docstring promise
    # of "False on any parse error" and matches `_is_pluto_stitcher_url`.
    if not isinstance(url, str):
        return False
    try:
        parsed = urllib.parse.urlparse(url)
    except (ValueError, TypeError):
        return False
    # HTTPS-only — matches GuardedSession's policy. See the comment
    # above _PLUTO_ALLOWED_HOST_SUFFIX for the downgrade-attack rationale.
    if parsed.scheme != "https":
        return False
    host = (parsed.hostname or "").lower()
    if not host:
        return False
    # `endswith` plus the leading dot in the suffix prevents the
    # `not-pluto.tv.attacker.com` bypass that a bare `pluto.tv` substring
    # check would allow.
    return host == "pluto.tv" or host.endswith(_PLUTO_ALLOWED_HOST_SUFFIX)


def _pluto_url_is_filler(stream_url):
    """Probe a single Pluto stitcher URL.

    Returns True iff the resolved variant manifest contains one of the
    known takedown / filler clip markers (see `_PLUTO_FILLER_MARKERS`).

    Returns False — i.e. "not classifiable as filler, treat as playable
    for canary purposes" — when:
      - the master or variant URL fails the host/scheme allow-list,
      - the HTTP fetch errors out (DNS/timeout/non-200),
      - or the master has no variant URL we can follow.

    The conservative-False bias on errors keeps a single bad response
    from tipping a healthy region into "skip" mode.
    """
    if not _is_pluto_probe_url_safe(stream_url):
        return False
    try:
        req = urllib.request.Request(stream_url, headers=_PLUTO_PROBE_HEADERS)
        with _PLUTO_PROBE_OPENER.open(req, timeout=_PLUTO_PROBE_TIMEOUT_SEC) as resp:
            if resp.getcode() != 200:
                return False
            master_body = resp.read(_PLUTO_PROBE_MAX_BYTES).decode("utf-8", errors="ignore")
            master_final_url = resp.geturl() if hasattr(resp, "geturl") else stream_url
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError):
        return False

    # Re-gate after redirects — the stitcher 302s us between Pluto
    # subdomains (e.g. cfd-v4-... → stitcher-ipv4-...), all still under
    # *.pluto.tv, but a compromised middleman could redirect off-domain.
    if not _is_pluto_probe_url_safe(master_final_url):
        return False

    # Inline media playlist (no `#EXT-X-STREAM-INF`): the master IS the
    # media playlist, so segment URIs sit on its non-tag lines. The
    # filler markers (which appear in `_ptv_takedownslates_` segment
    # paths) are already in master_body — no variant follow-up needed.
    # The previous always-treat-first-non-tag-line-as-variant logic
    # would have fetched a `.ts` segment and missed filler detection
    # since segments don't include the marker substring in their own
    # bodies. The cascade deep-probe in plugin.video.aegis uses the
    # same EXT-X-STREAM-INF presence check.
    if "#EXT-X-STREAM-INF" not in master_body:
        lowered_inline = master_body.lower()
        return any(marker in lowered_inline for marker in _PLUTO_FILLER_MARKERS)

    # Master playlist: walk to the first variant URL. Per HLS spec the
    # variant URL is the first non-tag, non-blank line after a
    # `#EXT-X-STREAM-INF` tag.
    variant_url = None
    in_stream_inf = False
    for line in master_body.splitlines():
        stripped = line.strip()
        if stripped.startswith("#EXT-X-STREAM-INF"):
            in_stream_inf = True
            continue
        if not in_stream_inf or not stripped or stripped.startswith("#"):
            continue
        variant_url = urllib.parse.urljoin(master_final_url, stripped)
        break
    if not variant_url:
        # No variant → can't classify. Conservative: don't flag as filler.
        return False
    # Variant URL is derived from the master body which is fetched over
    # the wire — re-apply the same allow-list so a compromised master
    # can't redirect the variant fetch to `file:///etc/passwd` or
    # another host.
    if not _is_pluto_probe_url_safe(variant_url):
        return False

    try:
        req = urllib.request.Request(variant_url, headers=_PLUTO_PROBE_HEADERS)
        with _PLUTO_PROBE_OPENER.open(req, timeout=_PLUTO_PROBE_TIMEOUT_SEC) as resp:
            if resp.getcode() != 200:
                return False
            variant_body = resp.read(_PLUTO_PROBE_MAX_BYTES).decode("utf-8", errors="ignore")
            variant_final_url = resp.geturl() if hasattr(resp, "geturl") else variant_url
    except (urllib.error.URLError, urllib.error.HTTPError, OSError, ValueError):
        return False

    # Re-gate after redirects — same defence as the master fetch above.
    # A `*.pluto.tv` variant URL that 302s to an attacker-controlled
    # host would otherwise let us evaluate (and trust the
    # filler-marker scan of) a third-party response body. The body has
    # already arrived by the time we get here, but discarding it
    # before the substring scan keeps the canary's decision honest:
    # filler markers can only declare a region dead via real Pluto
    # responses, not attacker injection.
    if not _is_pluto_probe_url_safe(variant_final_url):
        return False

    lowered = variant_body.lower()
    return any(marker in lowered for marker in _PLUTO_FILLER_MARKERS)


def _pluto_region_is_dead(channels):
    """Canary probe. Sample N channels from a parsed Pluto source; if
    enough of them serve takedown filler, declare the region dead and
    return True so the caller can drop the source for this refresh.

    `channels` is a list of parsed Channel objects from the FAST m3u
    after rewrite, so `ch.stream_url` is already the direct stitcher
    URL we'd ship into merged.m3u.
    """
    playable_candidates = [ch for ch in channels if getattr(ch, "stream_url", "")]
    if not playable_candidates:
        return False
    sample_size = min(_PLUTO_CANARY_SAMPLE_SIZE, len(playable_candidates))
    sample = random.sample(playable_candidates, sample_size)

    # Each probe does 2 HTTP requests (master + variant) and each can
    # take up to _PLUTO_PROBE_TIMEOUT_SEC seconds. Naïvely iterating
    # all 5 samples sequentially gives a worst-case ~60s merge stall.
    # Short-circuit in BOTH directions to cut AVERAGE-case latency —
    # the worst case is unchanged (still 5 probes when the outcome is
    # genuinely undecided until the last sample, e.g. needed=4/5 and
    # the first 4 yield 3 filler + 1 real, the 5th decides it):
    #   - Once we've seen enough filler hits to cross the threshold,
    #     declare DEAD and stop probing.
    #   - Once the remaining un-probed samples can't push the filler
    #     count over the threshold even if they ALL filler, declare
    #     OK and stop probing.
    # `needed` is the integer ceiling of (threshold * sample_size) so
    # the comparison stays in int-land and isn't sensitive to floating
    # point drift on the boundary.
    needed = math.ceil(_PLUTO_CANARY_FILLER_THRESHOLD * sample_size)
    filler_count = 0
    for i, ch in enumerate(sample, start=1):
        if _pluto_url_is_filler(ch.stream_url):
            filler_count += 1
            if filler_count >= needed:
                break
        remaining = sample_size - i
        if filler_count + remaining < needed:
            break
    is_dead = filler_count >= needed
    xbmc.log(
        "Aegis fast_playlist: pluto canary {}/{} returned filler "
        "(threshold {:.0%}; region {})".format(
            filler_count,
            sample_size,
            _PLUTO_CANARY_FILLER_THRESHOLD,
            "DEAD" if is_dead else "OK",
        ),
        xbmc.LOGINFO if not is_dead else xbmc.LOGWARNING,
    )
    return is_dead


class FastPlaylistAdapter(CustomM3UXMLTVAdapter):
    provider_name = "fast_playlist"

    def _load_payload(self, source, session):
        # Intercept the payload between fetch and parse so the parent's
        # single parse_m3u() pass sees the rewritten URLs directly — no
        # double-parse. Only the pluto sub-provider needs the rewrite:
        # Samsung (stvp-) and Plex (plex-) still work through jmp2.uk.
        payload = super()._load_payload(source, session)
        sid = getattr(source, "id", "")
        if sid.startswith("fast-pluto"):
            payload = rewrite_pluto_urls(payload)
        return payload

    def fetch_channels(self, source, session):
        # Canary probe for Pluto sources. Pluto's CA stitcher (and
        # potentially others) has been observed serving takedown filler
        # for ~100% of channels — even featured ones, even with a fully
        # bootstrapped session and the right Origin/Referer. When that
        # happens, every Pluto candidate in the cascade will return
        # 200+filler, get rejected by the deep-probe, and the cascade
        # falls back to whatever Samsung/Plex alternates exist. For
        # Pluto-only channels there's no alternate so the user gets the
        # "filler" toast and a dead channel.
        #
        # The canary samples a few channels post-rewrite and, if a
        # supermajority return filler, "drops" the source by KEEPING the
        # channel metadata (tvg-id, tvg-name, tvg-logo, group-title) and
        # nulling each `ch.stream_url`. Downstream dedup folds the
        # metadata-only entries into Samsung/Plex/iptv-org alternates by
        # name — the winning entry inherits Pluto's tvg-id (highest
        # priority bias) so the user's PVR favorites and EPG references
        # stay stable across availability changes, while the cascade
        # only carries the working alternate URLs. _write_m3u below
        # then skips any channel that ends up with no URLs at all, so
        # Pluto-only channels with no Samsung/Plex copy still vanish
        # from the guide instead of appearing as "play me — oh wait,
        # never mind".
        payload, channels = super().fetch_channels(source, session)
        sid = getattr(source, "id", "")
        if sid.startswith("fast-pluto") and channels:
            if _pluto_region_is_dead(channels):
                # Identity-preserving "drop": keep the channel metadata
                # (tvg_id, tvg_name, tvg_logo, group_title) but null the
                # stream URL. Downstream dedup folds these into Samsung /
                # Plex alternates by name — the surviving entry keeps
                # Pluto's tvg-id (highest priority) so the user's PVR
                # favorites and EPG references stay stable across
                # availability changes, while the cascade only carries
                # the working Samsung/Plex URLs.
                #
                # _write_m3u skips channels that end up with no URLs at
                # all (Pluto-only with no alternate), so dead Pluto-only
                # channels still vanish from the user's guide.
                xbmc.log(
                    "Aegis fast_playlist: nulling stream URLs on {} Pluto "
                    "channels from {} (stitcher serving filler; metadata "
                    "kept for dedup identity, URL kept as last-resort cascade "
                    "tail)".format(len(channels), sid),
                    xbmc.LOGWARNING,
                )
                for ch in channels:
                    # Stash the (probably-filler-right-now) stitcher URL as a
                    # last-resort before nulling the primary. Dedup folds these
                    # onto the surviving entry so a multi-source channel (e.g.
                    # CNN Headlines = Pluto + Plex) keeps a Pluto fallback behind
                    # its Plex URL instead of collapsing to a single fragile URL.
                    # A Pluto-ONLY channel still ends up with no real URL and is
                    # skipped from the guide by _write_m3u (unchanged behaviour).
                    if ch.stream_url and ch.stream_url not in ch.last_resort_urls:
                        ch.last_resort_urls.append(ch.stream_url)
                    ch.stream_url = ""
        return payload, channels

    def get_metadata(self, source):
        meta = super().get_metadata(source)
        meta["provider"] = self.provider_name
        sid = getattr(source, "id", "")
        if sid.startswith("fast-"):
            parts = sid.split("-", 2)
            if len(parts) >= 2:
                meta["fast_provider"] = parts[1]
        return meta
