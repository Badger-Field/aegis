"""Provider adapters for Live TV Source Fabric."""
