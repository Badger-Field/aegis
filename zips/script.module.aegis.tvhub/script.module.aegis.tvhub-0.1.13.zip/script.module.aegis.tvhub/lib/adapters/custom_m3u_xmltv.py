"""Adapter for user-provided and generic M3U/XMLTV sources."""
from pathlib import Path

try:
    from .base import BaseAdapter
except (ImportError, ValueError):
    from base import BaseAdapter


class CustomM3UXMLTVAdapter(BaseAdapter):
    provider_name = "custom_m3u_xmltv"

    # URL-based kinds that this adapter (and its FastPlaylistAdapter
    # subclass) accepts. All share the same constraint: `source.url`
    # must be a non-empty str. `fast_m3u` / `fast_url` are routed here
    # via `FabricManager._adapter_for`, which selects FastPlaylistAdapter
    # for those kinds — without listing them here, that adapter's
    # inherited `validate` would reject otherwise-valid configs and
    # FabricManager would fall the source back to cache/unavailable.
    _URL_KINDS = ("url_m3u", "git_m3u", "fast_m3u", "fast_url")

    def validate(self, source):
        kind = getattr(source, "kind", "")
        url = getattr(source, "url", "")
        if kind in self._URL_KINDS:
            if not isinstance(url, str) or not url:
                raise ValueError("{} source requires URL".format(kind))
        elif kind == "file_m3u":
            if not isinstance(url, str) or not url:
                raise ValueError("file_m3u source requires local path")
            if not Path(url).exists():
                raise ValueError("file_m3u source path not found: {}".format(url))
        else:
            raise ValueError("Unsupported source kind for custom adapter: {}".format(kind))

    def _load_payload(self, source, session):
        """Fetch (or read from disk) the raw m3u bytes for `source`.

        Split out so subclasses can intercept the payload between fetch
        and parse — e.g. FastPlaylistAdapter rewrites Pluto URLs here.
        """
        kind = getattr(source, "kind", "")
        if kind == "file_m3u":
            return Path(source.url).read_bytes()
        try:
            from ..fetch import fetch_m3u
        except (ImportError, ValueError):
            from fetch import fetch_m3u
        return fetch_m3u(source, session)

    def fetch_channels(self, source, session):
        payload = self._load_payload(source, session)
        try:
            from ..parse import parse_m3u
        except (ImportError, ValueError):
            from parse import parse_m3u
        channels = parse_m3u(payload)
        return payload, channels
