"""Per-provider HTTP headers for FAST stream URLs.

Different FAST CDNs gate playback on different User-Agent / Origin / Referer
combinations:

- Pluto TV uses a Chrome UA but also requires pluto.tv Origin/Referer —
  without them the stitcher serves a "We'll be right back" filler loop
  to clients it can't identify as the first-party web app.
- Samsung TV+'s segment edge (cloudfront) 403s a generic Chrome UA;
  Samsung's Tizen TV UA + samsungtvplus.com Origin/Referer passes the
  gate.
- Plex Live auths via the X-Plex-Token query param but some endpoints
  reject without an app.plex.tv Origin.
- Tubi accepts Chrome UA but wants tubitv.com Origin/Referer to look
  like the official web app.
- iptv-org direct streams are mixed; default Chrome UA with no extras
  is the safest default for "unknown".

This module is the single source of truth used by:
- script.module.aegis.tvhub.merge — bakes headers into #KODIPROP lines for
  direct (non-cascade) entries in merged.m3u
- plugin.video.aegis._route_tv_play — sets headers on the resolved item for
  cascade entries (mirrored inline to avoid cross-addon import at runtime)

Keep the two copies in sync — the test suite verifies provider classification
on both sides.
"""
from typing import Dict
from urllib.parse import quote, urlparse

_PROVIDER_UA = {
    "samsung": (
        "Mozilla/5.0 (SMART-TV; LINUX; Tizen 5.0) AppleWebKit/537.36 "
        "(KHTML, like Gecko) 73.0.3683.103 SamsungBrowser/9.1 LFD Safari/537.36"
    ),
    # Default desktop Chrome — used by Pluto, Tubi, Plex, and unknown providers.
    "default": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
}

_PROVIDER_EXTRA_HEADERS: Dict[str, Dict[str, str]] = {
    # Pluto's stitcher serves a "We'll be right back" filler loop (looks like
    # a 30s promo on repeat) to clients it can't recognize as the first-party
    # web app. The fallback fires when SSAI ad slicing fails for an unknown
    # client. Matching pluto.tv's Origin/Referer makes the stitcher treat us
    # as the web app and serve real channel content instead of the filler.
    # Reference: other working Pluto Kodi scrapers (e.g.
    # olavopeixoto/plugin.video.brplay) explicitly pass pluto.tv-style
    # context; without it the same channels degrade to the filler loop.
    "pluto": {
        "Origin": "https://pluto.tv",
        "Referer": "https://pluto.tv/",
    },
    "samsung": {
        "Origin": "https://www.samsungtvplus.com",
        "Referer": "https://www.samsungtvplus.com/",
    },
    "plex": {
        "Origin": "https://app.plex.tv",
        "Referer": "https://app.plex.tv/",
    },
    "tubi": {
        "Origin": "https://tubitv.com",
        "Referer": "https://tubitv.com/",
    },
    # Roku Channel FAST streams. Live capture 2026-06-09 18:20:47 showed
    # Roku channels (jmp2.uk/rok-...) routing through inputstream.adaptive
    # by default and hitting the same `SESSION::OnSegmentChanged: Cannot
    # get the stream sample reader` crash that Plex Live did — adaptive
    # 21.5.18 can't navigate Roku's HLS period changes either. Routing
    # through ffmpegdirect (see _route_tv_play classifier branch) lets
    # ffmpeg's HLS demuxer handle discontinuities cleanly.
    "roku": {
        "Origin": "https://therokuchannel.roku.com",
        "Referer": "https://therokuchannel.roku.com/",
    },
}


def _is_pluto_stitcher_url(url: str) -> bool:
    """True iff `url` is an http(s) request to `*.pluto.tv` (or apex
    `pluto.tv`) whose path starts with the stitcher prefix
    `/v1/stitch/`.

    Uses `urlparse` so the hostname is extracted structurally and
    can't be spoofed by an attacker putting `pluto.tv` somewhere in
    the path or query string. Returns False on any parse error or
    non-http(s) scheme so a malformed URL doesn't grant Pluto
    classification.
    """
    # Strict type gate: `urlparse` raises `TypeError`/`AttributeError`
    # on non-str inputs (None, bytes, int, etc.) — and a `ParseResultBytes`
    # from a bytes input would have a bytes `scheme`/`path` and break the
    # str-vs-str comparisons below in subtler ways. Reject upfront so the
    # rest of this function is a clean str-only path. Aligns with the
    # docstring promise of "False on any parse error" and matches the
    # plugin-side mirror behaviour.
    if not isinstance(url, str):
        return False
    try:
        parsed = urlparse(url)
    except (ValueError, TypeError):
        return False
    if parsed.scheme not in ("http", "https"):
        return False
    host = (parsed.hostname or "").lower()
    if not (host == "pluto.tv" or host.endswith(".pluto.tv")):
        return False
    return parsed.path.lower().startswith("/v1/stitch/")


def classify_stream(url: str) -> str:
    """Classify a stream URL into a provider key for header selection.

    Returns one of: "pluto", "samsung", "plex", "tubi", "unknown".

    Both jmp2.uk/plex- (the redirector form used by FAST aggregation and our
    tvhub dedup output) and the direct provider.plex.tv host get classified
    as "plex" so they pick up the same Origin/Referer headers.

    The direct Pluto stitcher (`stitcher-ipv4.pluto.tv/v1/stitch/...`,
    used after the jmp2.uk `plu-` rewrite landed in
    `adapters.fast_playlist`) is also classified as "pluto" so it picks
    up the same Origin/Referer headers — the stitcher's SSAI loop is
    just as sensitive to those as the jmp2.uk-redirected form was.

    Pluto stitcher match uses a real URL parse — `urlparse` extracts
    the hostname, and we check both (a) the hostname is `pluto.tv` or
    a subdomain (`*.pluto.tv`) AND (b) the path starts with the
    stitcher prefix (`/v1/stitch/`). Both conditions together rule out:
      - Non-stream Pluto resources (`images.pluto.tv/channels/...`
        channel logos): right host, wrong path.
      - Substring-collision attacks where the attacker puts
        `pluto.tv/v1/stitch/` somewhere in the URL path
        (`https://attacker.example/.pluto.tv/v1/stitch/...` or
        `https://notpluto.tv/v1/stitch/...`): wrong host, regardless
        of path contents.
    Parsing-based matching is the only safe way to do this — any
    substring approach loses on at least one of these classes.
    """
    # Defensive: caller may pass None, bytes, or other non-str (e.g.
    # `getattr(source, "stream_url", None)` returning None, or a stale
    # bytes payload that wasn't decoded). Treat anything non-str as
    # unclassifiable rather than letting `.lower()` / `in` raise.
    if not isinstance(url, str) or not url:
        return "unknown"
    lowered = url.lower()
    if "jmp2.uk/plu-" in lowered:
        return "pluto"
    if _is_pluto_stitcher_url(url):
        return "pluto"
    if "jmp2.uk/stvp-" in lowered:
        return "samsung"
    if "jmp2.uk/plex-" in lowered or "provider.plex.tv" in lowered:
        return "plex"
    # tubi.io / tubitv.com are the VOD + app domains; Tubi's LIVE channels are
    # served from the CSM stitcher on *.tubi.video (master on
    # csm-*.csm.tubi.video, segments on *.tubi.video). Without matching
    # tubi.video, live Tubi classified as "unknown" and fell through to
    # inputstream.adaptive, which crashed on Tubi's yospace SCTE-35
    # #EXT-X-DISCONTINUITY ad-splices (CVideoPlayerVideo::OutputPicture timeout
    # after a resync-backward storm — kodi.exe crash 2026-08-01 19:59).
    if "tubi.io" in lowered or "tubitv.com" in lowered or "tubi.video" in lowered:
        return "tubi"
    # Roku Channel FAST: `jmp2.uk/rok-...` is the redirector form the
    # BuddyChewChew Roku playlist publishes. We don't (yet) have a
    # direct-stitcher form for Roku the way Pluto has `stitcher-ipv4.pluto.tv`,
    # so the redirector substring is the only signal. If Roku ever ships a
    # direct CDN URL we'd need to add it here the same way Pluto did.
    if "jmp2.uk/rok-" in lowered:
        return "roku"
    return "unknown"


def headers_for_url(url: str) -> Dict[str, str]:
    """Return the {header_name: header_value} dict to send for `url`."""
    provider = classify_stream(url)
    ua = _PROVIDER_UA.get(provider, _PROVIDER_UA["default"])
    headers: Dict[str, str] = {"User-Agent": ua}
    headers.update(_PROVIDER_EXTRA_HEADERS.get(provider, {}))
    return headers


# ffmpeg AVDictionary options (NOT HTTP headers) that ride along the
# Kodi pipe-tail when a URL is routed through inputstream.ffmpegdirect.
# ffmpegdirect's `GetFFMpegOptionsFromInput` (src/stream/FFmpegStream.cpp
# @2280-2410) inspects each pipe-tail key and, for these specific names,
# calls `av_dict_set` on the ffmpeg options dict instead of appending an
# HTTP header. The names match its allowlist verbatim — `seekable`,
# `reconnect`, `reconnect_at_eof`, `reconnect_streamed`,
# `reconnect_delay_max`, and a few ICY/cookie-decryption keys we don't
# need here.
#
# Why we need these: Samsung TV+ is HLS over MPEG-TS. Transient
# segment-fetch errors (CDN edge 503, momentary TCP reset) need to
# be retried in-band instead of bubbling EOF up to ffmpegdirect and
# triggering a full demuxer re-init. `reconnect=1` plus
# `reconnect_streamed=1` together make libavformat's HTTP layer
# retry on transient errors even for non-seekable streams (which
# live HLS is). `reconnect_delay_max=1` caps the retry backoff at
# 1s — earlier we ran 5s and live capture 2026-06-05 22:25:36
# showed audio drift growing to -1342s because the 5s window let
# video continue from buffer while audio had nothing.
#
# NOTE: `reconnect_at_eof=1` is INTENTIONALLY ABSENT.
#
# That option exists for live single-URL streams where EOF on the
# underlying connection is unexpected and should trigger a retry of
# the same URL. HLS is the opposite shape: each segment is a
# separate file that NORMALLY EOFs when it finishes, and the HLS
# demuxer is responsible for moving on to the next segment via the
# variant playlist. `reconnect_at_eof=1` makes libavformat retry
# the same just-finished segment URL instead, which competes with
# the demuxer's next-segment fetch and (with `reconnect_delay_max=1`)
# fails after one second. Live capture 2026-06-06 00:49:02 showed
# Kodi re-initing the stream exactly at segment duration boundaries
# (~10s into playback) — too short to be SCTE-35 ad-break.
#
# ffmpeg docs (https://ffmpeg.org/ffmpeg-protocols.html#http) are
# explicit: "If set then eof is treated like an error and causes
# reconnection, this is useful for live / endless streams."
# i.e. it's for streams where EOF is unexpected, not for HLS where
# segment EOF is the normal end of a segment file.
#
# NOTE: `seekable=0` was added 2026-06-05 in PR #32 and immediately
# regressed playback (instant EOF after master parse). The option
# propagates through ffmpeg's `AV_OPT_SEARCH_CHILDREN` to the HLS
# demuxer itself, breaking its master→variant navigation. Pinned
# absent in tests so we don't re-add it.
_FFMPEG_RECONNECT_OPTS: Dict[str, str] = {
    "reconnect": "1",
    "reconnect_streamed": "1",
    "reconnect_delay_max": "1",
}


def ffmpegdirect_pipe_options(url: str) -> Dict[str, str]:
    """Return ffmpeg AVDictionary options to merge into the pipe-tail
    when `url` is routed through inputstream.ffmpegdirect.

    Provider-agnostic for now (Samsung is the only ffmpegdirect-routed
    provider as of PR #27); per-URL signature kept so future providers
    can override without a caller-site change.
    """
    return dict(_FFMPEG_RECONNECT_OPTS)


def kodi_header_string(headers: Dict[str, str]) -> str:
    """Format header dict for inputstream.adaptive.{manifest,stream}_headers.

    inputstream.adaptive expects `Key=Value&Key2=Value2` with URL-encoded
    values. Keys are not encoded (header names never contain reserved chars).
    """
    return "&".join("{}={}".format(k, quote(v, safe="")) for k, v in headers.items())


def kodi_pipe_header_url(url: str, headers: Dict[str, str]) -> str:
    """Append HTTP headers to a URL using Kodi's pipe-separator syntax.

    inputstream.ffmpegdirect doesn't expose separate manifest/stream
    header properties (the way inputstream.adaptive does); instead it
    relies on Kodi's own `CurlFile` extension where headers are
    URL-encoded after a `|` separator:

        https://host/master.m3u8|User-Agent=Foo&Origin=https%3A%2F%2Fa.com

    The kodi_header_string format is the same on both sides — just
    glued onto the URL here rather than set as separate properties.
    Returns the URL unchanged if `headers` is empty so the caller can
    keep a single code path for "headers or no headers".

    Idempotency: if `url` already carries a pipe tail (an upstream
    helper or aggregator decorated it once), merge `headers` into the
    existing tail rather than appending a second `|`. CurlFile only
    parses ONE pipe segment — a `url|...|...` shape silently drops
    the second header set. New keys win over existing ones on
    conflict (defensive choice: the explicit headers argument is the
    caller's "current" intent).
    """
    if not headers:
        return url
    base, sep, existing_tail = url.partition("|")
    if not sep:
        # No existing pipe tail — clean case.
        return "{}|{}".format(base, kodi_header_string(headers))
    # Merge: parse existing tail, layer new headers on top.
    merged: Dict[str, str] = {}
    for chunk in existing_tail.split("&"):
        if not chunk or "=" not in chunk:
            continue
        k, _, v = chunk.partition("=")
        # Values in the existing tail are URL-encoded — unquote so the
        # round-trip through kodi_header_string re-encodes consistently
        # and doesn't double-encode (`%20` becoming `%2520`).
        merged[k] = _unquote_header_value(v)
    merged.update(headers)
    return "{}|{}".format(base, kodi_header_string(merged))


def _unquote_header_value(encoded: str) -> str:
    """URL-decode a pipe-tail header value. Centralised so the
    decode/encode pair in `kodi_pipe_header_url` stays consistent —
    `kodi_header_string` uses `urllib.parse.quote(value, safe="")`
    so the inverse is `urllib.parse.unquote`."""
    from urllib.parse import unquote
    return unquote(encoded)
