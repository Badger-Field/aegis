from __future__ import annotations

import ast
import re
from pathlib import Path

DANGEROUS_CALLS = {"eval", "exec", "compile"}
INSECURE_URL_MARKER = "http://"
NETWORK_MODULES = {"requests", "urllib", "urllib3", "http"}
EXECUTEBUILTIN_DANGEROUS = {"UpdateAddonRepos", "UpdateLocalAddons"}


class Finding:
    def __init__(self, path: Path, line: int, code: str, message: str):
        self.path = path
        self.line = line
        self.code = code
        self.message = message

    def __str__(self) -> str:
        return "{}:{} [{}] {}".format(self.path.as_posix(), self.line, self.code, self.message)


def _source_has_insecure_url(source: str) -> bool:
    """
    Detect HTTP URLs in source, with filtering for docstrings/comments.
    Flags http:// in code strings (not in comments or docstrings).
    Ignores documentation links and license headers.
    """
    lines = source.split('\n')
    in_multiline_docstring = False
    
    for _line_no, line in enumerate(lines, start=1):
        stripped = line.strip()
        
        # Track multiline docstrings (with proper count tracking)
        if '"""' in line:
            triple_count = line.count('"""')
            if triple_count % 2 == 1:
                in_multiline_docstring = not in_multiline_docstring
        
        # Skip lines in multiline docstrings
        if in_multiline_docstring:
            continue
        
        # Skip comment-only lines
        stripped_no_comment = stripped.split('#')[0].strip()
        if not stripped_no_comment or stripped.startswith('#'):
            continue
        
        # If the line has http:// in the code part (before any comment), flag it
        code_part = line.split('#')[0]
        if "http://" in code_part:
            return True
    
    return False


def _is_literal(node: ast.expr) -> bool:
    """Check if an AST node is a literal value."""
    return isinstance(node, (ast.Str, ast.Constant, ast.Bytes))


def _iter_calls(tree: ast.AST):
    """Iterate over all Call nodes in the AST."""
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            yield node


def _iter_imports_at_module_level(tree: ast.Module) -> list[tuple[str, int]]:
    """Get all module-level imports (not nested in functions)."""
    imports = []
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append((alias.name, node.lineno))
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.append((node.module, node.lineno))
    return imports


def _is_network_call_at_module_level(tree: ast.Module) -> list[Finding]:
    """Detect network calls at module import time (not in functions)."""
    findings = []
    network_call_names = {"request", "get", "post", "put", "delete", "urlopen", "HTTPConnection"}
    
    for node in tree.body:
        # Skip function/class definitions
        if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.AsyncFunctionDef)):
            continue
        
        # Collect all calls from this top-level node
        calls_to_check = []
        
        if isinstance(node, ast.Expr):
            # Direct call expression: requests.get(...)
            if isinstance(node.value, ast.Call):
                calls_to_check.append((node.value, node.lineno))
        elif isinstance(node, ast.Assign):
            # Assignment with call: response = requests.get(...)
            if isinstance(node.value, ast.Call):
                calls_to_check.append((node.value, node.lineno))
        
        # Check each call
        for call, lineno in calls_to_check:
            if isinstance(call.func, ast.Attribute):
                if call.func.attr in network_call_names:
                    findings.append(Finding(
                        Path("dummy"),
                        lineno,
                        "AEGIS006",
                        f"Network call '{call.func.attr}' at module import time (may block/hang)"
                    ))
            elif isinstance(call.func, ast.Name):
                if call.func.id in network_call_names:
                    findings.append(Finding(
                        Path("dummy"),
                        lineno,
                        "AEGIS006",
                        f"Network call '{call.func.id}' at module import time"
                    ))
    
    return findings


def _detect_base64_exec_flow(tree: ast.AST) -> list[Finding]:
    """
    Detect base64.b64decode(...) whose result is passed to exec/compile.
    Pattern: exec(base64.b64decode(...)) or similar obfuscation.
    Also handles intermediate assignments: code = base64.b64decode(...); exec(code)
    """
    findings = []
    
    # First, find all variables that hold base64.b64decode results
    base64_vars = set()
    
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            # Check if this is an assignment like: var = base64.b64decode(...)
            if isinstance(node.value, ast.Call):
                if isinstance(node.value.func, ast.Attribute):
                    if node.value.func.attr == "b64decode":
                        # Record this variable as holding base64 data
                        for target in node.targets:
                            if isinstance(target, ast.Name):
                                base64_vars.add(target.id)
    
    # Now check for exec/compile calls with base64 results
    for call in _iter_calls(tree):
        func = call.func
        
        # Check if this is a call to exec/compile
        if isinstance(func, ast.Name) and func.id in ("exec", "compile"):
            # Check if any argument is a base64 call or base64 variable
            for arg in call.args:
                if isinstance(arg, ast.Call):
                    if isinstance(arg.func, ast.Attribute):
                        if arg.func.attr == "b64decode":
                            findings.append(Finding(
                                Path("dummy"),
                                call.lineno,
                                "AEGIS003",
                                "Base64 decode result passed to exec/compile (obfuscation pattern)"
                            ))
                elif isinstance(arg, ast.Name) and arg.id in base64_vars:
                    findings.append(Finding(
                        Path("dummy"),
                        call.lineno,
                        "AEGIS003",
                        "Variable holding base64 result passed to exec/compile"
                    ))
    
    return findings


def _detect_import_with_non_literal(tree: ast.AST) -> list[Finding]:
    """
    Detect __import__ with non-literal module names.
    Pattern: __import__(variable_name) or __import__(some_function())
    """
    findings = []
    
    for call in _iter_calls(tree):
        func = call.func
        if isinstance(func, ast.Name) and func.id == "__import__":
            # Check if the first argument is not a literal
            if call.args and not _is_literal(call.args[0]):
                findings.append(Finding(
                    Path("dummy"),
                    call.lineno,
                    "AEGIS004",
                    "__import__ with non-literal argument (dynamic imports)"
                ))
    
    return findings


def _detect_verify_false(tree: ast.AST) -> list[Finding]:
    """
    Detect requests.get/post/etc with verify=False.
    Pattern: requests.get(url, verify=False) or session.request(..., verify=False)
    """
    findings = []
    
    for call in _iter_calls(tree):
        # Check if this is a requests-like call
        if isinstance(call.func, ast.Attribute):
            # Methods like requests.get, session.post, etc.
            for keyword in call.keywords:
                if keyword.arg == "verify" and isinstance(keyword.value, ast.Constant):
                    if keyword.value.value is False:
                        findings.append(Finding(
                            Path("dummy"),
                            call.lineno,
                            "AEGIS005",
                            "verify=False disables SSL certificate validation"
                        ))
    
    return findings


def _detect_file_path_safety(tree: ast.AST) -> list[Finding]:
    """
    Detect unsafe file path operations.
    Pattern: os.path.join with untrusted input, path traversal indicators like ../
    """
    findings = []
    
    for node in ast.walk(tree):
        # Check for os.path operations
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Attribute):
                if node.func.attr in ("join", "abspath", "relpath"):
                    # Check if any argument contains .. (path traversal)
                    for arg in node.args:
                        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                            if ".." in arg.value:
                                findings.append(Finding(
                                    Path("dummy"),
                                    node.lineno,
                                    "AEGIS007",
                                    "Path contains '..' (potential path traversal)"
                                ))
    
    return findings


def _detect_executebuiltin_dangerous(tree: ast.AST) -> list[Finding]:
    """
    Detect calls to xbmc.executebuiltin() with dangerous commands.
    Pattern: xbmc.executebuiltin('UpdateAddonRepos')
    """
    findings = []
    
    for call in _iter_calls(tree):
        if isinstance(call.func, ast.Attribute):
            if call.func.attr == "executebuiltin":
                # Check the first argument for dangerous commands
                if call.args and isinstance(call.args[0], ast.Constant):
                    cmd = call.args[0].value
                    if isinstance(cmd, str):
                        for dangerous in EXECUTEBUILTIN_DANGEROUS:
                            if dangerous in cmd:
                                findings.append(Finding(
                                    Path("dummy"),
                                    call.lineno,
                                    "AEGIS010",
                                    f"executebuiltin('{dangerous}') mutates other addons"
                                ))
    
    return findings


def _detect_env_var_injection(tree: ast.AST) -> list[Finding]:
    """
    Detect environment variable access that may be user-influenced.
    Pattern: os.environ.get(user_input), os.getenv(variable_name), os.environ[key]
    """
    findings = []
    
    for node in ast.walk(tree):
        # Handle subscript access: os.environ[key]
        if isinstance(node, ast.Subscript):
            if isinstance(node.value, ast.Attribute):
                if node.value.attr == "environ":
                    if not _is_literal(node.slice):
                        findings.append(Finding(
                            Path("dummy"),
                            node.lineno,
                            "AEGIS009",
                            "os.environ[non_literal] key (potential injection)"
                        ))
    
    for call in _iter_calls(tree):
        func = call.func
        
        # Detect os.environ.get/pop with non-literal keys
        if isinstance(func, ast.Attribute):
            if func.attr in ("get", "pop"):
                # Check if the object is os.environ
                if isinstance(func.value, ast.Attribute):
                    if func.value.attr == "environ":
                        # os.environ.get(key)
                        if call.args and not _is_literal(call.args[0]):
                            findings.append(Finding(
                                Path("dummy"),
                                call.lineno,
                                "AEGIS009",
                                "os.environ.get with non-literal key (potential injection)"
                            ))
        
        # Detect os.getenv(name) with non-literal
        elif isinstance(func, ast.Attribute):
            if func.attr == "getenv":
                if call.args and not _is_literal(call.args[0]):
                    findings.append(Finding(
                        Path("dummy"),
                        call.lineno,
                        "AEGIS009",
                        "os.getenv with non-literal key (potential injection)"
                    ))
    
    return findings


def _detect_subprocess_unsafe(tree: ast.AST) -> list[Finding]:
    """
    Detect subprocess calls with shell=True or without list-form args.
    Pattern: subprocess.call(cmd, shell=True) or subprocess.Popen(cmd_string)
    """
    findings = []
    
    for call in _iter_calls(tree):
        func = call.func
        
        # Check for subprocess calls
        if isinstance(func, ast.Attribute):
            if func.attr in ("call", "run", "Popen", "check_call"):
                # Look for shell=True
                for keyword in call.keywords:
                    if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant):
                        if keyword.value.value is True:
                            findings.append(Finding(
                                Path("dummy"),
                                call.lineno,
                                "AEGIS011",
                                f"subprocess.{func.attr} with shell=True (injection risk)"
                            ))
                
                # Check if first arg is a string (not list)
                if call.args and isinstance(call.args[0], ast.Constant):
                    if isinstance(call.args[0].value, str):
                        findings.append(Finding(
                            Path("dummy"),
                            call.lineno,
                            "AEGIS011",
                            f"subprocess.{func.attr} with string argument (use list instead)"
                        ))
    
    return findings


def _detect_token_like_strings(source: str) -> list[Finding]:
    """
    Detect long strings that look like hardcoded tokens/secrets.
    Heuristic: consecutive alphanumeric+underscore strings > 40 chars.
    """
    findings = []
    # Simple pattern: look for very long quoted strings
    long_string_pattern = r'(["\'])[a-zA-Z0-9_\-]{40,}(["\'])'
    lines = source.split('\n')
    for line_no, line in enumerate(lines, start=1):
        # Skip comments
        if line.strip().startswith('#'):
            continue
        if re.search(long_string_pattern, line):
            findings.append(Finding(
                Path("dummy"),
                line_no,
                "AEGIS008",
                "Long alphanumeric string resembles hardcoded token/secret"
            ))
    
    return findings


def scan_file(path: Path) -> list[Finding]:
    findings: list[Finding] = []
    source = path.read_text(encoding="utf-8", errors="replace")
    
    # AEGIS001: Insecure HTTP URLs
    if _source_has_insecure_url(source):
        findings.append(Finding(path, 1, "AEGIS001", "Found plaintext HTTP URL"))
    
    try:
        tree = ast.parse(source)
    except SyntaxError as err:
        findings.append(Finding(path, err.lineno or 1, "AEGIS999", "SyntaxError during scan"))
        return findings
    
    # AEGIS002: Dangerous execution calls
    for call in _iter_calls(tree):
        func = call.func
        if isinstance(func, ast.Name) and func.id in DANGEROUS_CALLS:
            findings.append(Finding(path, call.lineno, "AEGIS002", "Dangerous dynamic execution call"))
    
    # AEGIS003: Base64 + exec flow
    for finding in _detect_base64_exec_flow(tree):
        finding.path = path
        findings.append(finding)
    
    # AEGIS004: __import__ with non-literal
    for finding in _detect_import_with_non_literal(tree):
        finding.path = path
        findings.append(finding)
    
    # AEGIS005: verify=False in requests
    for finding in _detect_verify_false(tree):
        finding.path = path
        findings.append(finding)
    
    # AEGIS006: Network calls at module level
    if isinstance(tree, ast.Module):
        for finding in _is_network_call_at_module_level(tree):
            finding.path = path
            findings.append(finding)
    
    # AEGIS007: File path safety
    for finding in _detect_file_path_safety(tree):
        finding.path = path
        findings.append(finding)
    
    # AEGIS008: Token-like strings
    for finding in _detect_token_like_strings(source):
        finding.path = path
        findings.append(finding)
    
    # AEGIS009: Environment variable injection
    for finding in _detect_env_var_injection(tree):
        finding.path = path
        findings.append(finding)
    
    # AEGIS010: executebuiltin dangerous calls
    for finding in _detect_executebuiltin_dangerous(tree):
        finding.path = path
        findings.append(finding)
    
    # AEGIS011: Unsafe subprocess calls
    for finding in _detect_subprocess_unsafe(tree):
        finding.path = path
        findings.append(finding)
    
    return findings


def scan_tree(root: Path) -> list[Finding]:
    results: list[Finding] = []
    for path in root.rglob("*.py"):
        results.extend(scan_file(path))
    return results

