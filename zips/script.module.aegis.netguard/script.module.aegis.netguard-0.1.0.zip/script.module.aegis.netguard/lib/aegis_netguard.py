from __future__ import annotations

import re
from typing import Mapping
from urllib.parse import urlparse

import requests


class AegisInsecureURLError(ValueError):
    pass


REDACTION_KEYS = {
    "access_token",
    "refresh_token",
    "client_secret",
    "authorization",
    "api_key",
}


class GuardedSession(requests.Session):
    """Session that blocks plaintext HTTP calls."""

    def request(self, method, url, *args, **kwargs):
        parsed = urlparse(url)
        if parsed.scheme.lower() != "https":
            raise AegisInsecureURLError("Only HTTPS endpoints are allowed")
        if kwargs.get("verify") is False:
            raise AegisInsecureURLError("TLS verification may not be disabled")
        return super().request(method, url, *args, **kwargs)


def redact_log_line(line: str, key_names: set[str] | None = None) -> str:
    keys = key_names or REDACTION_KEYS
    redacted = line
    for key in keys:
        redacted = re.sub(
            r"(?i)({}\s*[=:]\s*)([^\s,;]+)".format(re.escape(key)),
            r"\1[REDACTED:{}]".format(key),
            redacted,
        )
    return redacted


def redact_mapping(values: Mapping[str, str], key_names: set[str] | None = None) -> dict[str, str]:
    keys = key_names or REDACTION_KEYS
    output: dict[str, str] = {}
    for key, value in values.items():
        if key.lower() in keys:
            output[key] = "[REDACTED:{}]".format(key)
        else:
            output[key] = value
    return output