from __future__ import annotations

import re
from typing import Mapping
from urllib.parse import urlparse

import requests


class AegisInsecureURLError(ValueError):
    pass


REDACTION_KEYS = {
    "access_token",
    "refresh_token",
    "client_secret",
    "authorization",
    "api_key",
    # Adobe Pass / MSO credentials + debrid device-flow codes handled by firstrun.
    "password",
    "pin",
    "aptoken",
    "device_code",
    "user_code",
}


class GuardedSession(requests.Session):
    """Session that blocks plaintext HTTP calls.

    The scheme + TLS-verify enforcement runs in ``send()``, not just
    ``request()``: ``requests`` resolves redirects through ``Session.send()``
    (not ``request()``), so a ``request()``-only guard is bypassable by an
    ``https -> http`` 30x that would leak bearer tokens onto plaintext. ``send()``
    is the one choke point every hop passes through.
    """

    def __init__(self, *args, headers=None, **kwargs):
        # `headers=` is accepted here because three call sites (the plugin's
        # Continue Watching row, its Trakt session helper, the service's Trakt
        # scrobble) construct GuardedSession(headers={...}). requests.Session
        # takes no arguments, so each raised TypeError on every call; the
        # Continue Watching one took the whole row down with it whenever Trakt
        # was linked. The tests never saw it: they swap in a dummy session that
        # accepts anything.
        super().__init__(*args, **kwargs)
        if headers:
            self.headers.update(headers)
        # Pin verification at the session level so it can't be silently disabled
        # via the `verify` attribute; the per-call kwarg is rejected below.
        self.verify = True

    def _guard(self, url: str, verify) -> None:
        parsed = urlparse(url)
        if parsed.scheme.lower() != "https":
            # Only the host in the message -- never echo the full URL, whose
            # query string can carry tokens (this module exists to stop leaks).
            raise AegisInsecureURLError(
                "Only HTTPS endpoints are allowed (host {})".format(parsed.netloc or "?")
            )
        # Reject a disabled TLS check whether it came in as a per-call kwarg OR
        # via a later `session.verify = False` (requests falls back to the
        # session attribute when the call omits verify).
        if verify is False or self.verify is False:
            raise AegisInsecureURLError("TLS verification may not be disabled")

    def request(self, method, url, *args, **kwargs):
        self._guard(url, kwargs.get("verify"))
        return super().request(method, url, *args, **kwargs)

    def send(self, request, **kwargs):
        # Every hop (initial request + each redirect target) passes through here.
        self._guard(request.url, kwargs.get("verify"))
        return super().send(request, **kwargs)


def self_test() -> tuple[bool, str]:
    """Attempt the things the guard exists to refuse, without touching the
    network. Returns (ok, detail).

    Why this exists: the health screen and the home chip used to print
    "HTTPS-only ✓" as fixed text. A guard that is installed but inert (a
    refactor that stops routing through _guard, a subclass that swallows the
    error) would have kept showing the tick. Callers now show the tick only
    when this passes, so the claim is a measurement rather than a label.

    Scope, deliberately narrow: this proves the guard on GuardedSession. It
    says nothing about code that does not use GuardedSession (live-TV stream
    probing, the vendored Umbrella/scraper addons) -- callers must not present
    a pass as build-wide.
    """
    try:
        session = GuardedSession()
    except Exception as exc:
        return False, "could not create session ({})".format(type(exc).__name__)
    refused = (
        ("plain HTTP", "http://aegis.invalid/", None),
        ("disabled certificate check", "https://aegis.invalid/", False),
    )
    for label, url, verify in refused:
        try:
            session._guard(url, verify)
        except AegisInsecureURLError:
            continue
        except Exception as exc:
            return False, "{} raised {}".format(label, type(exc).__name__)
        return False, "{} was NOT refused".format(label)
    # The other direction matters too: a guard that refuses everything would
    # pass the checks above while every account call failed.
    try:
        session._guard("https://aegis.invalid/", None)
    except Exception as exc:
        return False, "verified HTTPS was refused ({})".format(type(exc).__name__)
    if session.verify is not True:
        return False, "session certificate verification is not pinned on"
    return True, "plain HTTP and unverified TLS refused"


def redact_log_line(line: str, key_names: set[str] | None = None) -> str:
    keys = key_names or REDACTION_KEYS
    redacted = line
    for key in keys:
        # \b requires a word boundary before the key so a key name that is the
        # TAIL of a longer token isn't matched (e.g. "pin" inside "spin=fast",
        # where the "pin=" substring would otherwise redact "fast"). The optional
        # auth-scheme group preserves "Bearer"/"Basic" for debugging while still
        # redacting the credential after it -- the old ([^\s,;]+) stopped at the
        # space, so "Authorization: Bearer <tok>" leaked <tok>.
        pattern = (
            r"(?i)\b(" + re.escape(key) + r"\s*[=:]\s*)"
            r"((?:Bearer|Basic|Token|Digest)\s+)?([^\s,;]+)"
        )

        def _sub(match, k=key):
            return "{}{}[REDACTED:{}]".format(match.group(1), match.group(2) or "", k)

        redacted = re.sub(pattern, _sub, redacted)
    return redacted


def redact_mapping(values: Mapping[str, str], key_names: set[str] | None = None) -> dict[str, str]:
    keys = key_names or REDACTION_KEYS
    output: dict[str, str] = {}
    for key, value in values.items():
        if key.lower() in keys:
            output[key] = "[REDACTED:{}]".format(key)
        else:
            output[key] = value
    return output