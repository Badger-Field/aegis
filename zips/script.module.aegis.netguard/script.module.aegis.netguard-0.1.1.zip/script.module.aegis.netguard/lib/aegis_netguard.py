from __future__ import annotations

import re
from typing import Mapping
from urllib.parse import urlparse

import requests


class AegisInsecureURLError(ValueError):
    pass


REDACTION_KEYS = {
    "access_token",
    "refresh_token",
    "client_secret",
    "authorization",
    "api_key",
    # Adobe Pass / MSO credentials + debrid device-flow codes handled by firstrun.
    "password",
    "pin",
    "aptoken",
    "device_code",
    "user_code",
}


class GuardedSession(requests.Session):
    """Session that blocks plaintext HTTP calls.

    The scheme + TLS-verify enforcement runs in ``send()``, not just
    ``request()``: ``requests`` resolves redirects through ``Session.send()``
    (not ``request()``), so a ``request()``-only guard is bypassable by an
    ``https -> http`` 30x that would leak bearer tokens onto plaintext. ``send()``
    is the one choke point every hop passes through.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Pin verification at the session level so it can't be silently disabled
        # via the `verify` attribute; the per-call kwarg is rejected below.
        self.verify = True

    def _guard(self, url: str, verify) -> None:
        parsed = urlparse(url)
        if parsed.scheme.lower() != "https":
            # Only the host in the message -- never echo the full URL, whose
            # query string can carry tokens (this module exists to stop leaks).
            raise AegisInsecureURLError(
                "Only HTTPS endpoints are allowed (host {})".format(parsed.netloc or "?")
            )
        # Reject a disabled TLS check whether it came in as a per-call kwarg OR
        # via a later `session.verify = False` (requests falls back to the
        # session attribute when the call omits verify).
        if verify is False or self.verify is False:
            raise AegisInsecureURLError("TLS verification may not be disabled")

    def request(self, method, url, *args, **kwargs):
        self._guard(url, kwargs.get("verify"))
        return super().request(method, url, *args, **kwargs)

    def send(self, request, **kwargs):
        # Every hop (initial request + each redirect target) passes through here.
        self._guard(request.url, kwargs.get("verify"))
        return super().send(request, **kwargs)


def redact_log_line(line: str, key_names: set[str] | None = None) -> str:
    keys = key_names or REDACTION_KEYS
    redacted = line
    for key in keys:
        # \b requires a word boundary before the key so a key name that is the
        # TAIL of a longer token isn't matched (e.g. "pin" inside "spin=fast",
        # where the "pin=" substring would otherwise redact "fast"). The optional
        # auth-scheme group preserves "Bearer"/"Basic" for debugging while still
        # redacting the credential after it -- the old ([^\s,;]+) stopped at the
        # space, so "Authorization: Bearer <tok>" leaked <tok>.
        pattern = (
            r"(?i)\b(" + re.escape(key) + r"\s*[=:]\s*)"
            r"((?:Bearer|Basic|Token|Digest)\s+)?([^\s,;]+)"
        )

        def _sub(match, k=key):
            return "{}{}[REDACTED:{}]".format(match.group(1), match.group(2) or "", k)

        redacted = re.sub(pattern, _sub, redacted)
    return redacted


def redact_mapping(values: Mapping[str, str], key_names: set[str] | None = None) -> dict[str, str]:
    keys = key_names or REDACTION_KEYS
    output: dict[str, str] = {}
    for key, value in values.items():
        if key.lower() in keys:
            output[key] = "[REDACTED:{}]".format(key)
        else:
            output[key] = value
    return output